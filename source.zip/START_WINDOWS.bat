@echo off
cd /d "%~dp0dist"
echo Hearthstride is starting. Open http://localhost:8787 in your browser.
where py >nul 2>nul
if %errorlevel%==0 (
  py -m http.server 8787 --bind 127.0.0.1
) else (
  python -m http.server 8787 --bind 127.0.0.1
)
pause

package com.example.hearthstride

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

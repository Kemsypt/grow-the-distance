# Grow the Distance

**Every step grows your world.**

A cosy real-world walking and farming game, previously called Hearthstride.
This repository is independent of Luce’s Pokémon project.

## Publish on GitHub Pages

1. Create a repository named `grow-the-distance` on your GitHub account.
2. Upload the contents of this folder, including `.github/workflows/pages.yml`.
3. In repository **Settings → Pages → Build and deployment**, select **GitHub Actions**.
4. In **Actions**, run **Publish Grow the Distance** if the initial run occurred before Pages was enabled.
5. Open the deployed URL shown by the workflow after it finishes successfully.

Every push to `main` runs the Flutter tests, builds the browser game with the correct repository path, and publishes it to Pages. The workflow also supports a custom domain or account-root site through Pages metadata.

## Keep your existing village

Before changing website address, open the old game and use **Settings → Export**.
Import that JSON backup in the new game. Browser saves do not move automatically to a different address. The internal save format and package name are retained for compatibility.

## Local development

Install Flutter stable with Dart 3.10 or newer. Run `flutter pub get`, then `flutter run -d chrome`. Run `flutter test` before publishing. To produce a local browser build, run `flutter build web --release --no-web-resources-cdn --output dist`, then use `START_WINDOWS.bat`.

The ready-built old Hearthstride browser bundle is intentionally omitted: GitHub Actions compiles the renamed source instead.

## Prototype documentation

The notes below describe the existing gameplay. Some earlier version notes document historical behaviour superseded by later releases.

### Earlier prototype notes

A cosy GPS walking and farming prototype, built in Flutter with shared web and Android source.

## Quick start (Windows)
1. Extract this entire ZIP.
2. Double-click START_WINDOWS.bat. Requires Python 3 installed and available as `py` or `python`.
3. Open http://localhost:8787 in Edge or Chrome. Keep the terminal open while playing.

Or use the hosted private preview supplied with this download.

## First adventure
- Open Settings (gear), expand Admin menu, activate GPS spoofer.
- Open Map, choose your home location, and Set home.
- Start a walk. Drag and hold the joystick to move. Distance discoveries add timber, stone and seeds.
- For faster testing, Settings > Admin > Grant building supplies.
- Left-click a map location; Build farm costs 5 timber + 3 stone. Build well costs 8 timber + 6 stone.
- Select your farm marker, move to an outer corner, choose Build fence / wall and walk a loop enclosing the farm. Finish within 12m of any older section of the fence. Minimum area 40m². You can start in the middle: lead-ins are discarded and only the outer loop is kept.
- Time skipper advances 1, 5, 12, 24, 48 hours, 5, 7 or 14 days; or enter an exact future local date/time.
- Select a building, right-click the map to teleport, or walk within 45m, and collect. Complete the real-time 60/90/120-second break. Time skips do not finish recovery breaks.

## Simulator behaviour
- Teleports grant no distance; they cancel current fence recording and start a new route trace.
- Joystick motion earns distance and discoveries only during an active, unpaused walk.
- Simulator is app-local, not a system GPS spoofing utility.
- Turning it on stops the real GPS stream. Turning it off does not automatically connect real GPS.
- Simulation is off after loading a save.
- Farm and well production are capped. Offline time counts naturally. A farm produces 8 carrots/hour; a well 5 water/hour. Farm size adds up to 30 storage units with diminishing returns.

## Saves and privacy
Saves remain in local browser storage, tied to the origin (host/port). Settings offers JSON export/import. Copy the exported JSON to a text file for backup. Clearing browser storage deletes local progress. Only your current position and building locations are retained; route traces are session-only. No app account or cloud location storage. Basemap tiles are fetched from OpenStreetMap, which receives tile requests for the viewed area. Real GPS requires user permission and HTTPS or localhost.

## Development
Install Flutter stable (Dart >=3.10), then run:
```
flutter pub get
flutter run -d chrome
flutter test
flutter build web --release --no-web-resources-cdn --output dist
flutter build apk --release
```
The archive includes the ready-built web app in dist and Flutter Android scaffolding in android. Android builds require a local Android SDK; no APK is included. Android uses foreground-only GPS in this prototype. Before distribution, set a unique application ID, signing, icons and privacy policy.

## Scope and limitations
Included: home, real map tiles, distance pickups, buildings, fence polygons and area, capped/offline production, collection breaks, a short device-narrated introduction, selectable walking goals, Admin simulator and time skip, local saves, backup import/export. Map tiles require internet; offline canvas can be enabled in Settings.
Not yet included: Android background/locked-screen tracking, music-app controls or audio ducking, automatic fitness adaptation, random damage events, physical step counting, route directions, multiplayer, trading, combat, weather or complex crafting. Existing music can play in its own app. The Listen button uses device/browser text-to-speech, not recorded narration.


## v0.2 changes
- Simulator speed is now 1x to 20x a normal 1.4 m/s walk. Desktop has a slider; phone maps have a speed selector above the joystick. Full joystick travel at 20x is 28 m/s.
- Fence posts and double rails appear live behind you during Walk fence, with an open endpoint until you finish the loop. Completed fences keep the same look.
- Walking at 20x still records distance, pickups and fence points. Teleporting still cancels fence recording and awards no distance.
- Fixed sub-metre distance rounding so normal-speed joystick movement records distance and extends fences correctly.


## v0.3 changes
- Finish near any older boundary segment, rather than returning to the recording start. The outer closed loop is extracted from the walk; dangling lead-ins and lead-outs are removed.
- Small GPS bumps are simplified with a 1.25–1.5 m tolerance while preserving concave plot shapes.
- Optional road snapping moves nearby fence sections to OpenStreetMap road centrelines within 6 m. Settings has a toggle. At first use, an in-app permission dialog names the Overpass destination and explains that the surrounding map area will be sent. Permission is device-local, can be revoked, and is not imported from village backups.
- Road geometry is queried for a coarse surrounding rectangle and cached for the session. A 10-second timeout or server error leaves a smoothed walked boundary and displays a fallback notice. No GPS trace is uploaded to the road service. Roads missing from OpenStreetMap cannot be snapped.
- Live public road lookup could not be verified in the build environment; provider parsing/caching/error paths and snapping geometry have automated tests. Live lookup requires permission, internet access, and an available Overpass service.


## v0.4 changes
The Map header now has a permanent Build menu. Farm and Well can be built at the selected map point, or at the player's position if no point is selected. Fence / wall opens a farm picker and starts walking its boundary. The menu stays available when an existing building is selected; during fence recording it is disabled until Finish or Cancel. Locked choices remain visible with instructions. "Fence / wall" refers to the farm boundary, not a separate freestanding masonry-wall building.


## v0.5: visible offline fence straightening
- Replaced the 1.5m, fixed-start-point cleanup with seam-free cyclic straightening. Standard cleanup allows up to 8m deviation on larger plots, scaled down for small plots. Each proposed segment stays within the tolerance of every original boundary sample; the farm remains enclosed, crossings are rejected and area changes stay within 8%.
- New fences use this cleanup automatically, independently of road lookup availability. Completion messages report how many points were actually removed, and say when no extra bends were removed.
- To repair an existing fence, select its farm and choose Neaten fence. Compare Before/After at identical scale, choose Gentle/Standard/Strong, then Apply neatening. Undo neatening restores the previous shape, including after saving/reloading. No need to re-walk the farm, and no road query is made by this tool.

- Teleporting is now available ONLY by right-clicking the map while GPS spoofer is active. Left-click selects locations without moving. Teleport buttons, coordinate entry and jump-to-building shortcuts have been removed. Right-click teleport still awards no distance and cancels an active fence recording.


## Growing and harvesting
Walk the first fence to start a plot of carrots. Select the farm marker and choose a crop to switch planting. Radishes and carrots reach full yield in 7 days. Potatoes and pumpkins take 14 days and yield more per square metre. Crop rows spread across the map as growth advances. The farm marker moves to the centre of its fence and you can collect inside the fence or within 45 m of the original entrance.

Harvest early for a smaller amount or wait for full yield. Collection takes 60, 90 or 120 seconds depending on Settings. After collecting, the same crop starts growing again. Ten harvested crops can replace four timber when building a well through the map’s Build menu.

Finish an outing to see distance, active time, discoveries, collected resources and building progress. Easy increases the next distance target by 10 percentage points of the base target. Too much reduces it by 15. Comfortable keeps the target. The adjustment is capped at 50% in either direction. Changing your base pace resets it. The journal keeps the most recent outing and unlocks narrated Bellmere chapters as you establish your home, fence your plot, harvest and restore the well.


## Full Journey and recovery
Home shows all resource totals. Continue story opens the Bellmere journal and its story walk. Free walk goes directly to the map for gathering resources. Switching walk modes finishes the current outing and starts a new one.

Select View Full Journey at the bottom of the journal. Zoom or pan the overview, toggle farm markers and fences, or use Replay to watch recorded walks and milestones in order. The replay can follow the walker, scrub to a moment, or run from 1× to 20×. Trips record while an outing is active and are saved in the browser and in exported backups. Trails from older builds cannot be reconstructed because those versions did not save them. Buildings in migrated saves appear as existing landmarks. Teleports break the trail without connecting the jump.

Collection has three guided phases with stretching, breathing, shoulder relaxation or seated recovery options. Crop selection requires standing inside the farm boundary.


## Farm upgrades
Select a fenced crop farm and open Farm upgrades. Each track starts at tier 1 and can be upgraded four times. Fence reduces daily break and animal risks. A broken fence can be repaired for four timber. Scarecrow reduces daily bird risk. Farmhouse raises total storage from 100% to 200% of a single full harvest, with reserve crops accumulating beyond full growth. Sprinklers raise growth speed by 15 percentage points per tier without resetting your progress. Existing farms start at tier 1. Farm incidents can occur while away and during an Admin time skip. Crop losses are capped at half of one full harvest per cycle.


## Well upgrades and watering
Crop and fence controls are under Farm upgrades. Farms use between 1 and 3 water per hour by crop. Growth pauses for an hour if the demand cannot be met and resumes when water is available. Existing farms keep their growth when the watering system starts.

Select a well and open Well upgrades. Upgrade collection yield or recharge separately, with five tiers each. Installs require a completed fence and tier 2 sprinklers or better. Purchase one connection per farm. Each subsequent purchase at a well costs more. Move within 25 m of the well, start the pipe walk, walk to the farm, and follow the fence until the connection is confirmed. The map draws the pipe as you walk and keeps the installed route visible. Teleporting interrupts the walk and the purchased pipe can be retried. Active pipes draw from the same well reserves you can collect manually. Any shortfall comes from the inventory.

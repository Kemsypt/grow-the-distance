const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const code = fs.readFileSync(path.join(__dirname, '../web/phone-test.js'), 'utf8');
function setup({mobile=false, saved=null, blocked=false, search=''}={}) {
  const ids = ['phone','zoom','stage','device','screen','game','return','dimensions','scale','rotate','desktop'];
  let srcWrites=0, redirected=null;
  const elements=Object.fromEntries(ids.map(id=>[id,{style:{},listeners:{},value:id==='zoom'?'fit':'',options:[],clientWidth:1070,clientHeight:729,
    addEventListener(event,fn){this.listeners[event]=fn;},add(option){this.options.push(option);},
    fire(event){this.listeners[event]();}}]));
  Object.defineProperty(elements.game,'src',{set(v){this._src=v;srcWrites++;},get(){return this._src;}});
  const modes = new Set(); let observer;
  vm.runInNewContext(code,{
    URL, URLSearchParams, Option:function(text,value){return {text,value};},
    navigator:{userAgent:mobile?'Mozilla Android':'Mozilla Windows',platform:mobile?'Linux armv8l':'Win32',maxTouchPoints:mobile?5:0},
    location:{search,hash:'',replace(v){redirected=String(v);}},
    localStorage:{getItem(){if(blocked)throw Error('blocked');return saved;},setItem(){if(blocked)throw Error('blocked');}},
    document:{baseURI:'https://example.com/grow-the-distance/',getElementById:id=>elements[id],body:{classList:{toggle(k,on){on?modes.add(k):modes.delete(k);}}}},
    window:{addEventListener(){}}, ResizeObserver:class{constructor(fn){observer=fn;}observe(){}},
    requestAnimationFrame:fn=>{fn();return 1;},cancelAnimationFrame(){}
  });
  return {elements,modes,srcWrites:()=>srcWrites,redirected,resize:()=>observer()};
}
const t=setup(), e=t.elements;
assert.equal(e.phone.options.length,15);
assert.equal(e.phone.value,'pixel8a');
assert.equal(e.dimensions.textContent,'412 × 915');
assert.equal(e.game.style.width,'412px');
assert.equal(e.game.style.height,'915px');
assert.ok(parseFloat(e.device.style.height)<729);
for (const option of e.phone.options) {
  e.phone.value=option.value;e.phone.fire('change');
  assert.ok(parseInt(e.game.style.width)>=360);
  assert.ok(parseInt(e.game.style.height)>=667);
}
e.rotate.fire('click');
assert.equal(e.game.style.width,'915px');assert.equal(e.game.style.height,'412px');
e.zoom.value='1';e.zoom.fire('change');assert.equal(e.game.style.transform,'scale(1)');
e.desktop.fire('click');assert.ok(t.modes.has('desktop'));assert.equal(e.game.style.width,'1070px');
e.return.fire('click');assert.ok(!t.modes.has('desktop'));assert.equal(t.srcWrites(),1);
e.stage.clientWidth=650;e.stage.clientHeight=400;e.zoom.value='fit';t.resize();
assert.ok(parseFloat(e.device.style.width)<=650-64);
assert.ok(parseFloat(e.device.style.height)<=400-64);
assert.equal(t.srcWrites(),1);
const m=setup({mobile:true,search:'?v=017'});assert.equal(m.redirected,'https://example.com/grow-the-distance/app.html?v=017');assert.equal(m.srcWrites(),0);
assert.equal(setup({mobile:true,search:'?phoneTest=1'}).elements.phone.options.length,15);
assert.equal(setup({saved:'broken json'}).elements.phone.value,'pixel8a');
assert.equal(setup({blocked:true}).elements.phone.value,'pixel8a');
const remembered=setup({saved:JSON.stringify({phone:'iphonese',landscape:true,zoom:'0.75'})});
assert.equal(remembered.elements.game.style.width,'667px');assert.equal(remembered.elements.game.style.height,'375px');
assert.equal(remembered.elements.game.style.transform,'scale(0.75)');
console.log('Phone Test checks passed: 15 presets, scaling, rotation, zoom, desktop toggle, single game instance, mobile routing, saved preferences and blocked storage.');

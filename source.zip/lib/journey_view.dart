import 'dart:async';
import 'dart:math';
// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' show LatLng;
import 'journey_history.dart';

class JourneyView extends StatefulWidget {
  const JourneyView({
    required this.events,
    required this.origin,
    required this.tiles,
    super.key,
  });
  final List<JourneyEvent> events;
  final LatLng origin;
  final bool tiles;
  @override
  State<JourneyView> createState() => _JourneyViewState();
}

class _JourneyViewState extends State<JourneyView> {
  final controller = MapController();
  final overview = JourneyFrame(), replay = JourneyFrame();
  bool replayMode = false, showFarms = true, follow = true, playing = false;
  int speed = 1;
  Timer? timer;
  int holdTicks = 0;
  JourneyFrame get frame => replayMode ? replay : overview;
  late final List<LatLng> walkPoints;
  late final int walkCount;
  static const colours = [
    Color(0xff007c91),
    Color(0xffad5319),
    Color(0xff774fac),
    Color(0xff1b704f),
  ];

  @override
  void initState() {
    super.initState();
    overview.seek(widget.events, widget.events.length);
    walkPoints = overview.tracks.expand((t) => t.$2).toList();
    walkCount = overview.walk;
  }

  @override
  void dispose() {
    timer?.cancel();
    controller.dispose();
    super.dispose();
  }

  late final CameraFit? fit = _makeFit();

  CameraFit? _makeFit() {
    final points = walkPoints.isNotEmpty
        ? walkPoints
        : overview.buildings.values.map((e) => e.position!).toList();
    return points.length < 2
        ? null
        : CameraFit.coordinates(
            coordinates: points,
            padding: const EdgeInsets.all(42),
            maxZoom: 17,
          );
  }

  void fitMap() {
    final bounds = fit;
    if (bounds != null) {
      controller.fitCamera(bounds);
    } else {
      controller.move(
        walkPoints.firstOrNull ??
            overview.buildings.values.firstOrNull?.position ??
            widget.origin,
        16,
      );
    }
  }

  void seek(int value) {
    setState(() => replay.seek(widget.events, value));
    final event = value > 0 ? widget.events[value - 1] : null;
    final target =
        event?.kind == JourneyKind.place &&
            (showFarms || event?.building != 'farm')
        ? event?.position
        : replay.position;
    if (follow && target != null) {
      controller.move(target, controller.camera.zoom.clamp(15.0, 19.0));
    }
  }

  void pause() {
    timer?.cancel();
    setState(() => playing = false);
  }

  void play() {
    if (playing) {
      pause();
      return;
    }
    if (widget.events.isEmpty) return;
    if (replay.cursor >= widget.events.length) seek(0);
    setState(() => playing = true);
    holdTicks = 0;
    timer = Timer.periodic(const Duration(milliseconds: 80), (_) {
      if (holdTicks > 0) {
        holdTicks--;
        return;
      }
      final end = min(widget.events.length, replay.cursor + speed);
      int stop = end;
      for (var i = replay.cursor; i < end; i++) {
        if (widget.events[i].label != null) {
          stop = i + 1;
          holdTicks = max(2, 11 ~/ speed);
          break;
        }
      }
      seek(stop);
      if (stop == widget.events.length) pause();
    });
  }

  void showReplay(bool value) {
    pause();
    setState(() => replayMode = value);
    if (!value) fitMap();
  }

  List<JourneyEvent> get milestones =>
      widget.events.where((e) => e.label != null).toList();
  String date(JourneyEvent event) {
    final d = DateTime.fromMillisecondsSinceEpoch(event.time).toLocal();
    return '${d.day}/${d.month}/${d.year} · ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final places = frame.buildings.values
        .where((p) => showFarms || p.building != 'farm')
        .toList();
    final current = replay.highlight;
    return Scaffold(
      appBar: AppBar(title: const Text('Full Journey')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
              child: Wrap(
                spacing: 8,
                runSpacing: 4,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  ChoiceChip(
                    label: const Text('All walks'),
                    selected: !replayMode,
                    onSelected: (_) => showReplay(false),
                  ),
                  ChoiceChip(
                    label: const Text('Replay'),
                    selected: replayMode,
                    onSelected: (_) => showReplay(true),
                  ),
                  FilterChip(
                    label: const Text('Show farms'),
                    selected: showFarms,
                    onSelected: (v) => setState(() => showFarms = v),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Stack(
                children: [
                  FlutterMap(
                    mapController: controller,
                    options: MapOptions(
                      initialCenter:
                          walkPoints.firstOrNull ??
                          overview.buildings.values.firstOrNull?.position ??
                          widget.origin,
                      initialZoom: 16,
                      initialCameraFit: fit,
                      minZoom: 2,
                      maxZoom: 19,
                    ),
                    children: [
                      if (widget.tiles)
                        TileLayer(
                          urlTemplate:
                              'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                          userAgentPackageName: 'com.hearthstride.app',
                        ),
                      PolygonLayer(
                        polygons: [
                          for (final p in places)
                            if (p.fence.length >= 3)
                              Polygon(
                                points: p.fence,
                                color: const Color(0x556f9e42),
                                borderColor: const Color(0xff795134),
                                borderStrokeWidth: 3,
                              ),
                        ],
                      ),
                      PolylineLayer(
                        polylines: [
                          for (final (walk, points) in frame.tracks)
                            if (points.length >= 2)
                              Polyline(
                                points: points,
                                color: colours[(walk - 1) % colours.length],
                                strokeWidth: 4,
                              ),
                        ],
                      ),
                      MarkerLayer(
                        markers: [
                          for (final p in places)
                            Marker(
                              point: p.position!,
                              width: 34,
                              height: 34,
                              child: Tooltip(
                                message: p.label ?? '',
                                child: DecoratedBox(
                                  decoration: BoxDecoration(
                                    color: const Color(0xfffff2d4),
                                    borderRadius: BorderRadius.circular(7),
                                  ),
                                  child: Icon(switch (p.building) {
                                    'farm' => Icons.spa,
                                    'well' => Icons.water_drop,
                                    _ => Icons.cottage,
                                  }, size: 20),
                                ),
                              ),
                            ),
                          if (replayMode && frame.position != null)
                            Marker(
                              point: frame.position!,
                              width: 25,
                              height: 25,
                              child: const Icon(
                                Icons.location_on,
                                color: Color(0xff194fba),
                              ),
                            ),
                        ],
                      ),
                      if (widget.tiles)
                        const Align(
                          alignment: Alignment.bottomLeft,
                          child: ColoredBox(
                            color: Color(0xddfff3d6),
                            child: Text(
                              ' © OpenStreetMap contributors ',
                              style: TextStyle(fontSize: 10),
                            ),
                          ),
                        ),
                    ],
                  ),
                  Positioned(
                    right: 10,
                    top: 10,
                    child: Material(
                      color: Theme.of(context).colorScheme.surface,
                      borderRadius: BorderRadius.circular(8),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            tooltip: 'Zoom in',
                            onPressed: () => controller.move(
                              controller.camera.center,
                              min(19, controller.camera.zoom + 1),
                            ),
                            icon: const Icon(Icons.add),
                          ),
                          IconButton(
                            tooltip: 'Zoom out',
                            onPressed: () => controller.move(
                              controller.camera.center,
                              max(2, controller.camera.zoom - 1),
                            ),
                            icon: const Icon(Icons.remove),
                          ),
                          IconButton(
                            tooltip: 'Fit all walks',
                            onPressed: fitMap,
                            icon: const Icon(Icons.fit_screen),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (replayMode)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 5, 12, 9),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      current?.label ?? 'Ready to replay',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      current == null
                          ? 'Walk ${frame.walk} of $walkCount'
                          : 'Walk ${frame.walk} of $walkCount  ·  ${date(current)}',
                    ),
                    Slider(
                      value: replay.cursor.toDouble(),
                      max: max(1, widget.events.length).toDouble(),
                      onChanged: widget.events.isEmpty
                          ? null
                          : (v) {
                              if (playing) pause();
                              seek(v.round());
                            },
                    ),
                    Wrap(
                      spacing: 8,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        FilledButton.icon(
                          onPressed: widget.events.isEmpty ? null : play,
                          icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                          label: Text(playing ? 'Pause' : 'Play'),
                        ),
                        IconButton(
                          tooltip: 'Restart replay',
                          onPressed: () {
                            pause();
                            seek(0);
                          },
                          icon: const Icon(Icons.replay),
                        ),
                        DropdownButton<int>(
                          value: speed,
                          items: [1, 2, 5, 10, 20]
                              .map(
                                (v) => DropdownMenuItem(
                                  value: v,
                                  child: Text('${v}×'),
                                ),
                              )
                              .toList(),
                          onChanged: (v) => setState(() => speed = v!),
                        ),
                        FilterChip(
                          label: const Text('Follow walker'),
                          selected: follow,
                          onSelected: (v) => setState(() => follow = v),
                        ),
                      ],
                    ),
                  ],
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        walkPoints.isEmpty
                            ? 'Start a walk to record your first trail.'
                            : '$walkCount recorded ${walkCount == 1 ? 'walk' : 'walks'}. Pan or zoom to explore.',
                      ),
                    ),
                    TextButton(
                      onPressed: milestones.isEmpty ? null : showTimeline,
                      child: const Text('Timeline'),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  void showTimeline() {
    final events = milestones;
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: ListView.builder(
          itemCount: events.length,
          itemBuilder: (context, i) {
            final event = events[i];
            return ListTile(
              title: Text(event.label!),
              subtitle: Text(date(event)),
              onTap: () {
                Navigator.pop(context);
                showReplay(true);
                seek(widget.events.indexOf(event) + 1);
                if (event.position != null)
                  controller.move(
                    event.position!,
                    max(15.0, controller.camera.zoom),
                  );
              },
            );
          },
        ),
      ),
    );
  }
}

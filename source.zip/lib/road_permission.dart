// ignore: deprecated_member_use
import 'package:flutter/material.dart';

Future<bool> askForRoadData(BuildContext context) async =>
    await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Use nearby road data?'),
        content: const Text(
          'To snap fences to road centres, send the surrounding map area to '
          'Overpass API (overpass-api.de), a service for OpenStreetMap data. '
          'This reveals the area you are building in. Your recorded route is not sent.\n\n'
          'Allow this for future fences on this device? You can revoke it in Settings. '
          'Choosing Skip still completes and smooths your fence.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Skip road snapping'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Allow road lookup'),
          ),
        ],
      ),
    ) ??
    false;

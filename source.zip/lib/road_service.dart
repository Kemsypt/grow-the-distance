import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class RoadData {
  final List<List<LatLng>> roads;
  final bool available;
  const RoadData(this.roads, {this.available = true});
}

/// Requests a coarse surrounding map rectangle, never the recorded GPS trace.
/// A short timeout and bounded query let fence completion work offline too.
class RoadService {
  final http.Client client;
  final Map<String, RoadData> _cache = {};
  RoadService({http.Client? client}) : client = client ?? http.Client();
  Future<RoadData> near(List<LatLng> points) async {
    if (points.isEmpty) return const RoadData([], available: false);
    const cell = .005;
    final south =
        (points.map((p) => p.latitude).reduce(min) / cell).floor() * cell -
        cell;
    final north =
        (points.map((p) => p.latitude).reduce(max) / cell).ceil() * cell + cell;
    final west =
        (points.map((p) => p.longitude).reduce(min) / cell).floor() * cell -
        cell;
    final east =
        (points.map((p) => p.longitude).reduce(max) / cell).ceil() * cell +
        cell;
    if (north - south > .06 || east - west > .06)
      return const RoadData([], available: false);
    final bbox = [
      south,
      west,
      north,
      east,
    ].map((v) => v.toStringAsFixed(3)).join(',');
    if (_cache.containsKey(bbox)) return _cache[bbox]!;
    final query =
        '[out:json][timeout:7];way["highway"~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|service|road)(_link)?\u0024"]($bbox);out geom;';
    try {
      final response = await client
          .post(
            Uri.parse('https://overpass-api.de/api/interpreter'),
            body: {'data': query},
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode != 200)
        return const RoadData([], available: false);
      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      if (decoded['remark'] != null)
        return const RoadData([], available: false);
      final roads = <List<LatLng>>[];
      for (final element in decoded['elements'] as List) {
        if (element['type'] != 'way' || element['geometry'] is! List) continue;
        final line = <LatLng>[];
        for (final node in element['geometry'] as List) {
          if (node['lat'] is num && node['lon'] is num)
            line.add(
              LatLng(
                (node['lat'] as num).toDouble(),
                (node['lon'] as num).toDouble(),
              ),
            );
        }
        if (line.length >= 2) roads.add(line);
      }
      final result = RoadData(roads);
      if (_cache.length >= 8) _cache.remove(_cache.keys.first);
      _cache[bbox] = result;
      return result;
    } catch (_) {
      return const RoadData([], available: false);
    }
  }

  void dispose() => client.close();
}

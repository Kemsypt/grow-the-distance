enum VillagePet {
  dog('Dog', '🐶', '30% lower fence-break risk'),
  cat('Cat', '🐱', '30% lower bird-swarm risk'),
  bunny('Bunny', '🐰', '15% more crops at harvest');

  const VillagePet(this.label, this.emoji, this.farmBonus);
  final String label, emoji, farmBonus;

  static const riskReduction = .30;
  static const harvestBonus = .15;
  String get asset => 'assets/pet_$name.png';
}

enum HomeProject {
  compostBin('Compost bin', 'compost', '🍂', 8, 4, {'timber': 8, 'stone': 3}),
  herbPatch('Herb patch', 'herbs', '🌿', 6, 6, {'timber': 5, 'seeds': 3}),
  workbench('Workbench', 'repair kits', '🧰', 0, 0, {'timber': 12, 'stone': 8});

  const HomeProject(
    this.label,
    this.resource,
    this.icon,
    this.hours,
    this.capacity,
    this.cost,
  );
  final String label, resource, icon;
  final int hours, capacity;
  final Map<String, int> cost;

  static const repairKitCost = {'timber': 3, 'stone': 2};
}

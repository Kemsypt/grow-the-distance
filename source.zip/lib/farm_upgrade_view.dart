// ignore: deprecated_member_use
import 'package:flutter/material.dart';

import 'farm_upgrades.dart';
import 'building_customization.dart';
import 'water_system.dart';
import 'game.dart';

class FarmUpgradeView extends StatelessWidget {
  const FarmUpgradeView({
    required this.game,
    required this.farm,
    this.chooseCrop,
    this.buildFence,
    this.neatenFence,
    this.startPipe,
    super.key,
  });
  final Game game;
  final Place farm;
  final VoidCallback? chooseCrop, buildFence, neatenFence;
  final ValueChanged<Place>? startPipe;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${farm.name} upgrades')),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: game,
          builder: (context, _) => ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 760),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Wrap(
                        spacing: 8,
                        runSpacing: 6,
                        children: [
                          OutlinedButton(
                            onPressed: farm.fence.isEmpty || game.inFarm(farm)
                                ? () => editBuilding(context, game, farm)
                                : null,
                            child: const Text('Customize farm'),
                          ),
                          OutlinedButton(
                            onPressed: buildFence,
                            child: const Text('Build fence / wall'),
                          ),
                          OutlinedButton(
                            onPressed: game.inFarm(farm) ? chooseCrop : null,
                            child: const Text('Choose crop'),
                          ),
                          if (farm.fence.length >= 3)
                            OutlinedButton(
                              onPressed: neatenFence,
                              child: const Text('Neaten fence'),
                            ),
                          if (farm.fenceBeforeCleanup.length >= 3)
                            OutlinedButton(
                              onPressed: () => game.undoFenceCleanup(farm),
                              child: const Text('Undo neatening'),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      if (farm.fence.length < 3)
                        const Text(
                          'Walk the farm fence to unlock crop production and upgrades.',
                        ),
                      if (farm.fence.length >= 3 && !game.inFarm(farm))
                        const Text(
                          'Step inside the fence to change crops, upgrade or repair.',
                        ),
                      Text(
                        '${farm.crop.waterPerHour} water/hour · ${farm.pipeActive
                            ? (farm.pipeOn ? 'Piped water with inventory backup' : 'Pipes off · inventory watering')
                            : farm.pipes.isNotEmpty
                            ? 'Pipe walk pending'
                            : 'Draws from inventory'}',
                      ),
                      if (farm.dry)
                        const Text('Growth paused · not enough water.'),
                      const SizedBox(height: 12),
                      if (farm.improvements.fenceDamaged ||
                          farm.improvements.lostCrops > 0 ||
                          farm.improvements.lastIncident != null)
                        Card(
                          color: const Color(0xffffe5cc),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (farm.improvements.fenceDamaged)
                                  Text(
                                    'Fence damaged · ${farm.improvements.fenceYieldLoss}% lower yield and more farm events until repaired.',
                                  ),
                                if (farm.improvements.lostCrops > 0)
                                  Text(
                                    '${farm.improvements.lostCrops} crops lost this cycle.',
                                  ),
                                if (farm.improvements.lastIncident
                                    case final incident?)
                                  Text(incident),
                                if (farm.improvements.fenceDamaged)
                                  TextButton(
                                    onPressed:
                                        game.inFarm(farm) &&
                                            (game.bag['timber'] ?? 0) >=
                                                Game.fenceRepairTimber
                                        ? () => game.repairFarmFence(farm)
                                        : null,
                                    child: const Text(
                                      'Repair fence · ${Game.fenceRepairTimber} timber',
                                    ),
                                  ),
                                if (farm.improvements.fenceDamaged)
                                  TextButton(
                                    onPressed:
                                        game.inFarm(farm) &&
                                            (game.bag['repair kits'] ?? 0) > 0
                                        ? () => game.repairFarmFence(
                                            farm,
                                            useKit: true,
                                          )
                                        : null,
                                    child: const Text(
                                      'Repair fence · 1 repair kit',
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      Text(
                        '${farm.yieldCapacity} crops at full yield · ${farm.storage} storage',
                      ),
                      const SizedBox(height: 12),
                      if (farm.fence.length >= 3)
                        OutlinedButton(
                          onPressed:
                              game.inFarm(farm) &&
                                  !farm.compostApplied &&
                                  farm.growth(game.now) < 1 &&
                                  (game.bag['compost'] ?? 0) > 0
                              ? () => game.applyCompost(farm)
                              : null,
                          child: Text(
                            farm.compostApplied
                                ? 'Compost applied this planting'
                                : 'Apply compost · 1 compost',
                          ),
                        ),
                      if (game.pet != null && farm.fence.length >= 3)
                        _farmPet(context),
                      if (game.canPipe(farm)) _pipes(context),
                      if (farm.fence.length >= 3)
                        for (final upgrade in FarmUpgrade.values)
                          _upgradeCard(context, upgrade),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _farmPet(BuildContext context) {
    final pet = game.pet!;
    final assigned = game.petFarm == farm;
    final unlocked = game.petFriendship >= Game.petFarmUnlock;
    final withinFarm = game.inFarm(farm);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${pet.emoji} Farm helper',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(pet.farmBonus),
            if (assigned)
              const Text('Your pet is helping here.')
            else if (!unlocked)
              const Text('Unlock at friendship level 4.')
            else if (!withinFarm)
              const Text('Step inside the fence to leave your pet here.'),
            TextButton(
              onPressed: assigned
                  ? () => game.setPetFollowing(true)
                  : unlocked && withinFarm
                  ? () => game.assignPetToFarm(farm)
                  : null,
              child: Text(assigned ? 'Call pet back' : 'Leave pet here'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _pipes(BuildContext context) {
    final inside = game.inFarm(farm);
    final cost = game.pipeUpgradeCost(farm);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Farm pipes · ${farm.pipes.length} / ${farm.pipeSlots}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            for (final connection in farm.pipes)
              if (game.pipeSource(farm, connection) case final well?)
                if (connection.installed)
                  SwitchListTile(
                    title: Text(well.name),
                    value: connection.enabled,
                    onChanged: (enabled) =>
                        game.togglePipe(farm, connection, enabled),
                  )
                else
                  ListTile(
                    title: Text(well.name),
                    subtitle: const Text('Installation walk pending'),
                    trailing: TextButton(
                      onPressed: startPipe == null
                          ? null
                          : () => startPipe!(well),
                      child: const Text('Start pipe walk'),
                    ),
                  ),
            if (farm.pipes.length < farm.pipeSlots)
              for (final well in game.places.where(
                (place) => place.kind == 'well',
              ))
                if (game.connectionTo(well, farm) == null)
                  ListTile(
                    title: Text(well.name),
                    subtitle: Text(
                      WellUpgrades.connectionCost(
                            game.connectedFarms(well).length,
                          ).entries
                          .map((entry) => '${entry.value} ${entry.key}')
                          .join(' · '),
                    ),
                    trailing: TextButton(
                      onPressed: inside ? () => game.buyPipe(well, farm) : null,
                      child: const Text('Buy pipe'),
                    ),
                  ),
            if (farm.pipeSlots < 3)
              OutlinedButton(
                onPressed:
                    inside &&
                        cost.entries.every(
                          (entry) => (game.bag[entry.key] ?? 0) >= entry.value,
                        )
                    ? () => game.upgradePipes(farm)
                    : null,
                child: Text(
                  'Add pipe slot · ${cost.entries.map((entry) => '${entry.value} ${entry.key}').join(' · ')}',
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _upgradeCard(BuildContext context, FarmUpgrade upgrade) {
    final level = farm.improvements.level(upgrade);
    final isMax = level == FarmUpgrade.maxTier;
    final cost = isMax ? const <String, int>{} : upgrade.cost(level + 1);
    final affordable = cost.entries.every(
      (item) => (game.bag[item.key] ?? 0) >= item.value,
    );
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(upgrade.icon, style: const TextStyle(fontSize: 25)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    upgrade.label,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                Text('Tier $level / 5'),
              ],
            ),
            const SizedBox(height: 6),
            LinearProgressIndicator(value: level / 5),
            const SizedBox(height: 10),
            Text(
              upgrade.tiers[level - 1],
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(upgrade.effect(level)),
            if (!isMax) ...[
              const Divider(height: 20),
              Text(
                'Next · ${upgrade.tiers[level]}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(upgrade.effect(level + 1)),
              const SizedBox(height: 6),
              Text(
                cost.entries
                    .map(
                      (item) =>
                          '${game.bag[item.key] ?? 0}/${item.value} ${item.key}',
                    )
                    .join('  ·  '),
              ),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: game.inFarm(farm) && affordable
                    ? () => game.upgradeFarm(farm, upgrade)
                    : null,
                child: Text(
                  affordable
                      ? 'Upgrade ${upgrade.label.toLowerCase()} to tier ${level + 1}'
                      : 'More resources needed',
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

import 'dart:math';

// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';

import 'game.dart';

class GrowingFields extends StatelessWidget {
  const GrowingFields(this.farms, this.now, {super.key});
  final Iterable<Place> farms;
  final int now;
  @override
  Widget build(BuildContext context) {
    final camera = MapCamera.of(context);
    return IgnorePointer(
      child: SizedBox.expand(
        child: CustomPaint(
          painter: _FieldsPainter([
            for (final farm in farms)
              (
                farm.fence.map(camera.latLngToScreenOffset).toList(),
                farm.growth(now),
                farm.crop,
              ),
          ]),
        ),
      ),
    );
  }
}

class _FieldsPainter extends CustomPainter {
  const _FieldsPainter(this.fields);
  final List<(List<Offset>, double, Crop)> fields;
  @override
  void paint(Canvas canvas, Size size) {
    final viewport = Offset.zero & size;
    for (final (points, progress, crop) in fields) {
      final outline = Path()..addPolygon(points, true);
      final bound = outline.getBounds();
      if (!bound.overlaps(viewport) || progress <= 0) continue;
      final visible = bound.intersect(viewport);
      final front = bound.top + bound.height * progress;
      final colour = switch (crop) {
        Crop.carrots => const Color(0xffec883f),
        Crop.radishes => const Color(0xffd76580),
        Crop.pumpkins => const Color(0xffffa335),
        Crop.potatoes => const Color(0xffb99a54),
      };
      canvas.save();
      canvas.clipPath(outline);
      canvas.drawRect(
        Rect.fromLTRB(bound.left, bound.top, bound.right, front),
        Paint()..color = const Color(0xff6b993f).withValues(alpha: .40),
      );
      const spacing = 15.0;
      final rows = ((visible.top - bound.top) / spacing).floor();
      final columns = ((visible.left - bound.left) / spacing).floor();
      for (
        var y = bound.top + rows * spacing + 5;
        y <= min(front, visible.bottom + 5);
        y += spacing
      ) {
        canvas.drawLine(
          Offset(visible.left, y + 4),
          Offset(visible.right, y + 4),
          Paint()..color = const Color(0xff6a4c34).withValues(alpha: .40),
        );
        for (
          var x = bound.left + columns * spacing + 5;
          x <= visible.right + 5;
          x += spacing
        ) {
          canvas.drawRect(
            Rect.fromCenter(center: Offset(x, y + 2), width: 5, height: 4),
            Paint()..color = colour,
          );
          canvas.drawRect(
            Rect.fromCenter(center: Offset(x, y - 1), width: 3, height: 4),
            Paint()..color = const Color(0xff305a32),
          );
        }
      }
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _FieldsPainter oldDelegate) => true;
}

class HarvestBasket extends StatelessWidget {
  const HarvestBasket({required this.progress, required this.icon, super.key});
  final double progress;
  final String icon;
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
    tween: Tween(end: progress),
    duration: const Duration(milliseconds: 500),
    builder: (context, value, _) => SizedBox(
      width: 145,
      height: 86,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          const Text('🧺', style: TextStyle(fontSize: 64, height: 1)),
          for (var i = 0; i < 8; i++)
            Positioned(
              left: 35 + (i % 4) * 17.0,
              bottom: 19 + (i ~/ 4) * 14.0,
              child: Opacity(
                opacity: (value * 8 - i).clamp(0.0, 1.0),
                child: Text(icon, style: const TextStyle(fontSize: 17)),
              ),
            ),
        ],
      ),
    ),
  );
}

String clockTime(int seconds) =>
    '${seconds ~/ 60}:${(seconds % 60).toString().padLeft(2, '0')}';
String until(int target, int now) {
  final minutes = max(0, ((target - now) / 60000).ceil());
  if (minutes >= 1440) return '${minutes ~/ 1440}d ${(minutes % 1440) ~/ 60}h';
  if (minutes >= 60) return '${minutes ~/ 60}h ${minutes % 60}m';
  return '${minutes}m';
}

class VillageChapter {
  const VillageChapter(this.title, this.speaker, this.body);
  final String title, speaker, body;
}

const villageChapters = [
  VillageChapter(
    'The house at the end of the lane',
    'The solicitor’s letter',
    'A relative you never met has left you a farmhouse outside the little town of Bellmere. The letter names her as Ada Vale. No one in your family remembers an Ada. You decide to see the house for yourself. Inside the envelope is a brass key and a note in a different hand: “The front door sticks in the rain.”',
  ),
  VillageChapter(
    'A neighbour at the gate',
    'Rowan, from across the lane',
    'Rowan brings bread and asks if you’re staying. He says Ada used to walk the boundary every evening. While you gather timber and stone for the farm, he mentions the old town bell. It hasn’t had a rope in twenty years. He says this as though it explains something.',
  ),
  VillageChapter(
    'The first furrow',
    'Mira, the village shopkeeper',
    'Mira brings you seeds and asks what you plan to grow. When she sees the new fence, she traces its outline on the table with one finger. “That’s where Ada put hers,” she says. You built it by following the paths that felt right. Plant a crop and watch for your first harvest.',
  ),
  VillageChapter(
    'Under the well cover',
    'A page from Ada’s notebook',
    'After your first harvest, Rowan shows you the old well. You can restore it with supplies, and spare crops can cover some of the timber. Under the cover is a folded page in Ada’s hand: “The bell sounded at 3:17. Ask Mira whether she heard it too.”',
  ),
  VillageChapter(
    'Three seventeen',
    'Mira, after closing',
    'The well is working again. You ask Mira about the notebook. She washes the same cup twice before answering. “I heard it the night Ada left.” Outside, a farm gate taps in the wind. The clock behind Mira has stopped at 3:17.',
  ),
];

class CollectionRoutine extends StatelessWidget {
  const CollectionRoutine({
    required this.activity,
    required this.remaining,
    required this.total,
    super.key,
  });
  final String activity;
  final int remaining, total;
  @override
  Widget build(BuildContext context) {
    final steps = switch (activity) {
      'Gentle breathing' => const [
        (
          'Settle in',
          'Stand or sit comfortably. Let your hands and shoulders relax.',
        ),
        (
          'Breathe slowly',
          'Take a few easy breaths. Let each breath out gently.',
        ),
        (
          'Ease back in',
          'Return to your usual breathing and relax your hands.',
        ),
      ],
      'Shoulder relaxation' => const [
        (
          'Drop your shoulders',
          'Sit or stand tall and let your arms hang comfortably.',
        ),
        (
          'Roll and release',
          'Make a few slow shoulder circles in each direction.',
        ),
        (
          'Relax your arms',
          'Let your shoulders settle and take a few easy breaths.',
        ),
      ],
      'Seated rest' => const [
        (
          'Take a seat',
          'Find a comfortable seat and rest both feet on the ground.',
        ),
        (
          'Loosen your ankles',
          'Gently lift and lower your toes, then your heels, a few times.',
        ),
        (
          'Take a quiet moment',
          'Rest your feet and breathe normally until the timer ends.',
        ),
      ],
      _ => const [
        (
          'Loosen your shoulders',
          'Stand or sit comfortably. Roll your shoulders slowly, then let your arms relax.',
        ),
        (
          'Stretch your calves',
          'Use a sturdy support if helpful. Step one foot back and gently lower that heel, then swap legs.',
        ),
        (
          'Release and breathe',
          'Bring your feet together, relax your arms and take a few easy breaths.',
        ),
      ],
    };
    final index =
        ((total - remaining).clamp(0, total) * steps.length ~/ max(1, total))
            .clamp(0, steps.length - 1);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(activity, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 7),
        Text(
          '${index + 1} of ${steps.length} · ${steps[index].$1}',
          style: const TextStyle(fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        Text(steps[index].$2, textAlign: TextAlign.center),
        const SizedBox(height: 6),
        const Text(
          'Keep movements comfortable. You can rest instead.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 11),
        ),
      ],
    );
  }
}

import 'package:latlong2/latlong.dart';

enum JourneyKind { walkStart, trackStart, point, walkEnd, place, note }

class JourneyEvent {
  const JourneyEvent(
    this.kind,
    this.time, {
    this.position,
    this.label,
    this.placeId,
    this.building,
    this.fence = const [],
  });

  final JourneyKind kind;
  final int time;
  final LatLng? position;
  final String? label, building;
  final int? placeId;
  final List<LatLng> fence;

  static List<double> _coords(LatLng p) => [p.latitude, p.longitude];
  static LatLng _point(List<dynamic> value) =>
      LatLng((value[0] as num).toDouble(), (value[1] as num).toDouble());

  List<dynamic> json() => [
    kind.name,
    time,
    position == null ? null : _coords(position!),
    if (label != null || placeId != null) label,
    if (placeId != null) ...[placeId, building, fence.map(_coords).toList()],
  ];
  factory JourneyEvent.from(List<dynamic> j) => JourneyEvent(
    JourneyKind.values.byName(j[0] as String),
    j[1] as int,
    position: j[2] == null ? null : _point(j[2] as List<dynamic>),
    label: j.length > 3 ? j[3] as String? : null,
    placeId: j.length > 4 ? j[4] as int : null,
    building: j.length > 4 ? j[5] as String : null,
    fence: j.length > 4
        ? (j[6] as List).map((p) => _point(p as List<dynamic>)).toList()
        : const [],
  );
}

/// Reconstructs the timeline incrementally. Teleports and paused movement start
/// a new segment, and building events replace the previous snapshot of a place.
class JourneyFrame {
  final tracks = <(int, List<LatLng>)>[];
  final buildings = <int, JourneyEvent>{};
  int walk = 0;
  int cursor = 0;
  LatLng? position;
  JourneyEvent? highlight;
  List<LatLng>? _track;

  void seek(List<JourneyEvent> events, int target) {
    if (target < cursor) {
      tracks.clear();
      buildings.clear();
      walk = 0;
      cursor = 0;
      position = null;
      highlight = null;
      _track = null;
    }
    while (cursor < target) {
      final e = events[cursor++];
      switch (e.kind) {
        case JourneyKind.walkStart:
          walk++;
          _track = null;
          position = null;
        case JourneyKind.trackStart:
          _track = [e.position!];
          tracks.add((walk, _track!));
          position = e.position;
        case JourneyKind.point:
          _track?.add(e.position!);
          position = e.position;
        case JourneyKind.walkEnd:
          _track = null;
        case JourneyKind.place:
          buildings[e.placeId!] = e;
        case JourneyKind.note:
          break;
      }
      if (e.label != null) highlight = e;
    }
  }
}

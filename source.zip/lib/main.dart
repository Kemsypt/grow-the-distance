import 'dart:async';
import 'dart:convert';
import 'dart:math';

// Flutter retains this compatibility import across supported SDK versions.
// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_tts/flutter_tts.dart';

import 'game.dart';
import 'homestead.dart';
import 'home_upgrade_view.dart';
import 'water_system.dart';
import 'farm_upgrade_view.dart';
import 'farm_upgrades.dart';
import 'well_upgrade_view.dart';
import 'outing_views.dart';
import 'journey_view.dart';
import 'journey_history.dart';
import 'fence_layer.dart';
import 'irrigation_layer.dart';
import 'fence_geometry.dart';
import 'fence_cleanup_dialog.dart';
import 'road_service.dart';
import 'road_permission.dart';

const pine = Color(0xff294b32),
    cream = Color(0xfffff3d6),
    orange = Color(0xffdc702e),
    grass = Color(0xff9ead59);
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) await BrowserContextMenu.disableContextMenu();
  runApp(const HearthApp());
}

class HearthApp extends StatelessWidget {
  const HearthApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
    title: 'Grow the Distance',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: pine, surface: cream),
      scaffoldBackgroundColor: const Color(0xfff8f3e5),
      fontFamily: 'monospace',
      textTheme: const TextTheme(
        bodyMedium: TextStyle(color: pine, fontSize: 14, height: 1.5),
        titleLarge: TextStyle(
          color: pine,
          fontSize: 25,
          fontWeight: FontWeight.w900,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: orange,
          foregroundColor: cream,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: pine,
          padding: const EdgeInsets.all(17),
          side: const BorderSide(color: pine, width: 1.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
      ),
    ),
    home: const Village(),
  );
}

class Village extends StatefulWidget {
  const Village({super.key});
  @override
  State<Village> createState() => _VillageState();
}

class _VillageState extends State<Village> {
  final g = Game(), mc = MapController(), tts = FlutterTts();
  SharedPreferences? prefs;
  Timer? timer, saveTimer;
  StreamSubscription<Position>? gps;
  int page = 0;
  bool settings = false, admin = false, tiles = true, night = false;
  LatLng? selected;
  Place? focus, fencing;
  Offset stick = Offset.zero;
  double speedMultiplier = 1;
  final roadService = RoadService();
  bool finishingFence = false;
  bool roadLookupConsent = false;
  int collecting = 0, collectTotal = 60;
  Place? collectingPlace;
  (String, String, int)? collectionReward;
  DateTime? collectionEnds;
  Timer? collectionTimer;
  String activity = 'Gentle stretching';
  String collectionActivity = 'Gentle stretching';
  int journeySavedCount = 0;
  int recovery = 60;
  String lastSaved = 'Loading…';
  bool loaded = false;
  int narrative = 0;
  final customDate = TextEditingController();
  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(milliseconds: 200), (_) {
      if (!loaded) return;
      if (g.spoofer && !finishingFence && stick.distance > .05) {
        g.move(
          simulatedStep(
            g.position,
            horizontal: stick.dx,
            vertical: stick.dy,
            multiplier: speedMultiplier,
            seconds: .2,
          ),
        );
      }
      if (DateTime.now().millisecondsSinceEpoch ~/ 1000 != tick) {
        tick = DateTime.now().millisecondsSinceEpoch ~/ 1000;
        g.expireInfiniteResources();
        g.advanceWater();
        g.advanceFarmRisks();
        if (collectingPlace != null) {
          if (!g.inCollectionRange(collectingPlace!)) {
            final hint = g.collectionRangeHint(collectingPlace!);
            cancelCollection();
            g.changed('Collection stopped. $hint');
          } else {
            collecting = max(
              0,
              (collectionEnds!.difference(DateTime.now()).inMilliseconds / 1000)
                  .ceil(),
            );
          }
        }
        if (g.walking && g.journey.length != journeySavedCount && tick % 5 == 0)
          save();
        setState(() {});
      }
    });
  }

  int tick = 0;
  Future<void> load() async {
    prefs = await SharedPreferences.getInstance();
    roadLookupConsent = prefs!.getBool('roadLookupConsent') ?? false;
    var restored = false;
    try {
      final raw = prefs!.getString('village-v1');
      if (raw != null) {
        g.restore(jsonDecode(raw));
        restored = true;
      }
    } catch (_) {
      g.notice =
          'Could not load the previous save. Import a backup in Settings.';
    }
    loaded = true;
    g.addListener(onChange);
    showEventToasts();
    if (restored) unawaited(save());
    setState(() {
      lastSaved = 'Saved on this device';
    });
  }

  void onChange() {
    if (!mounted) return;
    setState(() {});
    showEventToasts();
    saveTimer?.cancel();
    saveTimer = Timer(const Duration(milliseconds: 500), save);
  }

  void showEventToasts() {
    if (g.eventToasts.isEmpty) return;
    final messages = List<String>.of(g.eventToasts);
    g.eventToasts.clear();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final messenger = ScaffoldMessenger.of(context);
      final recent = messages.length > 5
          ? messages.sublist(messages.length - 5)
          : messages;
      if (recent.length != messages.length) {
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              '${messages.length - recent.length} earlier events are in the village log.',
            ),
          ),
        );
      }
      for (final message in recent) {
        messenger.showSnackBar(
          SnackBar(
            content: Text(message),
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 6),
            showCloseIcon: true,
          ),
        );
      }
    });
  }

  Future<void> save() async {
    if (!loaded) return;
    final count = g.journey.length;
    final ok = await prefs!.setString('village-v1', jsonEncode(g.json()));
    if (ok) journeySavedCount = count;
    if (mounted)
      setState(
        () => lastSaved = ok
            ? 'Saved on this device'
            : 'Save failed — export a backup',
      );
  }

  @override
  void dispose() {
    timer?.cancel();
    saveTimer?.cancel();
    collectionTimer?.cancel();
    gps?.cancel();
    g.removeListener(onChange);
    tts.stop();
    roadService.dispose();
    super.dispose();
  }

  Future<void> realGps() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        g.changed('Enable device location services first.');
        return;
      }
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied)
        p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied ||
          p == LocationPermission.deniedForever) {
        g.changed(
          'Location permission is required. You can use Admin simulation instead.',
        );
        return;
      }
      g.spoofer = false;
      stick = Offset.zero;
      gps?.cancel();
      final pos = await Geolocator.getCurrentPosition();
      g.teleport(LatLng(pos.latitude, pos.longitude));
      recenter();
      gps =
          Geolocator.getPositionStream(
            locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.high,
              distanceFilter: 3,
            ),
          ).listen(
            (v) {
              if (!g.spoofer && !finishingFence && v.accuracy <= 50)
                g.move(LatLng(v.latitude, v.longitude));
            },
            onError: (_) => g.changed(
              'GPS unavailable. Check permissions or use the simulator.',
            ),
          );
      g.changed(
        'Real GPS connected. Browser tracking requires this page to stay active.',
      );
    } catch (_) {
      g.changed(
        'GPS could not connect. Use HTTPS and allow location, or enable the simulator.',
      );
    }
  }

  void recenter() {
    try {
      mc.move(g.position, 17);
    } catch (_) {}
  }

  void teleportFromMap(LatLng p) {
    if (!g.spoofer || finishingFence) return;
    stick = Offset.zero;
    selected = p;
    focus = null;
    g.teleport(p);
    recenter();
  }

  String time(int ms) =>
      '${DateTime.fromMillisecondsSinceEpoch(ms).toLocal().day}/${DateTime.fromMillisecondsSinceEpoch(ms).toLocal().month} · ${DateTime.fromMillisecondsSinceEpoch(ms).toLocal().hour.toString().padLeft(2, '0')}:${DateTime.fromMillisecondsSinceEpoch(ms).toLocal().minute.toString().padLeft(2, '0')}';
  Widget btn(
    String text,
    VoidCallback? action, {
    bool secondary = false,
    IconData? icon,
  }) => secondary
      ? OutlinedButton(onPressed: action, child: Text(text))
      : FilledButton(
          onPressed: action,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 19),
                const SizedBox(width: 9),
              ],
              Text(text),
            ],
          ),
        );
  Widget panel(Widget child, {EdgeInsets padding = const EdgeInsets.all(22)}) =>
      Container(
        padding: padding,
        decoration: BoxDecoration(
          color: cream,
          border: Border.all(color: pine.withValues(alpha: .22)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Material(color: Colors.transparent, child: child),
      );
  Widget heading(String text, [String? sub]) => Padding(
    padding: const EdgeInsets.only(bottom: 20),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(text, style: Theme.of(context).textTheme.titleLarge),
        if (sub != null)
          Text(sub, style: TextStyle(color: pine.withValues(alpha: .65))),
      ],
    ),
  );
  Widget tag(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: const Color(0xffe7eacb),
      borderRadius: BorderRadius.circular(4),
    ),
    child: Text(
      text,
      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
    ),
  );
  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width > 1000;
    return Scaffold(
      body: !loaded
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: Column(
                children: [
                  Container(
                    height: 76,
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    decoration: const BoxDecoration(color: pine),
                    child: Row(
                      children: [
                        const Icon(Icons.spa, color: Color(0xffe7bb65)),
                        const SizedBox(width: 12),
                        Text(
                          'HEARTHSTRIDE',
                          style: TextStyle(
                            color: cream,
                            fontSize: wide ? 20 : 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: wide ? 2 : 1,
                          ),
                        ),
                        if (wide) ...[
                          const SizedBox(width: 26),
                          const Text(
                            'A little walk. A little wonder.',
                            style: TextStyle(
                              color: Color(0xffc9d3b0),
                              fontSize: 12,
                            ),
                          ),
                        ],
                        const Spacer(),
                        if (wide)
                          Text(
                            time(g.now),
                            style: const TextStyle(color: cream, fontSize: 12),
                          ),
                        IconButton(
                          tooltip: 'Settings',
                          onPressed: () => setState(() => settings = !settings),
                          icon: const Icon(
                            Icons.settings_outlined,
                            color: cream,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Row(
                      children: [
                        if (wide) navigation(),
                        Expanded(
                          child: Column(
                            children: [
                              Expanded(
                                child: settings
                                    ? settingsView()
                                    : IndexedStack(
                                        index: page,
                                        children: [
                                          homeView(),
                                          mapView(),
                                          bagView(),
                                          journal(),
                                        ],
                                      ),
                              ),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 18,
                                  vertical: 10,
                                ),
                                color: const Color(0xffe5e8cd),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        g.notice,
                                        maxLines: 3,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(fontSize: 12),
                                      ),
                                    ),
                                    if (admin)
                                      TextButton(
                                        onPressed: showFarmEvents,
                                        child: const Text('Random effect'),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (wide && g.spoofer)
                          SizedBox(
                            width: 270,
                            child: SingleChildScrollView(
                              padding: const EdgeInsets.all(18),
                              child: simulator(),
                            ),
                          ),
                      ],
                    ),
                  ),
                  if (!wide && !settings)
                    NavigationBar(
                      backgroundColor: cream,
                      selectedIndex: page,
                      onDestinationSelected: (v) => setState(() => page = v),
                      destinations: const [
                        NavigationDestination(
                          icon: Icon(Icons.cottage_outlined),
                          label: 'Home',
                        ),
                        NavigationDestination(
                          icon: Icon(Icons.map_outlined),
                          label: 'Map',
                        ),
                        NavigationDestination(
                          icon: Icon(Icons.backpack_outlined),
                          label: 'Bag',
                        ),
                        NavigationDestination(
                          icon: Icon(Icons.menu_book),
                          label: 'Journal',
                        ),
                      ],
                    ),
                ],
              ),
            ),
    );
  }

  Widget navigation() => Container(
    width: 206,
    color: const Color(0xfff0eddc),
    padding: const EdgeInsets.all(18),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text(
          'YOUR LITTLE WORLD',
          style: TextStyle(fontSize: 10, letterSpacing: 1.2),
        ),
        const SizedBox(height: 22),
        for (final item in [
          (Icons.cottage_outlined, 'Homestead'),
          (Icons.map_outlined, 'Neighbourhood'),
          (Icons.backpack_outlined, 'Your bag'),
          (Icons.menu_book, 'Village journal'),
        ].indexed)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Material(
              color: Colors.transparent,
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                selected: page == item.$1 && !settings,
                selectedTileColor: const Color(0xffdde3bf),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6),
                ),
                leading: Icon(item.$2.$1, color: pine),
                title: Text(
                  item.$2.$2,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () => setState(() {
                  page = item.$1;
                  settings = false;
                }),
              ),
            ),
          ),
        const Spacer(),
        tag(g.spoofer ? 'SIMULATED GPS' : 'GPS NOT SIMULATED'),
        const SizedBox(height: 12),
        Text(lastSaved, style: const TextStyle(fontSize: 10)),
        const SizedBox(height: 8),
        const Text('Prototype · v0.16', style: TextStyle(fontSize: 10)),
      ],
    ),
  );
  Widget resourceOverview() => panel(
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Your resources',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        for (final (title, items) in [
          (
            'Supplies',
            [
              ('timber', 'Timber', '🪵'),
              ('stone', 'Stone', '🪨'),
              ('seeds', 'Seeds', '🌱'),
              ('water', 'Water', '💧'),
              for (final project in HomeProject.values)
                (
                  project.resource,
                  project.resource[0].toUpperCase() +
                      project.resource.substring(1),
                  project.icon,
                ),
            ],
          ),
          (
            'Harvest',
            [
              for (final crop in Crop.values)
                (crop.stock, crop.label, crop.icon),
            ],
          ),
        ]) ...[
          Text(
            title,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final (key, label, icon) in items)
                Container(
                  width: 112,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xfff8edd2),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: pine.withValues(alpha: .13)),
                  ),
                  child: Row(
                    children: [
                      Text(icon, style: const TextStyle(fontSize: 17)),
                      const SizedBox(width: 7),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${g.bag[key] ?? 0}',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            Text(label, style: const TextStyle(fontSize: 11)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          if (title == 'Supplies') const SizedBox(height: 12),
        ],
      ],
    ),
  );

  Widget homeView() => SingleChildScrollView(
    padding: const EdgeInsets.all(28),
    child: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 950),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: heading(
                    g.home?.name == null || g.home?.name == 'Home'
                        ? 'Your farmhouse in Bellmere'
                        : g.home!.name,
                    'A house, a key, and a name you’ve never heard.',
                  ),
                ),
                tag('CHAPTER 0${chapter + 1}'),
              ],
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Stack(
                children: [
                  Image.asset(
                    'assets/homestead.png',
                    height: 310,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.none,
                  ),
                  Positioned(
                    left: 18,
                    top: 18,
                    child: panel(
                      const Text(
                        'Your homestead',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      padding: const EdgeInsets.all(12),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            LayoutBuilder(
              builder: (c, s) {
                final cards = [
                  panel(
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'A LITTLE FRESH AIR',
                          style: TextStyle(fontSize: 10, letterSpacing: 1.5),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          g.walking
                              ? '${(g.outingDistance / 1000).toStringAsFixed(2)} km this outing'
                              : 'Your next wander awaits',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 12),
                        LinearProgressIndicator(
                          value: g.walking
                              ? min(1, g.outingDistance / max(1, g.outingGoal))
                              : 0,
                          color: grass,
                          backgroundColor: const Color(0xffdedfbd),
                          minHeight: 8,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Suggested distance · ${g.walking ? g.outingGoal : g.goal} m',
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton(
                                onPressed: () => setState(() => page = 3),
                                child: const Text(
                                  'Continue story',
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () => openWalk(free: true),
                                child: const Text(
                                  'Free walk',
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  panel(
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'THE NEXT CHAPTER',
                          style: TextStyle(fontSize: 10, letterSpacing: 1.5),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          !g.homeSet
                              ? 'Put down roots'
                              : g.places.where((p) => p.kind == 'farm').isEmpty
                              ? 'A patch of your own'
                              : g.harvests == 0
                              ? 'Your first harvest'
                              : 'Restore the village well',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          !g.homeSet
                              ? 'Choose a place on the map to call home.'
                              : 'Gather, grow, and bring this quiet village back to life.',
                        ),
                        const SizedBox(height: 12),
                        btn(
                          'Open village journal',
                          () => setState(() => page = 3),
                          secondary: true,
                        ),
                      ],
                    ),
                  ),
                ];
                return s.maxWidth > 650
                    ? Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(child: cards[0]),
                          const SizedBox(width: 18),
                          Expanded(child: cards[1]),
                        ],
                      )
                    : Column(
                        children: [
                          cards[0],
                          const SizedBox(height: 15),
                          cards[1],
                        ],
                      );
              },
            ),
            const SizedBox(height: 20),
            if (g.home case final home?) ...[
              btn(
                'Home upgrades',
                () => openHomeUpgrades(home),
                secondary: true,
              ),
              const SizedBox(height: 8),
            ],
            PetSlot(game: g),
            const SizedBox(height: 12),
            resourceOverview(),
            const SizedBox(height: 26),
            heading(
              'Around your village',
              'Your buildings keep growing while you’re away.',
            ),
            if (g.places.isEmpty)
              panel(
                Row(
                  children: [
                    const Icon(Icons.add_home_outlined, size: 32),
                    const SizedBox(width: 16),
                    Expanded(
                      child: const Text('Your story begins with a home.'),
                    ),
                    btn('Open map', () => setState(() => page = 1)),
                  ],
                ),
              ),
            for (final p in g.places)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: placeCard(p),
              ),
          ],
        ),
      ),
    ),
  );
  Widget placeCard(Place p) => panel(
    Row(
      children: [
        Text(
          p.kind == 'home'
              ? '⌂'
              : p.kind == 'farm'
              ? '🥕'
              : '🪣',
          style: const TextStyle(fontSize: 30),
        ),
        const SizedBox(width: 15),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(
                p.kind == 'home'
                    ? 'A place to begin again'
                    : '${p.available(g.now)} / ${p.storage} ready · ${meters(g.position, p.pos).round()} m away',
                style: const TextStyle(fontSize: 12),
              ),
            ],
          ),
        ),
        btn(
          'Visit',
          () => setState(() {
            page = 1;
            focus = p;
            selected = p.pos;
            recenter();
          }),
          secondary: true,
        ),
      ],
    ),
  );
  Future<void> showFarmEvents() async {
    final targets = g.places
        .where(
          (place) =>
              place.kind == 'well' || (place.kind == 'farm' && place.area > 0),
        )
        .toList();
    var target = targets.contains(focus)
        ? focus!
        : targets.where((place) => place.kind == 'farm').firstOrNull ??
              targets.firstOrNull;
    await showDialog<void>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, update) {
          final place = target;
          final isWell = place?.kind == 'well';
          void trigger({FarmEvent? farmEvent, WellEvent? wellEvent}) {
            if (place == null) return;
            Navigator.pop(context);
            if (isWell) {
              g.triggerWellEvent(place, event: wellEvent);
            } else {
              g.triggerFarmEvent(place, event: farmEvent);
            }
          }

          return AlertDialog(
            title: const Text('Trigger a village event'),
            content: SizedBox(
              width: 360,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (targets.isEmpty)
                      const Text(
                        'Build a well or fence a farm to trigger building events.',
                      )
                    else ...[
                      DropdownButton<Place>(
                        isExpanded: true,
                        value: place,
                        items: [
                          for (final option in targets)
                            DropdownMenuItem(
                              value: option,
                              child: Text(
                                option.name,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                        ],
                        onChanged: (value) => update(() => target = value),
                      ),
                      FilledButton(
                        onPressed: trigger,
                        child: const Text('Random event'),
                      ),
                      if (isWell)
                        for (final event in WellEvent.values)
                          TextButton(
                            onPressed: () => trigger(wellEvent: event),
                            child: Text(event.title),
                          )
                      else
                        for (final event in FarmEvent.values)
                          TextButton(
                            onPressed: () => trigger(farmEvent: event),
                            child: Text(event.title),
                          ),
                    ],
                    const Divider(),
                    const Text('Find a pet'),
                    if (g.home == null || g.pet != null)
                      Text(
                        g.pet != null
                            ? 'The Home pet slot is occupied.'
                            : 'Set your home first.',
                      )
                    else
                      Wrap(
                        spacing: 6,
                        children: [
                          for (final pet in [...VillagePet.values, null])
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                                g.findPet(species: pet);
                              },
                              child: Text(
                                pet == null
                                    ? 'Random pet'
                                    : '${pet.emoji} ${pet.label}',
                              ),
                            ),
                        ],
                      ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<String?> nameNewFarm() {
    var name = '';
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Name your farm'),
        content: TextFormField(
          autofocus: true,
          maxLength: 32,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            labelText: 'Farm name',
            hintText: 'Carrot Farm',
          ),
          onChanged: (value) => name = value,
          onFieldSubmitted: (value) => Navigator.pop(context, value),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, name),
            child: const Text('Build farm'),
          ),
        ],
      ),
    );
  }

  Future<void> buildFromMenu(String kind) async {
    if (g.recording || finishingFence) return;
    if (kind == 'fence') {
      final farms =
          g.places.where((p) => p.kind == 'farm' || p.kind == 'home').toList()
            ..sort(
              (a, b) => meters(
                g.position,
                a.pos,
              ).compareTo(meters(g.position, b.pos)),
            );
      if (farms.isEmpty) {
        g.changed('Build a farm before adding a fence / wall.');
        return;
      }
      final chosen = await showDialog<Place>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Fence / wall'),
          content: SizedBox(
            width: 360,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Choose the farm or home you want to fence. Then walk its boundary.',
                  ),
                  const SizedBox(height: 12),
                  for (final farm in farms)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: TextButton(
                        onPressed: () => Navigator.pop(c, farm),
                        child: Text(
                          '${farm.name} · ${meters(g.position, farm.pos).round()} m away',
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('Cancel'),
            ),
          ],
        ),
      );
      if (chosen != null && mounted && g.places.contains(chosen)) {
        if (chosen.kind == 'home') {
          openHomeUpgrades(chosen);
        } else {
          openFarmUpgrades(chosen);
        }
      }
      return;
    }
    final location = selected ?? g.position;
    if (kind == 'home') {
      g.setHome(location);
      return;
    }
    final name = kind == 'farm' ? await nameNewFarm() : null;
    if (!mounted || (kind == 'farm' && name == null)) return;
    if (g.build(
      kind == 'cropWell' ? 'well' : kind,
      location,
      useCrops: kind == 'cropWell',
      farmName: name,
    )) {
      setState(() {
        focus = g.places.last;
        selected = location;
      });
    }
  }

  void openFarmUpgrades(Place farm) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (routeContext) => FarmUpgradeView(
          game: g,
          farm: farm,
          chooseCrop: () => chooseCrop(farm),
          buildFence: () {
            Navigator.pop(routeContext);
            startFence(farm);
          },
          neatenFence: () => neatenExistingFence(farm),
          startPipe: (well) {
            if (g.startPipeWalk(well, farm)) {
              Navigator.pop(routeContext);
              setState(() {
                page = 1;
                focus = farm;
                selected = farm.pos;
              });
            }
          },
        ),
      ),
    );
  }

  void openWellUpgrades(Place well) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (routeContext) => WellUpgradeView(
          game: g,
          well: well,
          startWalk: (farm) {
            Navigator.pop(routeContext);
            if (g.startPipeWalk(well, farm)) {
              setState(() {
                page = 1;
                focus = farm;
                selected = farm.pos;
              });
            }
          },
        ),
      ),
    );
  }

  void openHomeUpgrades(Place home) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (routeContext) => HomeUpgradeView(
          home: home,
          game: g,
          buildFence: () {
            Navigator.pop(routeContext);
            startFence(home);
          },
        ),
      ),
    );
  }

  void startFence(Place farm) {
    setState(() {
      focus = farm;
      selected = farm.pos;
      page = 1;
      settings = false;
    });
    if (meters(g.position, farm.pos) > 150) {
      g.changed('Move within 150 m of ${farm.name} to build its fence / wall.');
      return;
    }
    fencing = farm;
    g.beginFence();
  }

  Widget mapView() => Column(
    children: [
      Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Your neighbourhood',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900),
                  ),
                  Text(
                    g.recording
                        ? 'Building fence · ${fenceLength(g.fence).round()} m'
                        : g.walking
                        ? '${(g.outingDistance / 1000).toStringAsFixed(2)} km · ${g.elapsed ~/ 60}:${(g.elapsed % 60).toString().padLeft(2, '0')} · ${g.paused
                              ? 'Paused'
                              : g.freeWalk
                              ? 'Free walk'
                              : 'Story walk'}'
                        : 'Pick a place. Make it part of your story.',
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
            PopupMenuButton<String>(
              tooltip: 'Build',
              enabled: !g.recording && !finishingFence,
              onSelected: buildFromMenu,
              itemBuilder: (c) => [
                PopupMenuItem<String>(
                  enabled: false,
                  child: Text(
                    selected == null
                        ? 'At your current location'
                        : 'At the selected map point',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
                if (!g.homeSet)
                  const PopupMenuItem(
                    value: 'home',
                    child: Text('Set home here'),
                  ),
                PopupMenuItem(
                  value: 'farm',
                  enabled: g.homeSet,
                  child: const Text('Farm · 5 timber / 3 stone'),
                ),
                PopupMenuItem(
                  value: 'well',
                  enabled: g.homeSet,
                  child: const Text('Well · 8 timber / 6 stone'),
                ),
                if (g.homeSet && g.surplusCrops >= 10)
                  const PopupMenuItem(
                    value: 'cropWell',
                    child: Text('Well · 4 timber / 6 stone / 10 crops'),
                  ),
                const PopupMenuDivider(),
                PopupMenuItem(
                  value: 'fence',
                  enabled: g.places.any((p) => p.kind == 'farm'),
                  child: Text(
                    g.places.any((p) => p.kind == 'farm')
                        ? 'Fence / wall'
                        : 'Fence / wall · build a farm first',
                  ),
                ),
                if (!g.homeSet)
                  const PopupMenuItem<String>(
                    enabled: false,
                    child: Text(
                      'Set your home to unlock buildings.',
                      style: TextStyle(fontSize: 11),
                    ),
                  ),
              ],
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 11,
                ),
                decoration: BoxDecoration(
                  color: g.recording ? grass : orange,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.construction, size: 18, color: cream),
                    SizedBox(width: 6),
                    Text(
                      'Build',
                      style: TextStyle(
                        color: cream,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (g.spoofer)
              IconButton(
                tooltip: 'Teleport',
                onPressed: finishingFence
                    ? null
                    : () {
                        final target = selected;
                        if (target == null) {
                          g.changed(
                            'Select a spot on the map to teleport there.',
                          );
                        } else {
                          teleportFromMap(target);
                        }
                      },
                icon: const Icon(Icons.bolt, color: pine),
              ),
            IconButton(
              tooltip: 'Centre on player',
              onPressed: recenter,
              icon: const Icon(Icons.my_location),
            ),
            IconButton(
              tooltip: 'Connect real GPS',
              onPressed: realGps,
              icon: const Icon(Icons.gps_fixed),
            ),
          ],
        ),
      ),
      Expanded(
        child: Stack(
          children: [
            Container(color: const Color(0xffdce5bd)),
            FlutterMap(
              mapController: mc,
              options: MapOptions(
                initialCenter: g.position,
                initialZoom: 16.5,
                onSecondaryTap: (tap, p) => teleportFromMap(p),
                onTap: (tap, p) => setState(() {
                  selected = p;
                  focus = null;
                }),
              ),
              children: [
                if (tiles)
                  TileLayer(
                    urlTemplate:
                        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.hearthstride.app',
                  ),
                PolygonLayer(
                  polygons: [
                    for (final p in g.places)
                      if (p.fence.length > 2)
                        Polygon(
                          points: p.fence,
                          color:
                              (p.markerColor == null
                                      ? grass
                                      : Color(p.markerColor!))
                                  .withValues(alpha: .35),
                          borderColor: const Color(0xff86613b),
                          borderStrokeWidth: 0,
                        ),
                  ],
                ),
                GrowingFields(
                  g.places.where((p) => p.kind == 'farm' && p.fence.length > 2),
                  g.now,
                ),
                PolylineLayer(
                  polylines: [
                    if (g.route.length > 1 && !g.recording)
                      Polyline(points: g.route, color: orange, strokeWidth: 4),
                  ],
                ),
                if (g.pipeWalk case final pipe?)
                  CircleLayer(
                    circles: [
                      for (final sample in pipe.remaining)
                        CircleMarker(
                          point: sample.point,
                          radius: 3,
                          color: const Color(0xff20c6df),
                          borderColor: const Color(0xff00465b),
                          borderStrokeWidth: 1,
                        ),
                    ],
                  ),
                FenceLayer(
                  completed: [
                    for (final p in g.places)
                      if (p.fence.length > 2) p.fence,
                  ],
                  tiers: [
                    for (final p in g.places)
                      if (p.fence.length > 2)
                        p.improvements.fenceDamaged
                            ? 0
                            : p.improvements.level(FarmUpgrade.fence),
                  ],
                  active: List.of(g.fence),
                ),
                IrrigationLayer(
                  visible: page == 1 && !settings,
                  links: [
                    for (final farm in g.places)
                      for (final pipe in farm.pipes)
                        if (g.pipeSource(farm, pipe) case final well?
                            when pipe.installed)
                          (
                            well: well.markerPosition,
                            farm: farm.markerPosition,
                            flowing: pipe.enabled && well.available(g.now) > 0,
                          ),
                  ],
                ),
                PolylineLayer(
                  polylines: [
                    if (g.pipeWalk case final pipe? when pipe.path.length > 1)
                      Polyline(
                        points: List.of(pipe.path),
                        color: const Color(0xff49d5f1),
                        strokeWidth: 5,
                        borderColor: const Color(0xff00465b),
                        borderStrokeWidth: 2,
                      ),
                  ],
                ),
                MarkerLayer(
                  markers: [
                    for (final p in g.places)
                      Marker(
                        point: p.markerPosition,
                        width: 105,
                        height: 90,
                        child: GestureDetector(
                          onTap: () => setState(() {
                            focus = p;
                            selected = p.pos;
                          }),
                          child: Column(
                            children: [
                              Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                      color: p.markerColor == null
                                          ? cream
                                          : Color(p.markerColor!),
                                      border: Border.all(color: pine, width: 2),
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: Text(
                                      p.icon,
                                      style: const TextStyle(fontSize: 25),
                                    ),
                                  ),
                                  if (p.kind == 'farm' && p.pipeActive)
                                    Positioned(
                                      top: -5,
                                      right: -5,
                                      child: Tooltip(
                                        message: p.pipeOn
                                            ? 'Direct watering connected'
                                            : 'Pipes turned off',
                                        child: Container(
                                          padding: const EdgeInsets.all(2),
                                          decoration: BoxDecoration(
                                            color: p.pipeOn
                                                ? const Color(0xff14617a)
                                                : const Color(0xff66726d),
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: cream,
                                              width: 2,
                                            ),
                                          ),
                                          child: const Icon(
                                            Icons.water_drop,
                                            size: 13,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              Container(
                                color:
                                    p.kind == 'farm' && p.available(g.now) > 0
                                    ? const Color(0xffffdc85)
                                    : cream,
                                child: Text(
                                  p.kind == 'farm' && p.available(g.now) > 0
                                      ? 'Harvest ready'
                                      : p.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    if (selected != null)
                      Marker(
                        point: selected!,
                        width: 28,
                        height: 40,
                        child: const IgnorePointer(
                          child: Icon(
                            Icons.location_on,
                            color: orange,
                            size: 35,
                          ),
                        ),
                      ),
                    Marker(
                      point: g.position,
                      width: 30,
                      height: 30,
                      child: IgnorePointer(
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0xff3a94d4),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 4),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0x663a94d4),
                                spreadRadius: 10,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    if (g.pet case final pet?)
                      if ((g.petFollows
                              ? g.position
                              : (g.petFarm ?? g.home)?.markerPosition)
                          case final petPosition?)
                        Marker(
                          point: petPosition,
                          width: 32,
                          height: 32,
                          child: IgnorePointer(
                            child: Transform.translate(
                              offset: Offset(g.petFollows ? -24 : 26, -18),
                              child: Tooltip(
                                message: g.petFollows
                                    ? '${pet.label} following you'
                                    : pet.label,
                                child: Container(
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color: cream,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: pine),
                                  ),
                                  child: Text(
                                    pet.emoji,
                                    style: const TextStyle(fontSize: 18),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                  ],
                ),
                Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    color: cream,
                    child: const Text(
                      '© OpenStreetMap contributors',
                      style: TextStyle(fontSize: 10),
                      softWrap: true,
                    ),
                  ),
                ),
              ],
            ),
            Positioned(
              top: 12,
              left: 12,
              child: tag(g.spoofer ? 'SIMULATOR ACTIVE' : 'REAL LOCATION MODE'),
            ),
            if (!tiles)
              const Positioned(
                top: 60,
                left: 16,
                child: Text(
                  'Offline canvas · turn on street tiles in Settings',
                ),
              ),
            if (g.spoofer && MediaQuery.sizeOf(context).width <= 1000)
              Positioned(
                right: 12,
                bottom: 30,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Material(
                      color: cream,
                      borderRadius: BorderRadius.circular(6),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: DropdownButton<double>(
                          value: speedMultiplier,
                          underline: const SizedBox.shrink(),
                          items:
                              ({
                                    1.0,
                                    2.0,
                                    5.0,
                                    10.0,
                                    20.0,
                                    speedMultiplier,
                                  }.toList()..sort())
                                  .map(
                                    (v) => DropdownMenuItem(
                                      value: v,
                                      child: Text('${v.round()}× speed'),
                                    ),
                                  )
                                  .toList(),
                          onChanged: (v) =>
                              setState(() => speedMultiplier = v!),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    joystick(),
                  ],
                ),
              ),
            if (collectingPlace != null || collectionReward != null)
              Positioned.fill(
                child: Container(
                  color: pine.withValues(alpha: .9),
                  child: Center(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(12),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 360),
                        child: panel(
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              HarvestBasket(
                                progress: collectionReward != null
                                    ? 1
                                    : 1 - collecting / collectTotal,
                                icon:
                                    collectionReward?.$2 ??
                                    (collectingPlace?.kind == 'well'
                                        ? '💧'
                                        : collectingPlace?.crop.icon ?? '🌱'),
                              ),
                              if (collectionReward case final reward?) ...[
                                Text(
                                  '+${reward.$3} ${reward.$1}',
                                  style: const TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const Text('Added to your trail bag.'),
                                btn(
                                  'Done',
                                  () => setState(() => collectionReward = null),
                                ),
                              ] else ...[
                                Text(
                                  'Collecting ${collectingPlace!.resource}',
                                  style: const TextStyle(
                                    fontSize: 21,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  clockTime(collecting),
                                  style: const TextStyle(
                                    fontSize: 42,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                CollectionRoutine(
                                  activity: collectionActivity,
                                  remaining: collecting,
                                  total: collectTotal,
                                ),
                                const SizedBox(height: 12),
                                LinearProgressIndicator(
                                  value: 1 - collecting / collectTotal,
                                  color: grass,
                                ),
                                const SizedBox(height: 12),
                                btn(
                                  'Cancel collection',
                                  () => setState(cancelCollection),
                                  secondary: true,
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
      ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 260),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              mapActions(),
              if (g.walking &&
                  !g.recording &&
                  (selected != null || focus != null))
                Align(
                  alignment: Alignment.centerLeft,
                  child: btn('Finish outing', finishOuting, secondary: true),
                ),
            ],
          ),
        ),
      ),
    ],
  );
  Future<void> finishFence() async {
    final target = fencing;
    if (target == null || finishingFence) return;
    if (findFenceBoundary(g.fence, target.pos) == null) {
      g.finishFence(target);
      return;
    }
    final path = List<LatLng>.of(g.fence);
    setState(() {
      finishingFence = true;
      stick = Offset.zero;
    });
    g.changed(
      'Tidying your outer boundary${g.snapFencesToRoads ? ' and checking nearby road centres' : ''}…',
    );
    try {
      var useRoads = g.snapFencesToRoads;
      if (useRoads && !roadLookupConsent) {
        final accepted = await askForRoadData(context);
        if (!mounted) return;
        if (accepted) {
          roadLookupConsent = true;
          await prefs?.setBool('roadLookupConsent', true);
        } else {
          useRoads = false;
        }
      }
      // No road request happens before the user grants destination-specific
      // permission. Permission is device-local and is never imported in a save.
      final roads = useRoads && roadLookupConsent
          ? await roadService.near(path)
          : const RoadData([]);
      if (!mounted ||
          !g.recording ||
          fencing != target ||
          !g.places.contains(target))
        return;
      g.finishFence(
        target,
        roads: roads.roads,
        roadNote: !useRoads && g.snapFencesToRoads
            ? 'Road snapping skipped.'
            : roads.available
            ? null
            : 'Road data unavailable; offline fence cleanup used.',
      );
    } finally {
      if (mounted) setState(() => finishingFence = false);
    }
  }

  Future<void> neatenExistingFence(Place farm) async {
    final strength = await showFenceCleanup(
      context,
      List.of(farm.fence),
      farm.pos,
    );
    if (!mounted || strength == null || !g.places.contains(farm)) return;
    g.applyFenceCleanup(farm, maxDeviation: strength);
  }

  void cancelCollection() {
    collectionTimer?.cancel();
    collectingPlace = null;
    collecting = 0;
  }

  void beginCollection(Place place) {
    collectionTimer?.cancel();
    final duration = Duration(seconds: recovery);
    setState(() {
      collectingPlace = place;
      collectTotal = recovery;
      collectionActivity = activity;
      collecting = recovery;
      collectionEnds = DateTime.now().add(duration);
      collectionReward = null;
    });
    collectionTimer = Timer(duration, () {
      if (!mounted || !identical(collectingPlace, place)) return;
      cancelCollection();
      final amount = g.collect(place);
      if (amount > 0)
        setState(
          () => collectionReward = (
            place.resource,
            place.kind == 'well'
                ? '💧'
                : place.kind == 'home'
                ? '🌱'
                : place.crop.icon,
            amount,
          ),
        );
    });
  }

  Future<void> chooseCrop(Place farm) async {
    if (!g.inFarm(farm)) return;
    final chosen = await showDialog<Crop>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Choose a crop'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Switching crops replaces the current planting and restarts growth.',
              ),
              for (final crop in Crop.values)
                ListTile(
                  leading: Text(crop.icon),
                  title: Text(crop.label),
                  subtitle: Text(
                    '${crop.days} days to full yield · ${max(1, (farm.area / 40 * crop.yieldFactor).round())} crops',
                  ),
                  trailing: crop == farm.crop ? const Icon(Icons.check) : null,
                  enabled: crop != farm.crop,
                  onTap: () => Navigator.pop(c, crop),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c),
            child: const Text('Keep current crop'),
          ),
        ],
      ),
    );
    if (mounted && chosen != null) g.plant(farm, chosen);
  }

  void finishOuting() {
    final outing = g.finishWalk();
    if (outing != null) showOuting(outing);
  }

  void showOuting(OutingSummary outing) {
    String items(Map<String, int> stock) => stock.isEmpty
        ? 'None'
        : stock.entries.map((e) => '${e.value} ${e.key}').join(', ');
    final hasFarm = g.places.any((p) => p.kind == 'farm');
    final hasWell = g.places.any((p) => p.kind == 'well');
    final timberNeeded = hasFarm ? (g.surplusCrops >= 10 ? 4 : 8) : 5;
    final stoneNeeded = hasFarm ? 6 : 3;
    showDialog<void>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, refresh) => AlertDialog(
          title: const Text('Outing summary'),
          content: SizedBox(
            width: 420,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${(outing.distance / 1000).toStringAsFixed(2)} km · ${clockTime(outing.seconds)}',
                    style: const TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '${outing.distance.round()} / ${outing.goal} m suggested distance',
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: (outing.distance / max(1, outing.goal)).clamp(
                      0.0,
                      1.0,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Discoveries (${outing.discoveries}) · ${items(outing.found)}',
                  ),
                  Text('Collected · ${items(outing.harvested)}'),
                  const SizedBox(height: 12),
                  Text(
                    hasFarm && hasWell
                        ? 'Your farm and well are built.'
                        : '${hasFarm ? 'Well' : 'Farm'} supplies · ${g.bag['timber']} / $timberNeeded timber and ${g.bag['stone']} / $stoneNeeded stone${hasFarm && g.surplusCrops >= 10 ? ' with 10 crops' : ''}',
                  ),
                  const Divider(height: 27),
                  const Text(
                    'How did this outing feel?',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  if (g.lastFeedback == null)
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final (answer, label) in [
                          (WalkFeedback.easy, 'Easy'),
                          (WalkFeedback.comfortable, 'Comfortable'),
                          (WalkFeedback.tooMuch, 'Too much'),
                        ])
                          btn(label, () {
                            g.recordFeedback(outing, answer);
                            refresh(() {});
                          }, secondary: true),
                      ],
                    ),
                  Text('Next suggested outing · ${g.goal} m'),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('Done'),
            ),
          ],
        ),
      ),
    );
  }

  Widget mapActions() {
    if (g.pipeWalk case final pipe?)
      return Wrap(
        spacing: 10,
        runSpacing: 6,
        children: [
          Text(
            pipe.perimeterReady
                ? 'Head toward an earlier section of pipe to connect.'
                : pipe.arrived
                ? 'Follow the farm fence to lay the pipe.'
                : 'Walk from the well to ${pipe.farm.name}',
          ),
          btn('Finish pipe', () => g.finishPipeWalk()),
          btn('Cancel pipe walk', () {
            g.cancelPipeWalk();
            g.changed('Pipe walk cancelled. Restart at the well.');
          }, secondary: true),
        ],
      );
    if (g.recording)
      return Wrap(
        spacing: 10,
        runSpacing: 8,
        children: [
          btn(
            finishingFence ? 'Tidying fence…' : 'Finish fence',
            finishingFence ? null : finishFence,
          ),
          const Text(
            'Finish near any older fence section. Lead-ins are discarded.',
            style: TextStyle(fontSize: 11),
          ),
          btn(
            'Cancel fence',
            finishingFence
                ? null
                : () {
                    g.recording = false;
                    g.fence = [];
                    g.changed('Fence recording cancelled.');
                  },
            secondary: true,
          ),
        ],
      );
    if (focus != null) {
      final p = focus!;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${p.name} · ${p.kind == 'farm' && p.fence.length >= 3 && g.inside(g.position, p.fence) ? 'Inside farm' : '${meters(g.position, p.pos).round()} m to ${p.kind == 'well' ? 'well' : 'entrance'}'}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          if (p.kind != 'home')
            Text(
              p.kind == 'farm' && p.fence.isEmpty
                  ? 'Awaiting a fence'
                  : '${p.available(g.now)} / ${p.storage} ready${p.fence.isNotEmpty ? ' · ${p.area.round()} m² fenced' : ''}',
            ),
          if (p.kind == 'farm' && p.fence.length > 2) ...[
            Text(
              '${p.crop.label} · ${(p.growth(g.now) * 100).floor()}% grown · ${p.yieldCapacity} at full yield',
            ),
            LinearProgressIndicator(value: p.growth(g.now), color: grass),
            Text(
              p.dry
                  ? 'Water needed to resume growth'
                  : p.growth(g.now) >= 1
                  ? p.storage > p.yieldCapacity && g.now < p.storageFullAt
                        ? 'Full crop grown · reserve storing until ${until(p.storageFullAt, g.now)} from now'
                        : 'Full crop grown'
                  : p.available(g.now) > 0
                  ? 'Harvest ready · full yield in ${until(p.fullAt, g.now)}'
                  : 'First harvest in ${until(p.readyAt, g.now)} · full yield in ${until(p.fullAt, g.now)}',
            ),
          ],
          if (p.kind == 'farm' &&
              (p.improvements.fenceDamaged || p.improvements.lostCrops > 0))
            Text(
              p.improvements.fenceDamaged
                  ? 'Fence damaged · ${p.improvements.fenceYieldLoss}% lower yield until repaired.'
                  : '${p.improvements.lostCrops} crops lost this cycle.',
            ),
          if (p.kind == 'farm' && p.fence.length >= 3)
            Text(
              '${p.crop.waterPerHour} water/hour · ${p.dry
                  ? 'growth paused for water'
                  : p.pipeOn
                  ? 'piped water with inventory backup'
                  : p.pipeActive
                  ? 'pipes off · inventory watering'
                  : 'inventory watering'}',
            ),
          if (g.pet case final assignedPet? when p == g.petFarm)
            Text('${assignedPet.emoji} ${assignedPet.farmBonus}'),
          if (p.kind == 'farm' && p.fence.isEmpty)
            const Text('Walk a fence around the farm to start growing crops.'),
          if (p.kind != 'home' &&
              p.available(g.now) > 0 &&
              !g.inCollectionRange(p))
            Text(g.collectionRangeHint(p)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 8,
            children: [
              if (p.kind == 'farm')
                btn('Farm upgrades', () => openFarmUpgrades(p)),
              if (p.kind == 'well')
                btn('Well upgrades', () => openWellUpgrades(p)),
              if (p.kind == 'home')
                btn('Home upgrades', () => openHomeUpgrades(p)),
              if (p.kind != 'home')
                btn(
                  'Collect · ${recovery}s',
                  p.available(g.now) > 0 && g.inCollectionRange(p)
                      ? () => beginCollection(p)
                      : null,
                ),
            ],
          ),
        ],
      );
    }
    if (selected != null)
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Selected location · ${selected!.latitude.toStringAsFixed(5)}, ${selected!.longitude.toStringAsFixed(5)}',
            style: const TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (!g.homeSet)
                btn('Set home', () => g.setHome(selected!), secondary: true),
              if (g.homeSet) ...[
                btn(
                  'Build farm · 5 wood / 3 stone',
                  () => buildFromMenu('farm'),
                  secondary: true,
                ),
                btn(
                  'Build well · 8 wood / 6 stone',
                  () => g.build('well', selected!),
                  secondary: true,
                ),
              ],
            ],
          ),
        ],
      );
    return Wrap(
      spacing: 10,
      runSpacing: 8,
      children: [
        btn(
          g.walking ? (g.paused ? 'Resume walk' : 'Pause walk') : 'Start walk',
          g.startWalk,
        ),
        if (g.walking) btn('Finish outing', finishOuting, secondary: true),
        if (!g.homeSet)
          btn('Set home here', () => g.setHome(g.position), secondary: true),
        const Text('Tap the map to select a location.'),
      ],
    );
  }

  Widget bagView() => SingleChildScrollView(
    padding: const EdgeInsets.all(28),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        heading('Your trail bag', 'Little discoveries, endless possibilities.'),
        Wrap(
          spacing: 16,
          runSpacing: 16,
          children: [
            for (final e in g.bag.entries)
              SizedBox(
                width: 210,
                child: panel(
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        {
                              'timber': '🪵',
                              'stone': '🪨',
                              'seeds': '🌱',
                              'carrots': '🥕',
                              'water': '🪣',
                              for (final project in HomeProject.values)
                                project.resource: project.icon,
                              for (final crop in Crop.values)
                                crop.stock: crop.icon,
                            }[e.key] ??
                            '📦',
                        style: const TextStyle(fontSize: 36),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        '${e.value}',
                        style: const TextStyle(
                          fontSize: 36,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      Text(
                        e.key.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 12,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 30),
        panel(
          Text(
            'Lifetime wandering: ${(g.distance / 1000).toStringAsFixed(2)} km\nDiscoveries arrive every 100–200 metres during an active walk.',
          ),
        ),
      ],
    ),
  );
  int get chapter => g.places.any((p) => p.kind == 'well') && g.harvests > 0
      ? 4
      : g.harvests > 0
      ? 3
      : g.places.any((p) => p.kind == 'farm' && p.fence.isNotEmpty)
      ? 2
      : g.homeSet
      ? 1
      : 0;
  void openWalk({required bool free}) {
    if (g.walking && g.freeWalk != free) g.finishWalk();
    if (!g.walking || g.paused) g.startWalk(free: free);
    setState(() => page = 1);
  }

  void openFullJourney() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => JourneyView(
          events: List<JourneyEvent>.of(g.journey),
          origin: g.position,
          tiles: tiles,
        ),
      ),
    );
  }

  Widget journal() => SingleChildScrollView(
    padding: const EdgeInsets.all(28),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        heading('Village journal', 'Bellmere'),
        btn(
          g.walking && !g.freeWalk ? 'Resume story walk' : 'Start story walk',
          () => openWalk(free: false),
        ),
        const SizedBox(height: 14),
        for (final entry in villageChapters.take(chapter + 1).toList().reversed)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: panel(
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    entry.title,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Text(
                    entry.speaker,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text(entry.body),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10,
                    runSpacing: 8,
                    children: [
                      btn('Listen', () async {
                        await tts.stop();
                        await tts.speak(entry.body);
                      }, icon: Icons.volume_up),
                      btn('Stop', () => tts.stop(), secondary: true),
                    ],
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 20),
        for (final x in [
          ('Choose your home', g.homeSet),
          (
            'Gather supplies and build a farm',
            g.places.any((p) => p.kind == 'farm'),
          ),
          ('Walk your farm’s fence', g.places.any((p) => p.fence.isNotEmpty)),
          ('Bring in your first harvest', g.harvests > 0),
          ('Restore the village well', g.places.any((p) => p.kind == 'well')),
        ])
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: panel(
              Row(
                children: [
                  Icon(
                    x.$2 ? Icons.check_circle : Icons.radio_button_unchecked,
                    color: x.$2 ? pine : grass,
                  ),
                  const SizedBox(width: 14),
                  Expanded(child: Text(x.$1)),
                ],
              ),
            ),
          ),
        if (chapter >= 1 &&
            (g.herbsGiftedToRowan ||
                g.home?.projects.containsKey(HomeProject.herbPatch) == true))
          panel(
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Herbs for Rowan',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                if (g.herbsGiftedToRowan)
                  const Text(
                    '“Ada grew these by the back step,” Rowan said. “She always left a sprig on the gate before her evening walk.”',
                  )
                else ...[
                  const Text('Bring Rowan two herbs from your garden.'),
                  const SizedBox(height: 8),
                  btn(
                    'Give Rowan 2 herbs',
                    g.canGiftHerbs ? g.giftHerbs : null,
                    secondary: true,
                  ),
                ],
              ],
            ),
          ),
        if (g.lastOuting case final outing?)
          btn('Last outing', () => showOuting(outing), secondary: true),
        const SizedBox(height: 12),
        btn('View Full Journey', openFullJourney, icon: Icons.map_outlined),
      ],
    ),
  );
  Widget settingsView() => SingleChildScrollView(
    padding: const EdgeInsets.all(28),
    child: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 800),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: heading(
                    'Settings',
                    'Make your adventure feel like you.',
                  ),
                ),
                IconButton(
                  onPressed: () => setState(() => settings = false),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            panel(
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'YOUR PACE',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  DropdownButton<String>(
                    isExpanded: true,
                    value: g.comfort,
                    items:
                        [
                              'Gentle · 10 minutes',
                              'Regular · 20 minutes',
                              'Ambitious · 40 minutes',
                            ]
                            .map(
                              (v) => DropdownMenuItem(value: v, child: Text(v)),
                            )
                            .toList(),
                    onChanged: (v) {
                      g.comfort = v!;
                      g.fitnessAdjustment = 0;
                      g.changed('Walking preference updated.');
                    },
                  ),
                  const Text(
                    'A flexible suggestion. Walk at your own pace; there is no streak to lose.',
                    style: TextStyle(fontSize: 12),
                  ),
                  const Divider(height: 30),
                  DropdownButton<int>(
                    isExpanded: true,
                    value: recovery,
                    items: [60, 90, 120]
                        .map(
                          (v) => DropdownMenuItem(
                            value: v,
                            child: Text('Collection break · $v seconds'),
                          ),
                        )
                        .toList(),
                    onChanged: (v) => setState(() => recovery = v!),
                  ),
                  DropdownButton<String>(
                    isExpanded: true,
                    value: activity,
                    items:
                        [
                              'Gentle stretching',
                              'Gentle breathing',
                              'Shoulder relaxation',
                              'Seated rest',
                            ]
                            .map(
                              (v) => DropdownMenuItem(value: v, child: Text(v)),
                            )
                            .toList(),
                    onChanged: (v) => setState(() => activity = v!),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Snap fences to nearby roads'),
                    subtitle: const Text(
                      'Within 6 m of mapped road centres. Fetches the surrounding map area from OpenStreetMap / Overpass when finishing a fence.',
                    ),
                    value: g.snapFencesToRoads,
                    onChanged: (v) {
                      g.snapFencesToRoads = v;
                      g.changed('Road snapping ${v ? 'enabled' : 'disabled'}.');
                    },
                  ),
                  if (roadLookupConsent)
                    TextButton(
                      onPressed: () async {
                        await prefs?.remove('roadLookupConsent');
                        if (mounted) setState(() => roadLookupConsent = false);
                        g.changed('Road lookup permission revoked.');
                      },
                      child: const Text('Revoke road lookup permission'),
                    ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Street map tiles'),
                    subtitle: const Text('Online OpenStreetMap basemap'),
                    value: tiles,
                    onChanged: (v) => setState(() => tiles = v),
                  ),
                  btn('Connect real GPS', realGps, secondary: true),
                ],
              ),
            ),
            const SizedBox(height: 18),
            panel(
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'YOUR SAVE',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(lastSaved),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      btn('Export save', () {
                        showDialog(
                          context: context,
                          builder: (c) => AlertDialog(
                            title: const Text('Your village backup'),
                            content: SizedBox(
                              width: 500,
                              child: SingleChildScrollView(
                                child: SelectableText(jsonEncode(g.json())),
                              ),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Clipboard.setData(
                                    ClipboardData(text: jsonEncode(g.json())),
                                  );
                                },
                                child: const Text('Copy'),
                              ),
                              TextButton(
                                onPressed: () => Navigator.pop(c),
                                child: const Text('Close'),
                              ),
                            ],
                          ),
                        );
                      }, secondary: true),
                      btn('Import save', importSave, secondary: true),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            panel(
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.tune, color: pine),
                    title: const Text(
                      'Admin menu',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: const Text(
                      'GPS simulator, village clock & debug tools',
                    ),
                    trailing: Icon(
                      admin ? Icons.expand_less : Icons.expand_more,
                    ),
                    onTap: () => setState(() => admin = !admin),
                  ),
                  if (admin) ...[
                    const Divider(),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Activate GPS spoofer'),
                      subtitle: const Text(
                        'Simulates location inside this app only.',
                      ),
                      value: g.spoofer,
                      onChanged: (v) {
                        gps?.cancel();
                        stick = Offset.zero;
                        g.spoofer = v;
                        g.changed(
                          v ? 'GPS simulator enabled. Open the map to explore.' : 'Simulator disabled. Connect real GPS to track movement.',
                        );
                      },
                    ),
                    if (g.spoofer) ...[
                      btn(
                        'Open simulator map',
                        () => setState(() {
                          settings = false;
                          page = 1;
                        }),
                      ),
                      const SizedBox(height: 15),
                      if (MediaQuery.sizeOf(context).width <= 1000) simulator(),
                    ],
                    const Divider(height: 35),
                    const Text(
                      'TIME SKIPPER',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text('Village time: ${time(g.now)}'),
                    const Text(
                      'Advances production; never awards walking distance.',
                      style: TextStyle(fontSize: 12),
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final h in [1, 5, 12, 24, 48, 120, 168, 336])
                          btn(
                            h < 24 ? '+${h}h' : '+${h ~/ 24} days',
                            () => g.skip(Duration(hours: h)),
                            secondary: true,
                          ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: customDate,
                      decoration: const InputDecoration(
                        labelText: 'Specific future time',
                        hintText: 'YYYY-MM-DD HH:MM',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    btn('Skip to this time', () {
                      try {
                        final d = DateTime.parse(
                          customDate.text.replaceFirst(' ', 'T'),
                        );
                        final delta = d.millisecondsSinceEpoch - g.now;
                        if (delta <= 0) {
                          g.changed(
                            'Choose a time later than the current village clock.',
                          );
                          return;
                        }
                        g.skip(Duration(milliseconds: delta));
                      } catch (_) {
                        g.changed('Enter a valid date: YYYY-MM-DD HH:MM.');
                      }
                    }, secondary: true),
                    const Divider(height: 35),
                    const Text(
                      'DEBUG TOOLS',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Infinite resources'),
                      subtitle: const Text(
                        '10 real minutes. Your previous inventory returns when this ends.',
                      ),
                      value: g.infiniteResources,
                      onChanged: g.setInfiniteResources,
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        btn('Grant building supplies', () {
                          for (final k in ['timber', 'stone', 'seeds']) {
                            g.bag[k] = g.bag[k]! + 50;
                          }
                          g.changed('Added 50 timber, stone and seeds.');
                        }, secondary: true),
                        btn('Trigger pickup', g.pickup, secondary: true),
                        btn(
                          'Ripen all buildings',
                          g.ripenBuildings,
                          secondary: true,
                        ),
                        btn('Grant water', () {
                          g.bag['water'] = g.bag['water']! + 250;
                          g.changed('Added 250 water.');
                        }, secondary: true),
                        btn('Reset village', reset, secondary: true),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'ACTIVITY LOG',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    for (final line in g.log.take(10))
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(line, style: const TextStyle(fontSize: 10)),
                      ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Prototype notes: saves stay in this browser/device. Narration uses the available device voice. Play your music in your usual app. Locked-screen tracking, media ducking and automatic fitness adaptation are not yet implemented.',
              style: TextStyle(fontSize: 11),
            ),
          ],
        ),
      ),
    ),
  );
  Widget simulator() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      tag('ADMIN · GPS SIMULATOR'),
      const SizedBox(height: 18),
      const Text(
        'Take the scenic route',
        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 6),
      const Text(
        'Right-click the map to teleport, or select a spot and use Teleport next to Build.',
        style: TextStyle(fontSize: 12),
      ),
      const SizedBox(height: 18),
      Center(child: joystick()),
      const SizedBox(height: 12),
      Text(
        '${speedMultiplier.round()}× walking speed · ${(1.4 * speedMultiplier * 3.6).toStringAsFixed(1)} km/h',
        style: const TextStyle(fontSize: 12),
      ),
      Slider(
        value: speedMultiplier,
        min: 1,
        max: 20,
        divisions: 19,
        label: '${speedMultiplier.round()}×',
        semanticFormatterCallback: (v) => '${v.round()} times walking speed',
        activeColor: pine,
        onChanged: (v) => setState(() => speedMultiplier = v),
      ),
      const Text(
        'Start a walk to earn distance and discoveries.',
        style: TextStyle(fontSize: 11),
      ),
      const SizedBox(height: 15),
      btn(
        g.walking ? (g.paused ? 'Resume walk' : 'Pause walk') : 'Start walk',
        g.startWalk,
      ),
      if (g.walking) ...[
        const SizedBox(height: 8),
        btn('Finish walk', finishOuting, secondary: true),
      ],
      const Divider(height: 30),
      const Divider(),
      Text(
        'Village clock\n${time(g.now)}',
        style: const TextStyle(fontSize: 12),
      ),
      const SizedBox(height: 10),
      Wrap(
        spacing: 6,
        runSpacing: 6,
        children: [
          for (final h in [1, 5, 24, 168])
            TextButton(
              onPressed: () => g.skip(Duration(hours: h)),
              child: Text(h < 24 ? '+${h}h' : '+${h ~/ 24}d'),
            ),
        ],
      ),
      TextButton(
        onPressed: () => setState(() {
          settings = true;
          admin = true;
        }),
        child: const Text('All Admin options →'),
      ),
    ],
  );
  Widget joystick() => Semantics(
    label: 'GPS movement joystick. Drag from the centre to walk.',
    child: GestureDetector(
      onPanStart: (d) => updateStick(d.localPosition),
      onPanUpdate: (d) => updateStick(d.localPosition),
      onPanEnd: (_) => setState(() => stick = Offset.zero),
      onPanCancel: () => setState(() => stick = Offset.zero),
      child: Container(
        width: 150,
        height: 150,
        decoration: BoxDecoration(
          color: cream.withValues(alpha: .94),
          shape: BoxShape.circle,
          border: Border.all(color: pine, width: 3),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            const Positioned(
              top: 6,
              child: Icon(Icons.keyboard_arrow_up, color: pine),
            ),
            const Positioned(
              bottom: 6,
              child: Icon(Icons.keyboard_arrow_down, color: pine),
            ),
            const Positioned(
              left: 6,
              child: Icon(Icons.keyboard_arrow_left, color: pine),
            ),
            const Positioned(
              right: 6,
              child: Icon(Icons.keyboard_arrow_right, color: pine),
            ),
            Transform.translate(
              offset: stick * 39,
              child: Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: orange,
                  shape: BoxShape.circle,
                  border: Border.all(color: pine, width: 2),
                ),
                child: const Icon(Icons.directions_walk, color: cream),
              ),
            ),
          ],
        ),
      ),
    ),
  );
  void updateStick(Offset p) {
    var d = (p - const Offset(75, 75)) / 45;
    if (d.distance > 1) d = d / d.distance;
    setState(() => stick = d);
  }

  Future<void> importSave() async {
    final input = TextEditingController();
    await showDialog(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Import village backup'),
        content: TextField(
          controller: input,
          maxLines: 8,
          decoration: const InputDecoration(
            hintText: 'Paste exported save JSON',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              try {
                final decoded = jsonDecode(input.text);
                final trial = Game();
                trial.restore(Map<String, dynamic>.from(decoded));
                g.restore(Map<String, dynamic>.from(decoded));
                gps?.cancel();
                focus = null;
                selected = null;
                cancelCollection();
                collectionReward = null;
                fencing = null;
                save();
                Navigator.pop(c);
              } catch (_) {
                g.changed('Invalid backup. Your current village was kept.');
              }
            },
            child: const Text('Import'),
          ),
        ],
      ),
    );
  }

  Future<void> reset() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Start a new village?'),
        content: const Text(
          'This removes your current village on this device. Export a backup first if you want to keep it.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Keep village'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Reset village'),
          ),
        ],
      ),
    );
    if (yes == true) {
      gps?.cancel();
      g.restore(Game().json());
      focus = null;
      selected = null;
      cancelCollection();
      collectionReward = null;
      fencing = null;
      stick = Offset.zero;
      g.changed('A fresh start. Your new homestead awaits.');
      save();
    }
  }
}

// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'game.dart';

const _farmColors = <String, int>{
  'Rose': 0xffffccd2,
  'Gold': 0xffffdc85,
  'Sage': 0xffcee5b3,
  'Sky': 0xffc4e7f8,
  'Lavender': 0xffe6d5fa,
};
const _farmIcons = ['🥕', '🌱', '🎃', '🥔', '🌻', '🍄', '🌾', '🦋', '🏡'];

Future<void> editBuilding(BuildContext context, Game game, Place place) async {
  var name = place.name;
  var color = place.markerColor;
  var emoji = place.markerEmoji;
  await showDialog<void>(
    context: context,
    builder: (context) => StatefulBuilder(
      builder: (context, update) => AlertDialog(
        title: Text(
          place.kind == 'farm' ? 'Customize farm' : 'Rename ${place.kind}',
        ),
        content: SizedBox(
          width: 340,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  initialValue: name,
                  maxLength: 32,
                  decoration: const InputDecoration(labelText: 'Name'),
                  onChanged: (value) => update(() => name = value),
                ),
                if (place.kind == 'farm') ...[
                  const Text('Map colour'),
                  Wrap(
                    spacing: 5,
                    children: [
                      ChoiceChip(
                        label: const Text('Default'),
                        selected: color == null,
                        onSelected: (_) => update(() => color = null),
                      ),
                      for (final option in _farmColors.entries)
                        ChoiceChip(
                          label: Text(option.key),
                          avatar: CircleAvatar(
                            backgroundColor: Color(option.value),
                            radius: 8,
                          ),
                          selected: color == option.value,
                          onSelected: (_) => update(() => color = option.value),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text('Map emoji'),
                  Wrap(
                    spacing: 5,
                    children: [
                      ChoiceChip(
                        label: const Text('Crop'),
                        selected: emoji == null,
                        onSelected: (_) => update(() => emoji = null),
                      ),
                      for (final option in _farmIcons)
                        ChoiceChip(
                          label: Text(option),
                          selected: emoji == option,
                          onSelected: (_) => update(() => emoji = option),
                        ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: name.trim().isEmpty
                ? null
                : () {
                    if (game.customizePlace(
                      place,
                      name,
                      color: color,
                      emoji: emoji,
                    ))
                      Navigator.pop(context);
                  },
            child: const Text('Save'),
          ),
        ],
      ),
    ),
  );
}

// ignore: deprecated_member_use
import 'package:flutter/material.dart';

import 'building_customization.dart';
import 'game.dart';
import 'homestead.dart';

class HomeUpgradeView extends StatelessWidget {
  const HomeUpgradeView({
    required this.game,
    required this.home,
    required this.buildFence,
    super.key,
  });

  final Game game;
  final Place home;
  final VoidCallback buildFence;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Home upgrades')),
    body: SafeArea(
      child: ListenableBuilder(
        listenable: game,
        builder: (context, _) {
          final inside = game.inCollectionRange(home);
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Text(home.name, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  OutlinedButton(
                    onPressed: () => editBuilding(context, game, home),
                    child: const Text('Rename home'),
                  ),
                  OutlinedButton(
                    onPressed: buildFence,
                    child: Text(
                      home.fence.isEmpty
                          ? 'Build home fence'
                          : 'Redraw home fence',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (home.fence.isEmpty)
                const Text('Walk a fence around home to start the seed garden.')
              else ...[
                Text(
                  '${home.available(game.now)} / ${home.capacity} seeds ready',
                ),
                if (!inside)
                  const Text(
                    'Step inside the home fence to gather seeds or make upgrades.',
                  ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: FilledButton(
                    onPressed: inside && home.available(game.now) > 0
                        ? () => game.collect(home)
                        : null,
                    child: const Text('Gather seeds'),
                  ),
                ),
                for (final garden in [true, false])
                  _upgrade(context, garden, inside),
                ...HomeProject.values.map(
                  (project) => _project(context, project, inside),
                ),
              ],
              const SizedBox(height: 12),
              PetSlot(game: game),
            ],
          );
        },
      ),
    ),
  );

  Widget _project(BuildContext context, HomeProject project, bool inside) {
    final built = home.projects.containsKey(project);
    final description = switch (project) {
      HomeProject.compostBin => 'Compost boosts crops once per planting.',
      HomeProject.herbPatch =>
        'Gather herbs for pet treats and a gift for Rowan.',
      HomeProject.workbench => 'Craft repair kits for fences and wells.',
    };
    String price(Map<String, int> items) =>
        items.entries.map((item) => '${item.value} ${item.key}').join(' · ');
    final stock = game.homeStock(project);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${project.icon} ${project.label}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(description),
            if (!built)
              OutlinedButton(
                onPressed: game.canBuildHomeProject(project)
                    ? () => game.buildHomeProject(project)
                    : null,
                child: Text('Build · ${price(project.cost)}'),
              )
            else if (project == HomeProject.workbench)
              OutlinedButton(
                onPressed: game.canCraftRepairKit ? game.craftRepairKit : null,
                child: Text(
                  'Craft a repair kit · ${price(HomeProject.repairKitCost)}',
                ),
              )
            else ...[
              Text(
                '$stock / ${project.capacity} ${project.resource} ready · one every ${project.hours}h',
              ),
              OutlinedButton(
                onPressed: inside && stock > 0
                    ? () => game.collectHomeProject(project)
                    : null,
                child: Text('Gather ${project.resource}'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _upgrade(BuildContext context, bool garden, bool inside) {
    final tier = garden ? home.gardenTier : home.shedTier;
    final cost = game.homeUpgradeCost(home, garden: garden);
    return Card(
      child: ListTile(
        title: Text(
          '${garden ? 'Seed garden' : 'Storage shed'} · Tier $tier / 3',
        ),
        subtitle: Text(
          [
            garden
                ? 'One seed every ${4 - tier} hours'
                : 'Stores up to ${home.capacity} seeds',
            if (tier < 3)
              cost.entries
                  .map((entry) => '${entry.value} ${entry.key}')
                  .join(' · '),
          ].join('\n'),
        ),
        trailing: tier < 3
            ? TextButton(
                onPressed:
                    inside &&
                        cost.entries.every(
                          (entry) => (game.bag[entry.key] ?? 0) >= entry.value,
                        )
                    ? () => game.upgradeHome(home, garden: garden)
                    : null,
                child: const Text('Upgrade'),
              )
            : null,
      ),
    );
  }
}

class PetSlot extends StatelessWidget {
  const PetSlot({required this.game, super.key});
  final Game game;

  @override
  Widget build(BuildContext context) {
    final pet = game.pet;
    final farm = game.petFarm;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (pet != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.asset(
                      pet.asset,
                      width: 72,
                      height: 72,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) =>
                          Text(pet.emoji, style: const TextStyle(fontSize: 34)),
                    ),
                  )
                else
                  const Icon(Icons.pets, size: 36),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Pet slot',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      Text(
                        pet == null
                            ? 'You might meet a dog, cat or bunny on a walk.'
                            : '${pet.label} · ${farm != null
                                  ? 'Helping at ${farm.name}'
                                  : game.petFollows
                                  ? 'Following you'
                                  : 'Resting at home'}',
                      ),
                      if (pet != null)
                        Text(
                          'Friendship level ${game.petFriendshipLevel} · ${game.petFriendship} points',
                        ),
                    ],
                  ),
                ),
              ],
            ),
            if (pet != null) ...[
              const SizedBox(height: 10),
              if (game.petFriendship < Game.petFarmUnlock) ...[
                LinearProgressIndicator(
                  value: game.petFriendship / Game.petFarmUnlock,
                ),
                Text(
                  'Farm help unlocks at level 4 · ${game.petFriendship}/${Game.petFarmUnlock} points. '
                  '+1 per 100 m together or +${Game.petTreatFriendship} per treat.',
                ),
              ] else
                Text(
                  farm == null
                      ? 'Ready to help. Visit a farm and open its upgrades.'
                      : pet.farmBonus,
                ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  OutlinedButton(
                    onPressed: () => game.setPetFollowing(!game.petFollows),
                    child: Text(game.petFollows ? 'Rest at home' : 'Follow me'),
                  ),
                  OutlinedButton(
                    onPressed: game.canTreatPet ? game.treatPet : null,
                    child: const Text('Give treat · 1 herb'),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

enum FarmEvent {
  birds('Bird Swarm!'),
  heavyRain('Heavy Rain!'),
  drought('Drought!'),
  brokenFence('Broken Fence!');

  const FarmEvent(this.title);
  final String title;

  static FarmEvent seasonalWeather(DateTime date, double latitude) {
    final northernDrySeason = date.month >= 6 && date.month <= 11;
    final drySeason = latitude >= 0 ? northernDrySeason : !northernDrySeason;
    return drySeason ? drought : heavyRain;
  }
}

enum FarmUpgrade {
  fence('Fence', '🪵', [
    'Basic wood',
    'Reinforced timber',
    'Stone wall',
    'Steel mesh',
    'Maximum security',
  ]),
  farmhouse('Farmhouse', '🏡', [
    'Farm cottage',
    'Store room',
    'Barn loft',
    'Granary',
    'Farm estate',
  ]),
  scarecrow('Scarecrow', '🌾', [
    'Straw sentinel',
    'Ribbon keeper',
    'Reflective watch',
    'Wind guardian',
    'Field warden',
  ]),
  sprinklers('Sprinklers', '💧', [
    'Hand watering',
    'Drip line',
    'Rotary sprinklers',
    'Pressure network',
    'Precision irrigation',
  ]);

  const FarmUpgrade(this.label, this.icon, this.tiers);
  final String label, icon;
  final List<String> tiers;
  static const maxTier = 5;

  Map<String, int> cost(int targetTier) {
    final n = targetTier - 1;
    return switch (this) {
      fence => {'timber': 8 * n, 'stone': 5 * n},
      farmhouse => {'timber': 12 * n, 'stone': 8 * n},
      scarecrow => {'timber': 5 * n, 'seeds': 2 * n},
      sprinklers => {'stone': 7 * n, 'water': 5 * n},
    };
  }

  String effect(int level) => switch (this) {
    fence => '${(breakRisk(level) * 100).round()}% base daily break risk',
    farmhouse => '${storagePercent(level)}% of one full harvest stored',
    scarecrow => '${(birdRisk(level) * 100).round()}% base daily bird risk',
    sprinklers => '${speedPercent(level)}% growth speed',
  };
  static int storagePercent(int level) => 100 + (level - 1) * 25;
  static int speedPercent(int level) => 100 + (level - 1) * 15;
  static double breakRisk(int level) =>
      const [.12, .08, .05, .025, .01][level - 1];
  static double birdRisk(int level) =>
      const [.19, .14, .09, .05, .02][level - 1];
}

class FarmImprovements {
  FarmImprovements({
    this.nextRiskAt,
    this.fenceDamaged = false,
    this.lostCrops = 0,
    this.fenceYieldLoss = 0,
    this.lastIncident,
  });
  final Map<FarmUpgrade, int> tiers = {};
  int? nextRiskAt;
  bool fenceDamaged;
  int lostCrops;
  int fenceYieldLoss;

  void repairFence() {
    fenceDamaged = false;
    fenceYieldLoss = 0;
  }

  String? lastIncident;

  int level(FarmUpgrade upgrade) => tiers[upgrade] ?? 1;
  Map<String, dynamic> json() => {
    'tiers': {for (final entry in tiers.entries) entry.key.name: entry.value},
    'nextRiskAt': nextRiskAt,
    'fenceDamaged': fenceDamaged,
    'lostCrops': lostCrops,
    'fenceYieldLoss': fenceYieldLoss,
    'lastIncident': lastIncident,
  };
  factory FarmImprovements.from(Map<String, dynamic> data) {
    final state = FarmImprovements(
      nextRiskAt: data['nextRiskAt'],
      fenceDamaged: data['fenceDamaged'] == true,
      lostCrops: data['lostCrops'] ?? 0,
      fenceYieldLoss: data['fenceDamaged'] == true
          ? (data['fenceYieldLoss'] as int? ?? 10).clamp(0, 100)
          : 0,
      lastIncident: data['lastIncident'],
    );
    final tiers = data['tiers'] as Map? ?? {};
    for (final upgrade in FarmUpgrade.values) {
      state.tiers[upgrade] = (tiers[upgrade.name] as int? ?? 1).clamp(
        1,
        FarmUpgrade.maxTier,
      );
    }
    return state;
  }
}

import 'dart:math';

import 'package:latlong2/latlong.dart';

typedef XY = Point<double>;
const fenceCloseDistance = 12.0;
const roadSnapDistance = 6.0;
const pipeJoinDistance = 100.0;
const pipeBoundaryTolerance = 16.0;

class FenceBoundary {
  final List<LatLng> points;
  final int snappedPoints;
  final List<LatLng> beforeCleanup;
  final double smoothingTolerance;
  final int removedPoints;
  const FenceBoundary(
    this.points, {
    this.snappedPoints = 0,
    this.beforeCleanup = const [],
    this.smoothingTolerance = 0,
    this.removedPoints = 0,
  });
}

class _Projection {
  final LatLng origin;
  late final double longitudeScale = 111320 * cos(origin.latitude * pi / 180);
  _Projection(this.origin);
  XY project(LatLng p) => XY(
    (p.longitude - origin.longitude) * longitudeScale,
    (p.latitude - origin.latitude) * 111320,
  );
  LatLng unproject(XY p) => LatLng(
    origin.latitude + p.y / 111320,
    origin.longitude + p.x / longitudeScale,
  );
}

double _cross(XY a, XY b) => a.x * b.y - a.y * b.x;
double _dot(XY a, XY b) => a.x * b.x + a.y * b.y;
XY _nearest(XY p, XY a, XY b) {
  final d = b - a;
  final n = _dot(d, d);
  return n < 1e-12 ? a : a + d * (_dot(p - a, d) / n).clamp(0.0, 1.0);
}

double _area(List<XY> p) {
  double a = 0;
  for (int i = 0; i < p.length; i++) {
    a += _cross(p[i], p[(i + 1) % p.length]);
  }
  return a / 2;
}

bool _contains(XY p, List<XY> vs) {
  bool c = false;
  for (int i = 0, j = vs.length - 1; i < vs.length; j = i++) {
    if (_nearest(p, vs[j], vs[i]).distanceTo(p) < .15) return true;
    if ((vs[i].y > p.y) != (vs[j].y > p.y) &&
        p.x <
            (vs[j].x - vs[i].x) * (p.y - vs[i].y) / (vs[j].y - vs[i].y) +
                vs[i].x)
      c = !c;
  }
  return c;
}

List<XY> _simplify(List<XY> p, double tolerance) {
  if (p.length <= 2) return List.of(p);
  final keep = <int>{0, p.length - 1};
  final stack = <List<int>>[
    [0, p.length - 1],
  ];
  while (stack.isNotEmpty) {
    final range = stack.removeLast();
    int index = -1;
    double distance = tolerance;
    for (int i = range[0] + 1; i < range[1]; i++) {
      final d = _nearest(p[i], p[range[0]], p[range[1]]).distanceTo(p[i]);
      if (d > distance) {
        distance = d;
        index = i;
      }
    }
    if (index >= 0) {
      keep.add(index);
      stack.add([range[0], index]);
      stack.add([index, range[1]]);
    }
  }
  final indices = keep.toList()..sort();
  return indices.map((i) => p[i]).toList();
}

List<XY> _simplifyRing(List<XY> p, double tolerance) {
  if (p.length <= 3) return List.of(p);
  int far = 1;
  for (int i = 2; i < p.length; i++) {
    if (p[i].distanceTo(p.first) > p[far].distanceTo(p.first)) far = i;
  }
  final a = _simplify(p.sublist(0, far + 1), tolerance);
  final b = _simplify([...p.sublist(far), p.first], tolerance);
  final result = [...a.take(a.length - 1), ...b.take(b.length - 1)];
  return result.length < 3 ? List.of(p) : result;
}

/// Split crossing segments into a planar graph and trace its faces. Removing
/// degree-one branches first drops lead-ins/out-tails, rather than treating them
/// as part of the perimeter or inflating the plot with a convex hull.
List<List<XY>> _faces(List<XY> path) {
  if (path.length < 4) return [];
  final splits = List.generate(path.length - 1, (_) => <double>[0, 1]);
  for (int i = 0; i < path.length - 1; i++) {
    final a = path[i], r = path[i + 1] - a;
    for (int j = i + 1; j < path.length - 1; j++) {
      final b = path[j], s = path[j + 1] - b, divisor = _cross(r, s);
      if (divisor.abs() > 1e-8) {
        final t = _cross(b - a, s) / divisor, u = _cross(b - a, r) / divisor;
        if (t >= -1e-8 && t <= 1 + 1e-8 && u >= -1e-8 && u <= 1 + 1e-8) {
          splits[i].add(t.clamp(0, 1));
          splits[j].add(u.clamp(0, 1));
        }
      } else if (_cross(b - a, r).abs() < 1e-5 &&
          _dot(r, r) > .001 &&
          _dot(s, s) > .001) {
        // Overlapping retraced sections also need shared graph vertices.
        for (final p in [b, b + s]) {
          final t = _dot(p - a, r) / _dot(r, r);
          if (t >= 0 && t <= 1) splits[i].add(t);
        }
        for (final p in [a, a + r]) {
          final u = _dot(p - b, s) / _dot(s, s);
          if (u >= 0 && u <= 1) splits[j].add(u);
        }
      }
    }
  }
  final nodes = <XY>[], ids = <String, int>{}, graph = <int, Set<int>>{};
  int node(XY p) {
    final key = '${(p.x * 20).round()}:${(p.y * 20).round()}';
    return ids.putIfAbsent(key, () {
      nodes.add(p);
      graph[nodes.length - 1] = {};
      return nodes.length - 1;
    });
  }

  for (int i = 0; i < splits.length; i++) {
    final ts = splits[i]..sort();
    int? last;
    for (final t in ts) {
      final n = node(path[i] + (path[i + 1] - path[i]) * t);
      if (last != null && last != n) {
        graph[last]!.add(n);
        graph[n]!.add(last);
      }
      last = n;
    }
  }
  final queue = graph.keys.where((n) => graph[n]!.length < 2).toList();
  while (queue.isNotEmpty) {
    final n = queue.removeLast();
    if (graph[n]!.length > 1) continue;
    for (final v in graph[n]!.toList()) {
      graph[v]!.remove(n);
      if (graph[v]!.length < 2) queue.add(v);
    }
    graph[n]!.clear();
  }
  final sorted = <int, List<int>>{};
  for (final n in graph.keys) {
    sorted[n] = graph[n]!.toList()
      ..sort(
        (a, b) => atan2(
          nodes[a].y - nodes[n].y,
          nodes[a].x - nodes[n].x,
        ).compareTo(atan2(nodes[b].y - nodes[n].y, nodes[b].x - nodes[n].x)),
      );
  }
  final seen = <String>{}, faces = <List<XY>>[];
  for (final a in graph.keys) {
    for (final b in graph[a]!) {
      if (seen.contains('$a:$b')) continue;
      int u = a, v = b;
      final ring = <int>[];
      for (int guard = 0; guard < nodes.length * 4; guard++) {
        final edge = '$u:$v';
        if (seen.contains(edge)) break;
        seen.add(edge);
        ring.add(u);
        final neighbours = sorted[v]!;
        if (neighbours.isEmpty) break;
        final next =
            neighbours[(neighbours.indexOf(u) - 1 + neighbours.length) %
                neighbours.length];
        u = v;
        v = next;
        if (u == a && v == b) {
          if (ring.length >= 3 && ring.toSet().length == ring.length)
            faces.add(ring.map((n) => nodes[n]).toList());
          break;
        }
      }
    }
  }
  return faces;
}

bool _simple(List<XY> p) {
  if (p.length < 3) return false;
  for (int i = 0; i < p.length; i++) {
    final a = p[i], r = p[(i + 1) % p.length] - a;
    if (_dot(r, r) < .001) return false;
    for (int j = i + 1; j < p.length; j++) {
      if (j == i + 1 || (i == 0 && j == p.length - 1)) continue;
      final b = p[j], s = p[(j + 1) % p.length] - b, d = _cross(r, s);
      if (d.abs() < 1e-8) {
        if (_cross(b - a, r).abs() < 1e-6) {
          final t = _dot(b - a, r) / _dot(r, r),
              u = _dot(b + s - a, r) / _dot(r, r);
          if (max(min(t, u), 0) <= min(max(t, u), 1)) return false;
        }
      } else {
        final t = _cross(b - a, s) / d, u = _cross(b - a, r) / d;
        if (t >= -1e-8 && t <= 1 + 1e-8 && u >= -1e-8 && u <= 1 + 1e-8)
          return false;
      }
    }
  }
  return true;
}

double _boundaryDistance(XY p, List<XY> ring) {
  double best = double.infinity;
  for (int i = 0; i < ring.length; i++) {
    best = min(
      best,
      _nearest(p, ring[i], ring[(i + 1) % ring.length]).distanceTo(p),
    );
  }
  return best;
}

class FenceCleanup {
  final List<LatLng> points;
  final int beforeCount;
  final double toleranceMeters;
  final bool safe;
  const FenceCleanup(
    this.points, {
    required this.beforeCount,
    required this.toleranceMeters,
    this.safe = true,
  });
  bool get changed => safe && points.length < beforeCount;
}

/// Simplify the entire cycle, with no permanently pinned seam/start vertex.
/// Every replacement edge is checked against ALL original points in its span,
/// so successive passes cannot drift further than the advertised tolerance.
/// Farm containment, simple topology and area within 8% are checked on each cut.
List<XY> _straightenRing(List<XY> source, XY farm, double tolerance) {
  if (source.length <= 3 || !_simple(source)) return List.of(source);
  final originalArea = _area(source).abs();
  final keep = List<int>.generate(source.length, (i) => i);
  while (keep.length > 3) {
    final candidates = <(double, int)>[];
    for (int k = 0; k < keep.length; k++) {
      final a = keep[(k - 1 + keep.length) % keep.length],
          b = keep[(k + 1) % keep.length];
      double error = 0;
      for (
        int i = (a + 1) % source.length;
        i != b;
        i = (i + 1) % source.length
      ) {
        error = max(
          error,
          _nearest(source[i], source[a], source[b]).distanceTo(source[i]),
        );
        if (error > tolerance) break;
      }
      if (error <= tolerance) candidates.add((error, k));
    }
    candidates.sort((a, b) => a.$1.compareTo(b.$1));
    bool removed = false;
    for (final candidate in candidates) {
      final trial = [
        for (int k = 0; k < keep.length; k++)
          if (k != candidate.$2) source[keep[k]],
      ];
      final area = _area(trial).abs();
      if (area < 40 ||
          (area - originalArea).abs() > originalArea * .08 ||
          !_contains(farm, trial) ||
          !_simple(trial))
        continue;
      keep.removeAt(candidate.$2);
      removed = true;
      break;
    }
    if (!removed) break;
  }
  return keep.map((i) => source[i]).toList();
}

FenceCleanup neatenFence(
  List<LatLng> boundary,
  LatLng entrance, {
  double maxDeviation = 8,
}) {
  if (boundary.length < 3)
    return FenceCleanup(
      List.of(boundary),
      beforeCount: boundary.length,
      toleranceMeters: 0,
      safe: false,
    );
  final frame = _Projection(boundary.first);
  final original = <XY>[];
  for (final p in boundary.map(frame.project)) {
    if (original.isEmpty || original.last.distanceTo(p) > .05) original.add(p);
  }
  if (original.length > 1 && original.first.distanceTo(original.last) < .05)
    original.removeLast();
  final area = _area(original).abs();
  final tolerance = min(
    maxDeviation.clamp(1.0, 20.0),
    max(1.5, sqrt(area) * .08),
  );
  final farm = frame.project(entrance);
  if (area < 40 || !_simple(original) || !_contains(farm, original)) {
    return FenceCleanup(
      List.of(boundary),
      beforeCount: boundary.length,
      toleranceMeters: tolerance,
      safe: false,
    );
  }
  final clean = _straightenRing(original, farm, tolerance);
  return FenceCleanup(
    clean.map(frame.unproject).toList(),
    beforeCount: original.length,
    toleranceMeters: tolerance,
  );
}

/// Keeps the largest genuine outer loop containing the farm. An endpoint can
/// join any older segment within 12m; it never closes directly back to a centre
/// start or uses a convex hull that would fill in intentional concave corners.
FenceBoundary? findFenceBoundary(
  List<LatLng> trail,
  LatLng entrance, {
  List<List<LatLng>> roads = const [],
}) {
  if (trail.length < 4) return null;
  final frame = _Projection(trail.first);
  final farm = frame.project(entrance), endpoint = frame.project(trail.last);
  final raw = trail.map(frame.project).toList();
  final path = _simplify(raw, 1.25);
  List<XY>? largest(List<List<XY>> rings) {
    final valid = rings
        .where(
          (r) =>
              _area(r).abs() >= 40 &&
              _contains(farm, r) &&
              _boundaryDistance(endpoint, r) <= fenceCloseDistance &&
              _simple(r),
        )
        .toList();
    if (valid.isEmpty) return null;
    valid.sort((a, b) => _area(b).abs().compareTo(_area(a).abs()));
    return valid.first;
  }

  var chosen = largest(_faces(path));
  if (chosen == null) {
    double remaining = 0;
    final candidates = <(double, XY)>[];
    for (int i = path.length - 2; i >= 0; i--) {
      remaining += path[i].distanceTo(path[i + 1]);
      final projection = _nearest(endpoint, path[i], path[i + 1]);
      final d = endpoint.distanceTo(projection);
      if (i < path.length - 3 &&
          d <= fenceCloseDistance &&
          remaining >= max(40, d * 6)) {
        final ring = [projection, ...path.sublist(i + 1)];
        if (_area(ring).abs() >= 40 && _contains(farm, ring))
          candidates.add((d, projection));
      }
    }
    candidates.sort((a, b) => a.$1.compareTo(b.$1));
    // Try the closest connections first; invalid small loops cannot steal a valid
    // farm boundary. Limit expensive graph rebuilding on a very long trace.
    for (final candidate in candidates.take(12)) {
      chosen = largest(_faces([...path, candidate.$2]));
      if (chosen != null) break;
    }
  }
  if (chosen == null) return null;
  final beforeCleanup = chosen.map(frame.unproject).toList();
  final cleanup = neatenFence(beforeCleanup, entrance);
  chosen = cleanup.points.map(frame.project).toList();
  int snapped = 0;
  if (roads.isNotEmpty) {
    final segments = <(XY, XY)>[];
    for (final road in roads) {
      for (int i = 1; i < road.length; i++) {
        segments.add((frame.project(road[i - 1]), frame.project(road[i])));
      }
    }
    final samples = <XY>[];
    for (int i = 0; i < chosen.length; i++) {
      final a = chosen[i], b = chosen[(i + 1) % chosen.length];
      final steps = max(1, (a.distanceTo(b) / 3).ceil());
      for (int k = 0; k < steps; k++) {
        final p = a + (b - a) * (k / steps);
        XY best = p;
        double distance = roadSnapDistance + .000001;
        for (final segment in segments) {
          // Fast bounding-box rejection before projecting onto road centrelines.
          if (p.x < min(segment.$1.x, segment.$2.x) - roadSnapDistance ||
              p.x > max(segment.$1.x, segment.$2.x) + roadSnapDistance ||
              p.y < min(segment.$1.y, segment.$2.y) - roadSnapDistance ||
              p.y > max(segment.$1.y, segment.$2.y) + roadSnapDistance)
            continue;
          final q = _nearest(p, segment.$1, segment.$2), d = p.distanceTo(q);
          if (d < distance) {
            best = q;
            distance = d;
          }
        }
        if (best.distanceTo(p) > .02) snapped++;
        if (samples.isEmpty || samples.last.distanceTo(best) > .15)
          samples.add(best);
      }
    }
    if (samples.length > 1 && samples.first.distanceTo(samples.last) < .15)
      samples.removeLast();
    final result = _simplifyRing(samples, .5);
    if (_simple(result) &&
        _area(result).abs() >= 40 &&
        _contains(farm, result)) {
      chosen = result;
    } else {
      snapped = 0;
    }
  }
  return FenceBoundary(
    chosen.map(frame.unproject).toList(),
    snappedPoints: snapped,
    beforeCleanup: beforeCleanup,
    smoothingTolerance: cleanup.toleranceMeters,
    removedPoints: max(0, beforeCleanup.length - cleanup.points.length),
  );
}

/// The area centroid, with an interior fallback for concave plots.
LatLng fenceCentre(List<LatLng> fence, LatLng entrance) {
  final frame = _Projection(fence.first);
  final ring = fence.map(frame.project).toList();
  var weight = 0.0, x = 0.0, y = 0.0;
  for (var i = 0; i < ring.length; i++) {
    final a = ring[i], b = ring[(i + 1) % ring.length], cross = _cross(a, b);
    weight += cross;
    x += (a.x + b.x) * cross;
    y += (a.y + b.y) * cross;
  }
  if (weight.abs() < .001) return entrance;
  final centre = XY(x / (3 * weight), y / (3 * weight));
  if (_contains(centre, ring)) return frame.unproject(centre);
  final loX = ring.map((p) => p.x).reduce(min),
      hiX = ring.map((p) => p.x).reduce(max);
  final loY = ring.map((p) => p.y).reduce(min),
      hiY = ring.map((p) => p.y).reduce(max);
  var best = frame.project(entrance), bestScore = -double.infinity;
  for (var i = 0; i < 12; i++) {
    for (var j = 0; j < 12; j++) {
      final p = XY(
        loX + (hiX - loX) * (i + .5) / 12,
        loY + (hiY - loY) * (j + .5) / 12,
      );
      if (!_contains(p, ring)) continue;
      final score = _boundaryDistance(p, ring) - p.distanceTo(centre) * .2;
      if (score > bestScore) {
        best = p;
        bestScore = score;
      }
    }
  }
  return frame.unproject(best);
}

/// Divide the perimeter into short, length-weighted sections so a side with
/// many corners does not count for more than its actual length.
List<({LatLng point, double length})> pipeBoundarySamples(
  List<LatLng> boundary,
) {
  final frame = _Projection(boundary.first);
  final points = boundary.map(frame.project).toList();
  final samples = <({LatLng point, double length})>[];
  for (var i = 0; i < points.length; i++) {
    final a = points[i], b = points[(i + 1) % points.length];
    final length = a.distanceTo(b);
    if (length == 0) continue;
    final steps = (length / 6).ceil();
    for (var j = 0; j < steps; j++) {
      samples.add((
        point: frame.unproject(a + (b - a) * ((j + .5) / steps)),
        length: length / steps,
      ));
    }
  }
  return samples;
}

bool pipeSegmentCovers(LatLng point, LatLng start, LatLng end) {
  final frame = _Projection(start);
  final p = frame.project(point), b = frame.project(end);
  return _nearest(p, const XY(0, 0), b).distanceTo(p) <= pipeBoundaryTolerance;
}

/// Find the nearest point on a laid pipe, including between GPS fixes.
LatLng? nearestPipeJoin(
  LatLng end,
  List<LatLng> currentPath,
  Iterable<List<LatLng>> installedPaths,
) {
  final frame = _Projection(end);
  const origin = XY(0, 0);
  XY? best;
  var bestDistance = pipeJoinDistance;

  void scan(List<LatLng> path, {required bool current}) {
    var walkedBack = 0.0;
    for (var i = path.length - 1; i > 0; i--) {
      final a = frame.project(path[i]);
      final b = frame.project(path[i - 1]);
      final candidate = _nearest(origin, a, b);
      final gap = candidate.distanceTo(origin);
      final distanceAlongPipe = walkedBack + a.distanceTo(candidate);
      walkedBack += a.distanceTo(b);
      // Ignore the live tip and the continuous tail behind the walker.
      if (current && distanceAlongPipe < max(25, gap + 12)) continue;
      if (gap > bestDistance || (best != null && gap == bestDistance)) {
        continue;
      }
      best = candidate;
      bestDistance = gap;
    }
  }

  scan(currentPath, current: true);
  for (final path in installedPaths) {
    scan(path, current: false);
  }
  return best == null ? null : frame.unproject(best!);
}

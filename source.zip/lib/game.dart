import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart';

import 'fence_geometry.dart';
import 'farm_upgrades.dart';
import 'water_system.dart';
import 'homestead.dart';
import 'journey_history.dart';

const start = LatLng(-34.9285, 138.6007);
double meters(LatLng a, LatLng b) =>
    const Distance(roundResult: false).as(LengthUnit.Meter, a, b);
List<double> coords(LatLng p) => [p.latitude, p.longitude];
LatLng point(dynamic a) =>
    LatLng((a[0] as num).toDouble(), (a[1] as num).toDouble());

enum Crop {
  radishes('Radishes', 'radishes', '🌱', 7, 1, .12),
  carrots('Carrots', 'carrots', '🥕', 7, 1.2, .20),
  pumpkins('Pumpkins', 'pumpkins', '🎃', 14, 1.75, .30),
  potatoes('Potatoes', 'potatoes', '🥔', 14, 1.5, .24);

  const Crop(
    this.label,
    this.stock,
    this.icon,
    this.days,
    this.yieldFactor,
    this.firstHarvest,
  );
  final String label, stock, icon;
  final int days;
  final double yieldFactor, firstHarvest;
  Duration get duration => Duration(days: days);
  int get waterPerHour => switch (this) {
    Crop.radishes => 1,
    Crop.carrots => 2,
    Crop.potatoes => 2,
    Crop.pumpkins => 3,
  };
}

enum WalkFeedback { easy, comfortable, tooMuch }

class OutingSummary {
  const OutingSummary(
    this.distance,
    this.seconds,
    this.discoveries,
    this.found,
    this.harvested,
    this.goal,
  );
  final double distance;
  final int seconds, discoveries, goal;
  final Map<String, int> found, harvested;
  Map<String, dynamic> json() => {
    'distance': distance,
    'seconds': seconds,
    'discoveries': discoveries,
    'found': found,
    'harvested': harvested,
    'goal': goal,
  };
  factory OutingSummary.from(Map<String, dynamic> j) => OutingSummary(
    (j['distance'] as num).toDouble(),
    j['seconds'],
    j['discoveries'],
    Map<String, int>.from(j['found']),
    Map<String, int>.from(j['harvested']),
    j['goal'],
  );
}

class FarmPipe {
  FarmPipe(
    this.wellId, {
    this.installed = false,
    this.enabled = true,
    List<LatLng>? path,
  }) : path = path ?? [];
  final int wellId;
  bool installed, enabled;
  List<LatLng> path;
  Map<String, dynamic> json() => {
    'well': wellId,
    'installed': installed,
    'enabled': enabled,
    'path': path.map(coords).toList(),
  };
  factory FarmPipe.from(Map data) => FarmPipe(
    data['well'],
    installed: data['installed'] == true,
    enabled: data['enabled'] != false,
    path: (data['path'] as List? ?? []).map(point).toList(),
  );
}

class Place {
  String name, kind;
  LatLng pos;
  List<LatLng> fence;
  List<LatLng> fenceBeforeCleanup;
  int planted;
  Crop crop;
  final FarmImprovements improvements;
  final WellUpgrades well;
  int? waterCheckedAt;
  bool dry;
  final List<FarmPipe> pipes;
  int pipeSlots, gardenTier, shedTier;
  final Map<HomeProject, int> projects;
  bool compostApplied;
  int? markerColor;
  String? markerEmoji;
  int? get pipeWell => pipes.firstOrNull?.wellId;
  bool get pipeActive => pipes.any((pipe) => pipe.installed);
  List<LatLng> get pipePath => pipes.firstOrNull?.path ?? [];
  bool get pipeOn => pipes.any((pipe) => pipe.installed && pipe.enabled);
  String get icon =>
      markerEmoji ??
      switch (kind) {
        'home' => '🏡',
        'well' => '🪣',
        _ => crop.icon,
      };
  Place(
    this.name,
    this.kind,
    this.pos, {
    List<LatLng>? fence,
    List<LatLng>? fenceBeforeCleanup,
    int? planted,
    this.crop = Crop.carrots,
    FarmImprovements? improvements,
    WellUpgrades? well,
    this.waterCheckedAt,
    int? pipeWell,
    this.dry = false,
    bool pipeActive = false,
    List<LatLng>? pipePath,
    List<FarmPipe>? pipes,
    this.pipeSlots = 1,
    this.markerColor,
    this.markerEmoji,
    this.gardenTier = 1,
    this.shedTier = 1,
    this.compostApplied = false,
    Map<HomeProject, int>? projects,
  }) : projects = projects ?? {},
       pipes =
           pipes ??
           [
             if (pipeWell != null)
               FarmPipe(pipeWell, installed: pipeActive, path: pipePath),
           ],
       well = well ?? WellUpgrades(),
       improvements = improvements ?? FarmImprovements(),
       fence = fence ?? [],
       fenceBeforeCleanup = fenceBeforeCleanup ?? [],
       planted = planted ?? DateTime.now().millisecondsSinceEpoch;
  double get area {
    if (fence.length < 3) return 0;
    final origin = fence.first;
    final p = fence
        .map(
          (v) => Point(
            (v.longitude - origin.longitude) *
                111320 *
                cos(origin.latitude * pi / 180),
            (v.latitude - origin.latitude) * 111320,
          ),
        )
        .toList();
    double s = 0;
    for (int i = 0; i < p.length; i++) {
      final b = p[(i + 1) % p.length];
      s += p[i].x * b.y - b.x * p[i].y;
    }
    return s.abs() / 2;
  }

  int get capacity => kind == 'well'
      ? well.capacity
      : kind == 'home'
      ? (fence.length >= 3 ? 8 + (shedTier - 1) * 6 : 0)
      : area > 0
      ? max(1, (area / 40 * crop.yieldFactor).round())
      : 0;

  int get yieldCapacity => improvements.fenceDamaged && capacity > 0
      ? max(1, (capacity * (100 - improvements.fenceYieldLoss) / 100).round())
      : capacity;

  LatLng get markerPosition => fence.length < 3 ? pos : fenceCentre(fence, pos);
  String get resource => switch (kind) {
    'well' => 'water',
    'home' => 'seeds',
    _ => crop.stock,
  };
  int get storage => kind == 'farm'
      ? capacity *
            FarmUpgrade.storagePercent(
              improvements.level(FarmUpgrade.farmhouse),
            ) ~/
            100
      : capacity;
  double get growthRate =>
      FarmUpgrade.speedPercent(improvements.level(FarmUpgrade.sprinklers)) /
      100;
  int get growthDurationMs => kind == 'well'
      ? well.rechargeMinutes * 60000
      : (crop.duration.inMilliseconds / growthRate).round();
  double growth(int now) =>
      ((productionTime(now) - planted) / growthDurationMs).clamp(0.0, 1.0);
  int productionTime(int now) => kind == 'farm' && waterCheckedAt != null
      ? min(now, waterCheckedAt!)
      : now;
  int available(int now) {
    if (capacity == 0) return 0;
    if (kind == 'well')
      return well.canDraw(now) ? well.stockAt(now, planted).floor() : 0;
    if (kind == 'home')
      return ((now - planted) ~/
              (Duration.millisecondsPerHour * (4 - gardenTier)))
          .clamp(0, capacity);
    final age = max(0, productionTime(now) - planted);
    if (kind == 'farm' && age < crop.firstHarvest * growthDurationMs) return 0;
    return standingCrops(now);
  }

  int standingCrops(int now) {
    final age = max(0, productionTime(now) - planted);
    return max(
      0,
      min(storage, yieldCapacity * age ~/ growthDurationMs) -
          improvements.lostCrops,
    );
  }

  int get readyAt =>
      planted +
      (kind == 'well'
          ? const Duration(minutes: 12).inMilliseconds
          : (growthDurationMs *
                    max(
                      crop.firstHarvest,
                      (1 + improvements.lostCrops) / max(1, yieldCapacity),
                    ))
                .ceil());
  int get fullAt => planted + growthDurationMs;
  int get storageFullAt =>
      planted + (growthDurationMs * storage / max(1, yieldCapacity)).ceil();
  Map<String, dynamic> json() => {
    'name': name,
    'kind': kind,
    'pos': coords(pos),
    'fence': fence.map(coords).toList(),
    'fenceBeforeCleanup': fenceBeforeCleanup.map(coords).toList(),
    'planted': planted,
    'crop': crop.name,
    'markerColor': markerColor,
    'markerEmoji': markerEmoji,
    if (kind == 'home') ...{
      'gardenTier': gardenTier,
      'shedTier': shedTier,
      'projects': {
        for (final entry in projects.entries) entry.key.name: entry.value,
      },
    },
    if (kind == 'farm') ...{
      'improvements': improvements.json(),
      'waterCheckedAt': waterCheckedAt,
      'pipes': pipes.map((pipe) => pipe.json()).toList(),
      'pipeSlots': pipeSlots,
      'dry': dry,
      'compostApplied': compostApplied,
    },
    if (kind == 'well') 'well': well.json(),
  };
  factory Place.from(Map<String, dynamic> j) => Place(
    j['name'],
    j['kind'],
    point(j['pos']),
    fence: (j['fence'] as List).map(point).toList(),
    fenceBeforeCleanup: (j['fenceBeforeCleanup'] as List? ?? [])
        .map(point)
        .toList(),
    planted: j['planted'],
    well: WellUpgrades.from(j['well'] as Map? ?? {}),
    waterCheckedAt: j['waterCheckedAt'],
    pipeWell: j['pipeWell'],
    pipes: (j['pipes'] as List?)?.map((data) => FarmPipe.from(data)).toList(),
    pipeSlots: (j['pipeSlots'] as int? ?? 1).clamp(1, 3),
    markerColor: j['markerColor'],
    markerEmoji: j['markerEmoji'],
    gardenTier: (j['gardenTier'] as int? ?? 1).clamp(1, 3),
    shedTier: (j['shedTier'] as int? ?? 1).clamp(1, 3),
    projects: {
      for (final project in HomeProject.values)
        if ((j['projects'] as Map?)?[project.name] case final int time)
          project: time,
    },
    compostApplied: j['compostApplied'] == true,
    pipeActive: j['pipeActive'] == true,
    pipePath: (j['pipePath'] as List? ?? []).map(point).toList(),
    dry: j['dry'] == true,
    improvements: FarmImprovements.from(
      Map<String, dynamic>.from(j['improvements'] as Map? ?? {}),
    ),
    crop:
        Crop.values.where((c) => c.name == j['crop']).firstOrNull ??
        Crop.carrots,
  );
}

class PipeWalk {
  PipeWalk(this.farm, this.well, this.remaining, LatLng start)
    : path = [well.pos, if (start != well.pos) start],
      perimeter = remaining.fold<double>(
        0,
        (total, sample) => total + sample.length,
      );
  final Place farm, well;
  final List<({LatLng point, double length})> remaining;
  final List<LatLng> path;
  final double perimeter;
  double covered = 0;
  bool get arrived => covered > 0;
  bool get perimeterReady => perimeter > 0 && covered >= perimeter * .6;
}

class Game extends ChangeNotifier {
  LatLng position = start;
  List<Place> places = [];
  List<LatLng> route = [], fence = [];
  Map<String, int> _bag = {
    'timber': 0,
    'stone': 0,
    'seeds': 6,
    'carrots': 0,
    'water': 0,
    'radishes': 0,
    'pumpkins': 0,
    'potatoes': 0,
    for (final project in HomeProject.values) project.resource: 0,
  };
  Map<String, int>? _debugBag;
  DateTime? _debugEnds;
  bool get infiniteResources => _debugEnds?.isAfter(_clock()) ?? false;
  Map<String, int> get bag => infiniteResources ? _debugBag! : _bag;

  void setInfiniteResources(bool enabled) {
    if (enabled && !infiniteResources) {
      _debugBag = {for (final key in _bag.keys) key: 999999};
      _debugEnds = _clock().add(const Duration(minutes: 10));
      changed('Infinite resources enabled for 10 minutes.');
    } else if (!enabled && _debugEnds != null) {
      _debugBag = null;
      _debugEnds = null;
      changed('Infinite resources ended. Your previous inventory is restored.');
    }
  }

  void expireInfiniteResources() {
    if (_debugEnds != null && !infiniteResources) setInfiniteResources(false);
  }

  VillagePet? pet;
  static const petFarmUnlock = 40;
  static const petTreatFriendship = 5;
  static const petWalkInterval = 100;
  static const _petLevelStarts = [0, 10, 25, petFarmUnlock];

  int petTreats = 0;
  int petFriendship = 0;
  double _petWalkRemainder = 0;
  bool _petStaysHome = false;
  int? _petFarmIndex;

  Place? get petFarm {
    final index = _petFarmIndex;
    if (pet == null || index == null || index < 0 || index >= places.length)
      return null;
    final farm = places[index];
    return farm.kind == 'farm' && farm.fence.length >= 3 ? farm : null;
  }

  bool get petFollows => pet != null && !_petStaysHome && petFarm == null;
  int get petFriendshipLevel =>
      _petLevelStarts.where((start) => petFriendship >= start).length;

  void _earnWalkFriendship(double distance) {
    if (!petFollows) return;
    _petWalkRemainder += distance;
    final earned = _petWalkRemainder ~/ petWalkInterval;
    if (earned == 0) return;
    _petWalkRemainder %= petWalkInterval;
    petFriendship += earned;
  }

  void setPetFollowing(bool follow) {
    if (pet == null || (petFarm == null && petFollows == follow)) return;
    advanceWater();
    advanceFarmRisks();
    _petFarmIndex = null;
    _petStaysHome = !follow;
    changed(
      follow ? 'Your pet is following you.' : 'Your pet is resting at home.',
    );
  }

  bool assignPetToFarm(Place farm) {
    if (pet == null ||
        petFriendship < petFarmUnlock ||
        !inFarm(farm) ||
        !places.contains(farm) ||
        petFarm == farm)
      return false;
    advanceWater();
    advanceFarmRisks();
    _petStaysHome = false;
    _petFarmIndex = places.indexOf(farm);
    changed('${pet!.label} is helping at ${farm.name}. ${pet!.farmBonus}.');
    return true;
  }

  bool herbsGiftedToRowan = false;
  final eventToasts = <String>[];

  bool findPet({VillagePet? species}) {
    if (home == null || pet != null) return false;
    pet = species ?? VillagePet.values[rng.nextInt(VillagePet.values.length)];
    final message =
        'New pet! A ${pet!.label.toLowerCase()} followed you home to ${home!.name}.';
    eventToasts.add(message);
    _recordJourney(JourneyKind.note, label: message, position: position);
    changed(message);
    return true;
  }

  bool customizePlace(Place place, String name, {int? color, String? emoji}) {
    if (!places.contains(place) || name.trim().isEmpty) return false;
    if (place.kind == 'farm' && place.fence.isNotEmpty && !inFarm(place)) {
      changed('Step inside the farm fence to make changes.');
      return false;
    }
    place.name = name.trim();
    if (place.kind == 'farm') {
      place.markerColor = color;
      place.markerEmoji = emoji;
    }
    _recordPlace(place, '${place.name} updated');
    changed('${place.name} updated.');
    return true;
  }

  Map<String, int> homeUpgradeCost(Place place, {required bool garden}) {
    final tier = garden ? place.gardenTier : place.shedTier;
    return {'timber': (garden ? 6 : 10) * tier, 'stone': 4 * tier};
  }

  bool upgradeHome(Place place, {required bool garden}) {
    if (place != home ||
        place.fence.length < 3 ||
        !inside(position, place.fence))
      return false;
    final tier = garden ? place.gardenTier : place.shedTier;
    final cost = homeUpgradeCost(place, garden: garden);
    if (tier >= 3 || !_canPay(cost)) return false;
    _pay(cost);
    if (garden) {
      final time = now;
      final elapsed = max(0, time - place.planted);
      place.planted = time - elapsed * (3 - tier) ~/ (4 - tier);
      place.gardenTier++;
    } else {
      place.shedTier++;
    }
    changed('${garden ? 'Seed garden' : 'Storage shed'} upgraded.');
    return true;
  }

  bool canBuildHomeProject(HomeProject project) {
    final place = home;
    return place != null &&
        inCollectionRange(place) &&
        !place.projects.containsKey(project) &&
        _canPay(project.cost);
  }

  void buildHomeProject(HomeProject project) {
    if (!canBuildHomeProject(project)) return;
    _pay(project.cost);
    home!.projects[project] = now;
    changed('${project.label} built at ${home!.name}.');
  }

  int homeStock(HomeProject project) {
    final start = home?.projects[project];
    if (start == null || project.hours == 0) return 0;
    return ((now - start) ~/ (project.hours * waterHour)).clamp(
      0,
      project.capacity,
    );
  }

  int collectHomeProject(HomeProject project) {
    final place = home;
    if (place == null || !inCollectionRange(place)) return 0;
    final count = homeStock(project);
    if (count == 0) return 0;
    final interval = project.hours * waterHour;
    final producedAt = place.projects[project]!;
    place.projects[project] = now - (now - producedAt) % interval;
    bag[project.resource] = (bag[project.resource] ?? 0) + count;
    changed(
      'Gathered $count ${project.resource} from your ${project.label.toLowerCase()}.',
    );
    return count;
  }

  bool get canCraftRepairKit {
    final place = home;
    return place != null &&
        inCollectionRange(place) &&
        place.projects.containsKey(HomeProject.workbench) &&
        _canPay(HomeProject.repairKitCost);
  }

  void craftRepairKit() {
    if (!canCraftRepairKit) return;
    _pay(HomeProject.repairKitCost);
    bag['repair kits'] = (bag['repair kits'] ?? 0) + 1;
    changed('Crafted a repair kit.');
  }

  bool applyCompost(Place farm) {
    const cost = {'compost': 1};
    if (!places.contains(farm) ||
        !inFarm(farm) ||
        farm.compostApplied ||
        !_canPay(cost))
      return false;
    advanceWater();
    final progress = farm.productionTime(now) - farm.planted;
    final remaining = farm.growthDurationMs - progress;
    if (remaining <= 0) return false;
    _pay(cost);
    farm.planted -= min(12 * waterHour, remaining);
    farm.compostApplied = true;
    changed('Compost applied to ${farm.name}. Crops grew up to 12 hours.');
    return true;
  }

  bool get canTreatPet =>
      pet != null &&
      (petFollows ||
          (petFarm != null && inFarm(petFarm!)) ||
          (_petStaysHome && home != null && inCollectionRange(home!))) &&
      (bag['herbs'] ?? 0) >= 1;

  void treatPet() {
    if (!canTreatPet) return;
    _pay({'herbs': 1});
    petTreats++;
    petFriendship += petTreatFriendship;
    changed(
      'Your ${pet!.label.toLowerCase()} enjoyed a garden treat. +$petTreatFriendship friendship.',
    );
  }

  bool get canGiftHerbs =>
      places.any((place) => place.kind == 'farm') &&
      !herbsGiftedToRowan &&
      (bag['herbs'] ?? 0) >= 2;

  void giftHerbs() {
    if (!canGiftHerbs) return;
    _pay({'herbs': 2});
    herbsGiftedToRowan = true;
    const message =
        'You gave Rowan herbs from your garden. “Ada grew these by the back step,” he says. “She always left a sprig on the gate before her evening walk.”';
    _recordJourney(JourneyKind.note, label: message, position: position);
    changed(message);
  }

  bool wellNeedsRepair(Place place) =>
      place.kind == 'well' &&
      (!place.well.canDraw(now) || place.well.siltUntil > now);

  bool repairWell(Place place) {
    const cost = {'repair kits': 1};
    if (!places.contains(place) || !inCollectionRange(place) || !_canPay(cost))
      return false;
    advanceWater();
    if (!wellNeedsRepair(place)) return false;
    final time = now;
    place.well.take(0, time, place.planted);
    place.well.siltUntil = 0;
    place.well.jammedUntil = 0;
    _pay(cost);
    changed('${place.name} repaired. Water is available to draw again.');
    return true;
  }

  double distance = 0, outingDistance = 0, discovery = 0;
  double nextDrop = 120;
  int offset = 0;
  final _outingClock = Stopwatch();
  int get elapsed => _outingClock.elapsed.inSeconds;
  bool walking = false, paused = false, spoofer = false, recording = false;
  bool homeSet = false;
  bool snapFencesToRoads = true;
  int harvests = 0;
  String comfort = 'Gentle · 10 minutes';
  List<String> log = [];
  String notice = 'Welcome home. Your little adventure starts here.';
  Game({Random? random, DateTime Function()? clock})
    : rng = random ?? Random(),
      _clock = clock ?? DateTime.now;
  final Random rng;
  final DateTime Function() _clock;
  int get now => _clock().millisecondsSinceEpoch + offset;
  Place? get home => places.where((p) => p.kind == 'home').firstOrNull;
  int fitnessAdjustment = 0;
  WalkFeedback? lastFeedback;
  OutingSummary? lastOuting;
  int outingDiscoveries = 0, outingGoal = 0;
  final outingFound = <String, int>{}, outingHarvested = <String, int>{};
  int get baseGoal => comfort.startsWith('Gentle')
      ? 700
      : comfort.startsWith('Regular')
      ? 1500
      : 3000;
  int get goal => (baseGoal * (1 + fitnessAdjustment / 100)).round();
  void recordFeedback(OutingSummary outing, WalkFeedback feedback) {
    if (!identical(lastOuting, outing) || lastFeedback != null) return;
    lastFeedback = feedback;
    final adjustment = switch (feedback) {
      WalkFeedback.easy => 10,
      WalkFeedback.comfortable => 0,
      WalkFeedback.tooMuch => -15,
    };
    fitnessAdjustment = (fitnessAdjustment + adjustment).clamp(-50, 50);
    changed('Suggested distance for your next outing: $goal m.');
  }

  void plant(Place farm, Crop crop) {
    if (!places.contains(farm) ||
        farm.kind != 'farm' ||
        farm.fence.length < 3 ||
        farm.crop == crop)
      return;
    if (!inFarm(farm)) {
      changed('Step inside the farm fence to change crops.');
      return;
    }
    advanceWater();
    advanceFarmRisks();
    farm.crop = crop;
    restartProduction(farm);
    changed('${crop.label} planted. Full yield in ${crop.days} days.');
  }

  final journey = <JourneyEvent>[];
  LatLng? _lastJourneyPoint;
  bool _newTrack = true;
  bool freeWalk = false;

  void _recordJourney(JourneyKind kind, {LatLng? position, String? label}) {
    journey.add(
      JourneyEvent(
        kind,
        DateTime.now().millisecondsSinceEpoch,
        position: position,
        label: label,
      ),
    );
  }

  void _recordPlace(Place place, String label) {
    final index = places.indexOf(place);
    if (index < 0) return;
    journey.add(
      JourneyEvent(
        JourneyKind.place,
        DateTime.now().millisecondsSinceEpoch,
        label: label,
        position: place.markerPosition,
        placeId: index,
        building: place.kind,
        fence: List.unmodifiable(place.fence),
      ),
    );
  }

  void _recordMovement(LatLng previous, LatLng position) {
    if (_newTrack) {
      _recordJourney(JourneyKind.trackStart, position: previous);
      _lastJourneyPoint = previous;
      _newTrack = false;
    }
    if (meters(_lastJourneyPoint!, position) >= 4) {
      _recordJourney(JourneyKind.point, position: position);
      _lastJourneyPoint = position;
    }
  }

  void _endTrack() {
    if (!_newTrack && _lastJourneyPoint != position) {
      _recordJourney(JourneyKind.point, position: position);
    }
    _newTrack = true;
    _lastJourneyPoint = null;
  }

  int get surplusCrops =>
      Crop.values.fold(0, (sum, crop) => sum + (bag[crop.stock] ?? 0));
  void _logMessage(String message, int at) {
    notice = message;
    log.insert(
      0,
      '${DateTime.fromMillisecondsSinceEpoch(at).toLocal().toString().substring(0, 16)}  $message',
    );
    if (log.length > 40) log.removeLast();
  }

  void changed([String? message]) {
    if (message != null) _logMessage(message, now);
    notifyListeners();
  }

  void setHome(LatLng p) {
    if (home != null) {
      if (home!.pos != p) {
        home!.fence = [];
        home!.fenceBeforeCleanup = [];
      }
      home!.pos = p;
    } else {
      places.add(Place('Home', 'home', p, planted: now));
    }
    homeSet = true;
    _recordPlace(home!, 'Farmhouse established');
    changed('Home established. Gather 5 timber and 3 stone for your farm.');
  }

  void startWalk({bool free = false}) {
    if (!walking) {
      walking = true;
      freeWalk = free;
      _newTrack = true;
      _recordJourney(
        JourneyKind.walkStart,
        label:
            '${free ? "Free" : "Story"} walk started${spoofer ? " · simulated" : ""}',
      );
      paused = false;
      outingDistance = 0;
      _outingClock
        ..reset()
        ..start();
      outingGoal = goal;
      outingDiscoveries = 0;
      outingFound.clear();
      outingHarvested.clear();
      route = [position];
      changed('Your wander has begun. Every little step counts.');
    } else {
      paused = !paused;
      if (paused) {
        _outingClock.stop();
        _endTrack();
      } else {
        _outingClock.start();
      }
      changed(paused ? 'Walk paused.' : 'Welcome back to the trail.');
    }
  }

  OutingSummary? finishWalk() {
    if (!walking) return null;
    _outingClock.stop();
    cancelPipeWalk();
    _endTrack();
    _recordJourney(
      JourneyKind.walkEnd,
      label: 'Walk finished · ${(outingDistance / 1000).toStringAsFixed(2)} km',
    );
    lastOuting = OutingSummary(
      outingDistance,
      elapsed,
      outingDiscoveries,
      Map.unmodifiable(outingFound),
      Map.unmodifiable(outingHarvested),
      outingGoal,
    );
    lastFeedback = null;
    walking = false;
    paused = false;
    recording = false;
    changed(
      'Walk finished: ${(outingDistance / 1000).toStringAsFixed(2)} km. Supplies are safely in your bag.',
    );
    fence = [];
    return lastOuting;
  }

  void teleport(LatLng p) {
    final cancelled = pipeWalk != null;
    cancelPipeWalk();
    if (walking) _endTrack();
    position = p;
    if (recording) {
      recording = false;
      fence = [];
    }
    if (walking) route = [p];
    changed(
      cancelled
          ? 'Teleported. Pipe walk cancelled. Restart at the well.'
          : 'Teleported. No distance awarded. Fence recording stopped.',
    );
  }

  void move(LatLng p) {
    final previous = position;
    final d = meters(previous, p);
    if (d > 0 && pipeWalk != null && (d >= 80 || paused)) {
      cancelPipeWalk();
      changed('Pipe walk interrupted. Restart at the well.');
    }
    if (walking && !paused && d >= 80) _endTrack();
    position = p;
    if (walking && !paused && d > 0 && d < 80) {
      _recordMovement(previous, p);
      trackPipe(previous, p);
      distance += d;
      _earnWalkFriendship(d);
      outingDistance += d;
      discovery += d;
      route.add(p);
      if (route.length > 4000) route.removeAt(0);
      if (recording) fence.add(p);
      while (discovery >= nextDrop) {
        discovery -= nextDrop;
        pickup(fromWalk: true);
        nextDrop = 100 + rng.nextInt(101).toDouble();
      }
    }
    notifyListeners();
  }

  void pickup({bool fromWalk = false}) {
    final k = ['timber', 'stone', 'seeds'][rng.nextInt(3)];
    final n = 2 + rng.nextInt(3);
    bag[k] = bag[k]! + n;
    if (fromWalk) {
      if (home != null && pet == null && rng.nextDouble() < .08) findPet();
      outingDiscoveries++;
      outingFound.update(k, (v) => v + n, ifAbsent: () => n);
    }
    changed('Found $n $k along the trail!');
  }

  static const waterHour = Duration.millisecondsPerHour;
  PipeWalk? pipeWalk;
  List<Place> connectedFarms(Place well) {
    final id = places.indexOf(well);
    return places
        .where(
          (farm) =>
              farm.kind == 'farm' &&
              farm.pipes.any((pipe) => pipe.wellId == id),
        )
        .toList();
  }

  bool canPipe(Place farm) =>
      farm.kind == 'farm' &&
      farm.fence.length >= 3 &&
      farm.improvements.level(FarmUpgrade.sprinklers) >= 2;
  Place? pipeSource(Place farm, [FarmPipe? connection]) {
    final i = (connection ?? farm.pipes.firstOrNull)?.wellId;
    if (i == null || i < 0 || i >= places.length || places[i].kind != 'well')
      return null;
    return places[i];
  }

  FarmPipe? connectionTo(Place well, Place farm) =>
      farm.pipes.where((pipe) => pipeSource(farm, pipe) == well).firstOrNull;

  Map<String, int> pipeUpgradeCost(Place farm) => {
    'timber': 10 * farm.pipeSlots,
    'stone': 8 * farm.pipeSlots,
  };

  bool upgradePipes(Place farm) {
    if (!places.contains(farm) ||
        !canPipe(farm) ||
        !inFarm(farm) ||
        farm.pipeSlots >= 3 ||
        !_canPay(pipeUpgradeCost(farm)))
      return false;
    _pay(pipeUpgradeCost(farm));
    farm.pipeSlots++;
    changed('${farm.name} can now connect to ${farm.pipeSlots} wells.');
    return true;
  }

  void togglePipe(Place farm, FarmPipe pipe, bool enabled) {
    if (!farm.pipes.contains(pipe) || !pipe.installed) return;
    advanceWater();
    pipe.enabled = enabled;
    changed('${farm.name} pipe ${enabled ? 'turned on' : 'turned off'}.');
  }

  bool _canPay(Map<String, int> cost) =>
      cost.entries.every((e) => (bag[e.key] ?? 0) >= e.value);
  void _pay(Map<String, int> cost) {
    for (final e in cost.entries) {
      bag[e.key] = bag[e.key]! - e.value;
    }
  }

  bool upgradeWell(Place place, {required bool recharge}) {
    if (!places.contains(place) || place.kind != 'well') return false;
    final level = recharge ? place.well.rechargeTier : place.well.yieldTier;
    final cost = WellUpgrades.cost(recharge, level);
    if (level >= 5 || !_canPay(cost)) return false;
    advanceWater();
    place.well.take(0, now, place.planted);
    _pay(cost);
    if (recharge) {
      place.well.rechargeTier++;
    } else {
      place.well.yieldTier++;
    }
    changed(
      'Well ${recharge ? 'recharge' : 'yield'} upgraded to tier ${level + 1}.',
    );
    return true;
  }

  bool buyPipe(Place well, Place farm) {
    if (!places.contains(well) ||
        well.kind != 'well' ||
        !places.contains(farm) ||
        !canPipe(farm) ||
        farm.pipes.length >= farm.pipeSlots ||
        connectionTo(well, farm) != null)
      return false;
    final cost = WellUpgrades.connectionCost(connectedFarms(well).length);
    if (!_canPay(cost)) return false;
    _pay(cost);
    farm.pipes.add(FarmPipe(places.indexOf(well)));
    changed('Pipe purchased. Start the installation walk at the well.');
    return true;
  }

  bool startPipeWalk(Place well, Place farm) {
    if (pipeWalk != null ||
        !canPipe(farm) ||
        connectionTo(well, farm)?.installed != false)
      return false;
    if (meters(position, well.pos) > 25) {
      changed('Move within 25 m of the well to start the pipe walk.');
      return false;
    }
    if (recording) {
      changed('Finish the fence walk first.');
      return false;
    }
    if (!walking || paused) startWalk(free: true);
    pipeWalk = PipeWalk(farm, well, pipeBoundarySamples(farm.fence), position);
    changed(
      'Pipe walk started. Walk from the well to the farm, then follow the fence until the connection is confirmed.',
    );
    return true;
  }

  void cancelPipeWalk() => pipeWalk = null;
  void trackPipe(LatLng previous, LatLng current) {
    final task = pipeWalk;
    if (task == null) return;
    task.path.add(current);
    task.remaining.removeWhere((sample) {
      if (!pipeSegmentCovers(sample.point, previous, current)) return false;
      task.covered += sample.length;
      return true;
    });
    if (task.perimeterReady) finishPipeWalk(automatic: true);
  }

  bool finishPipeWalk({bool automatic = false}) {
    final task = pipeWalk;
    if (task == null) return false;
    if (!task.perimeterReady) {
      if (!automatic) changed('Keep following the farm fence to lay the pipe.');
      return false;
    }
    final join = nearestPipeJoin(
      task.path.last,
      task.path,
      connectedFarms(task.well)
          .map((farm) => connectionTo(task.well, farm)!)
          .where((pipe) => pipe.installed)
          .map((pipe) => pipe.path),
    );
    if (join == null) {
      if (!automatic)
        changed('Move closer to an earlier section of pipe to connect.');
      return false;
    }
    advanceWater();
    final connection = connectionTo(task.well, task.farm)!;
    connection.installed = true;
    connection.path = [
      ...task.path,
      if (meters(task.path.last, join) > .01) join,
    ];
    cancelPipeWalk();
    _recordJourney(
      JourneyKind.note,
      label: 'Water pipe installed at ${task.farm.name}',
      position: task.farm.markerPosition,
    );
    changed('Direct watering activated for ${task.farm.name}.');
    return true;
  }

  void ripenBuildings() {
    advanceWater();
    for (final p in places) {
      if (p.kind == 'well') {
        p.well.buffer = p.capacity.toDouble();
        p.well.checkedAt = now;
      }
      if (p.kind == 'farm') {
        p.planted = p.productionTime(now) - p.growthDurationMs;
        p.dry = false;
        p.improvements.lostCrops = 0;
      }
    }
    changed('All production buildings are ready.');
  }

  void advanceWater() {
    final time = now;
    final farms = places
        .where(
          (p) =>
              p.kind == 'farm' &&
              p.fence.length >= 3 &&
              p.waterCheckedAt != null,
        )
        .toList();
    var advanced = false;
    while (true) {
      final due = farms.fold(
        time + 1,
        (first, p) => min(first, p.waterCheckedAt! + waterHour),
      );
      if (due > time) break;
      advanced = true;
      _advanceWellRisks(due);
      for (final farm in farms.where(
        (p) => p.waterCheckedAt! + waterHour == due,
      )) {
        final demand = farm.crop.waterPerHour;
        final draws = <Place, int>{};
        var fromBag = demand;
        if (canPipe(farm)) {
          for (final pipe in farm.pipes.where(
            (pipe) => pipe.installed && pipe.enabled,
          )) {
            final source = pipeSource(farm, pipe);
            if (fromBag == 0) break;
            if (source == null) continue;
            final draw = min(fromBag, source.available(due));
            if (draw > 0) draws[source] = draw;
            fromBag -= draw;
          }
        }
        final full = farm.productionTime(due) >= farm.storageFullAt;
        farm.dry = !full && (bag['water'] ?? 0) < fromBag;
        if (full || farm.dry) {
          farm.planted += waterHour;
        } else {
          for (final entry in draws.entries) {
            entry.key.well.take(entry.value, due, entry.key.planted);
          }
          bag['water'] = bag['water']! - fromBag;
        }
        farm.waterCheckedAt = due;
      }
      advanceFarmRisks(at: due);
    }
    if (advanced) changed();
  }

  static const _farmDay = Duration.millisecondsPerDay;

  void restartProduction(Place place) {
    if (place.waterCheckedAt != null) {
      place.waterCheckedAt = now;
      place.dry = false;
    }
    place.planted = now;
    place.compostApplied = false;
    place.improvements.lostCrops = 0;
    if (place.improvements.nextRiskAt != null)
      place.improvements.nextRiskAt = now + _farmDay;
  }

  bool upgradeFarm(Place farm, FarmUpgrade upgrade) {
    if (!places.contains(farm) || farm.kind != 'farm' || farm.fence.length < 3)
      return false;
    if (!inFarm(farm)) {
      changed('Step inside the farm fence to make upgrades.');
      return false;
    }
    final state = farm.improvements;
    final next = state.level(upgrade) + 1;
    if (next > FarmUpgrade.maxTier) return false;
    final cost = upgrade.cost(next);
    if (cost.entries.any((item) => (bag[item.key] ?? 0) < item.value))
      return false;
    advanceWater();
    advanceFarmRisks();
    final time = farm.productionTime(now);
    final previousDuration = farm.growthDurationMs;
    for (final item in cost.entries) {
      bag[item.key] = bag[item.key]! - item.value;
    }
    state.tiers[upgrade] = next;
    if (upgrade == FarmUpgrade.sprinklers) {
      // Keep growth already earned and apply the new speed going forward.
      farm.planted =
          time -
          ((time - farm.planted) * farm.growthDurationMs / previousDuration)
              .round();
    }
    if (upgrade == FarmUpgrade.fence) state.repairFence();
    _recordJourney(
      JourneyKind.note,
      label: '${farm.name} upgraded to ${upgrade.tiers[next - 1]}',
      position: farm.markerPosition,
    );
    changed('${farm.name} upgraded to ${upgrade.tiers[next - 1]}.');
    return true;
  }

  static const fenceRepairTimber = 4;
  bool repairFarmFence(Place farm, {bool useKit = false}) {
    if (!places.contains(farm) || !inFarm(farm)) {
      changed('Step inside the farm fence to repair it.');
      return false;
    }
    advanceFarmRisks();
    final cost = useKit ? {'repair kits': 1} : {'timber': fenceRepairTimber};
    if (!farm.improvements.fenceDamaged || !_canPay(cost)) return false;
    _pay(cost);
    farm.improvements.repairFence();
    changed('${farm.name} fence repaired.');
    return true;
  }

  bool triggerFarmEvent(Place farm, {FarmEvent? event}) {
    if (!places.contains(farm) || farm.kind != 'farm' || farm.area <= 0) {
      return false;
    }
    advanceWater();
    final time = now;
    final options = [
      FarmEvent.birds,
      _seasonalWeather(farm, time),
      FarmEvent.brokenFence,
    ];
    _applyFarmEvent(farm, event ?? options[rng.nextInt(options.length)], time);
    changed();
    return true;
  }

  FarmEvent _seasonalWeather(Place farm, int at) {
    // The farm's longitude supplies an approximate local calendar date even
    // when the player is travelling or using the GPS simulator overseas.
    final date = DateTime.fromMillisecondsSinceEpoch(
      at,
      isUtc: true,
    ).add(Duration(minutes: (farm.pos.longitude * 4).round()));
    return FarmEvent.seasonalWeather(date, farm.pos.latitude);
  }

  void _applyFarmEvent(Place farm, FarmEvent event, int at) {
    final state = farm.improvements;
    final standing = farm.standingCrops(at);
    final severity = rng.nextDouble();
    final loss = standing == 0
        ? 0
        : max(1, (standing * (.04 + .36 * severity * severity)).round());
    state.lostCrops += loss;
    final String detail;
    switch (event) {
      case FarmEvent.birds:
        final birds = 5 + rng.nextInt(46);
        detail = '$birds birds swarmed ${farm.name}, destroying $loss crops.';
      case FarmEvent.heavyRain:
        detail = 'Heavy rain flooded ${farm.name}, killing $loss crops.';
      case FarmEvent.drought:
        detail = 'Drought dried out ${farm.name}, killing $loss crops.';
      case FarmEvent.brokenFence:
        final cause = const [
          'A rabbit broke the fence while digging under it',
          'A deer broke the fence while trying to jump over it',
          'A wild boar broke the fence while digging for roots',
          'A falling branch broke a section of fence',
          'A fox broke the fence while squeezing through a gap',
        ][rng.nextInt(5)];
        final penalty = rng.nextDouble();
        state.fenceDamaged = true;
        state.fenceYieldLoss = max(
          state.fenceYieldLoss,
          5 + (35 * penalty * penalty).round(),
        );
        detail =
            '$cause at ${farm.name}, destroying $loss crops and reducing yield by ${state.fenceYieldLoss}% until repaired.';
    }
    final message = '${event.title} $detail';
    state.lastIncident = message;
    eventToasts.add(message);
    _logMessage(message, at);
    _recordJourney(
      JourneyKind.note,
      label: message,
      position: farm.markerPosition,
    );
  }

  bool triggerWellEvent(Place well, {WellEvent? event}) {
    if (!places.contains(well) || well.kind != 'well') return false;
    advanceWater();
    _applyWellEvent(
      well,
      event ?? WellEvent.values[rng.nextInt(WellEvent.values.length)],
      now,
    );
    changed();
    return true;
  }

  void _applyWellEvent(Place place, WellEvent event, int at) {
    final well = place.well;
    final String detail;
    switch (event) {
      case WellEvent.crackedLining:
        final loss = (well.stockAt(at, place.planted) / 2).floor();
        well.take(loss, at, place.planted);
        detail = 'A crack in the lining drained $loss stored water.';
      case WellEvent.siltBuildup:
        well.take(0, at, place.planted);
        well.siltUntil = at + _farmDay;
        detail = 'Sediment washed into the well. It refills at half speed for 24 hours.';
      case WellEvent.jammedPump:
        well.jammedUntil = at + _farmDay ~/ 2;
        detail =
            'Debris jammed the pump. Draws and pipes are blocked for 12 hours.';
    }
    final message = '${event.title}! ${place.name}. $detail';
    well.lastIncident = message;
    eventToasts.add(message);
    _logMessage(message, at);
    _recordJourney(JourneyKind.note, label: message, position: place.pos);
  }

  bool _advanceWellRisks(int time) {
    var advanced = false;
    for (final well in places.where((place) => place.kind == 'well')) {
      final state = well.well;
      final due = state.nextRiskAt ??= time + _farmDay;
      if (due > time) continue;
      final days = (time - due) ~/ _farmDay + 1;
      for (var i = max(0, days - 90); i < days; i++) {
        final at = due + i * _farmDay;
        if (at < (state.checkedAt ?? well.planted)) continue;
        if (rng.nextDouble() < .10) {
          _applyWellEvent(
            well,
            WellEvent.values[rng.nextInt(WellEvent.values.length)],
            at,
          );
        }
      }
      state.nextRiskAt = due + days * _farmDay;
      advanced = true;
    }
    return advanced;
  }

  void advanceFarmRisks({int? at}) {
    final time = at ?? now;
    var advanced = _advanceWellRisks(time);
    for (final farm in places) {
      final state = farm.improvements;
      final due = state.nextRiskAt;
      if (farm.kind != 'farm' ||
          farm.fence.length < 3 ||
          due == null ||
          due > time) {
        continue;
      }
      advanced = true;
      final elapsedDays = (time - due) ~/ _farmDay + 1;
      final fenceTier = state.level(FarmUpgrade.fence);
      final scarecrowTier = state.level(FarmUpgrade.scarecrow);
      final helper = farm == petFarm ? pet : null;
      final fenceRisk =
          FarmUpgrade.breakRisk(fenceTier) *
          (helper == VillagePet.dog ? 1 - VillagePet.riskReduction : 1);
      final birdRisk =
          FarmUpgrade.birdRisk(scarecrowTier) *
          (helper == VillagePet.cat ? 1 - VillagePet.riskReduction : 1);
      for (var i = max(0, elapsedDays - 90); i < elapsedDays; i++) {
        final day = due + i * _farmDay;
        final age = ((day - farm.planted) / (14 * _farmDay)).clamp(0.0, .5);
        final risk = (1 + age) * (state.fenceDamaged ? 1.8 : 1);
        if (!state.fenceDamaged && rng.nextDouble() < risk * fenceRisk) {
          _applyFarmEvent(farm, FarmEvent.brokenFence, day);
        } else if (farm.standingCrops(day) > 0) {
          if (rng.nextDouble() < risk * birdRisk) {
            _applyFarmEvent(farm, FarmEvent.birds, day);
          } else if (rng.nextDouble() < risk * .08) {
            _applyFarmEvent(farm, _seasonalWeather(farm, day), day);
          }
        }
      }
      state.nextRiskAt = due + elapsedDays * _farmDay;
    }
    if (advanced) changed();
  }

  void skip(Duration d) {
    if (d.inMilliseconds <= 0) throw ArgumentError('Choose a future time.');
    offset += d.inMilliseconds;
    advanceWater();
    _logMessage(
      'Advanced village time by ${d.inHours} hours. Your buildings kept producing.',
      now,
    );
    advanceFarmRisks();
    changed();
  }

  bool build(String kind, LatLng p, {bool useCrops = false, String? farmName}) {
    if (!homeSet) {
      changed('Set your home first.');
      return false;
    }
    final cropTrade = kind == 'well' && useCrops;
    if (cropTrade && surplusCrops < 10) {
      changed('Need 10 harvested crops for a well.');
      return false;
    }
    final cost = cropTrade
        ? {'timber': 4, 'stone': 6}
        : kind == 'farm'
        ? {'timber': 5, 'stone': 3}
        : {'timber': 8, 'stone': 6};
    if (cost.entries.any((e) => bag[e.key]! < e.value)) {
      changed('Need ${cost['timber']} timber and ${cost['stone']} stone.');
      return false;
    }
    for (final e in cost.entries) {
      bag[e.key] = bag[e.key]! - e.value;
    }
    if (cropTrade) {
      int remaining = 10;
      for (final crop in Crop.values) {
        final n = min(remaining, bag[crop.stock] ?? 0);
        bag[crop.stock] = (bag[crop.stock] ?? 0) - n;
        remaining -= n;
      }
    }
    final name = farmName?.trim() ?? '';
    places.add(
      Place(
        kind == 'farm' ? (name.isEmpty ? 'Carrot Farm' : name) : 'Village Well',
        kind,
        p,
        planted: now,
        well: kind == 'well' ? WellUpgrades(nextRiskAt: now + _farmDay) : null,
      ),
    );
    _recordPlace(
      places.last,
      kind == 'farm' ? '${places.last.name} built' : 'Village well built',
    );
    changed(
      '${places.last.name} built. ${kind == 'farm' ? 'Walk its fence to expand production.' : 'Water is on its way.'}',
    );
    return true;
  }

  void beginFence() {
    cancelPipeWalk();
    if (!walking) {
      startWalk();
    }
    if (paused) startWalk();
    fence = [position];
    recording = true;
    changed(
      'Walk around your plot. Finish within 12 m of any older fence section.',
    );
  }

  bool finishFence(
    Place p, {
    List<List<LatLng>> roads = const [],
    String? roadNote,
  }) {
    final result = findFenceBoundary(fence, p.pos, roads: roads);
    if (result == null) {
      changed(
        'Walk a full loop around the farm (at least 40 m²), then finish within 12 m of any older fence section.',
      );
      return false;
    }
    p.fenceBeforeCleanup = result.removedPoints > 0
        ? List.of(result.beforeCleanup)
        : [];
    if (pipeWalk?.farm == p) cancelPipeWalk();
    if (p.kind == 'home' && p.fence.isEmpty) p.planted = now;
    if (p.kind == 'farm' && p.fence.isEmpty) {
      p.improvements.nextRiskAt = now + _farmDay;
      p.waterCheckedAt = now;
      restartProduction(p);
    }
    p.fence = result.points;
    _recordPlace(
      p,
      '${p.kind == 'home' ? 'Home' : 'Farm'} fence finished · ${p.area.round()} m²',
    );
    fence = [];
    recording = false;
    changed(
      'Fence finished! ${p.area.round()} m². ${result.removedPoints > 0 ? 'Straightened ${result.removedPoints} boundary points.' : 'No extra bends removed.'}${result.snappedPoints > 0 ? ' Nearby road sections snapped.' : ''}${roadNote == null ? '' : ' $roadNote'}',
    );
    return true;
  }

  bool applyFenceCleanup(Place p, {double maxDeviation = 8}) {
    final result = neatenFence(p.fence, p.pos, maxDeviation: maxDeviation);
    if (!result.changed) {
      changed(
        result.safe
            ? 'No extra bends can be safely removed at this strength.'
            : 'This boundary could not be safely straightened.',
      );
      return false;
    }
    if (pipeWalk?.farm == p) cancelPipeWalk();
    p.fenceBeforeCleanup = List.of(p.fence);
    p.fence = List.of(result.points);
    _recordPlace(p, 'Farm fence neatened');
    changed(
      'Fence neatened: ${result.beforeCount} → ${result.points.length} boundary points. Undo is available.',
    );
    return true;
  }

  void undoFenceCleanup(Place p) {
    if (p.fenceBeforeCleanup.isEmpty) return;
    if (pipeWalk?.farm == p) cancelPipeWalk();
    p.fence = List.of(p.fenceBeforeCleanup);
    p.fenceBeforeCleanup = [];
    _recordPlace(p, 'Farm fence restored');
    changed('Restored the previous fence shape.');
  }

  bool inside(LatLng p, List<LatLng> vs) {
    bool c = false;
    for (int i = 0, j = vs.length - 1; i < vs.length; j = i++) {
      if (((vs[i].latitude > p.latitude) != (vs[j].latitude > p.latitude)) &&
          (p.longitude <
              (vs[j].longitude - vs[i].longitude) *
                      (p.latitude - vs[i].latitude) /
                      (vs[j].latitude - vs[i].latitude) +
                  vs[i].longitude))
        c = !c;
    }
    return c;
  }

  bool inFarm(Place place) =>
      place.kind == 'farm' &&
      place.fence.length >= 3 &&
      inside(position, place.fence);

  bool inCollectionRange(Place place) => place.kind == 'home'
      ? place.fence.length >= 3 && inside(position, place.fence)
      : meters(position, place.pos) <= 45 || inFarm(place);

  String collectionRangeHint(Place place) => place.kind == 'farm'
      ? 'Step inside the farm fence or within 45 m of its entrance to collect.'
      : place.kind == 'home'
      ? 'Step inside your home fence to gather seeds.'
      : 'Move within 45 m of the well to collect.';

  int collect(Place p) {
    if (!inCollectionRange(p)) {
      changed(collectionRangeHint(p));
      return 0;
    }
    advanceWater();
    advanceFarmRisks();
    final base = p.available(now);
    if (base == 0) {
      changed('Still growing. Come back a little later.');
      return 0;
    }
    final bonus = p == petFarm && pet == VillagePet.bunny
        ? (base * VillagePet.harvestBonus).round()
        : 0;
    final n = base + bonus;
    bag.update(p.resource, (v) => v + n, ifAbsent: () => n);
    if (walking)
      outingHarvested.update(p.resource, (v) => v + n, ifAbsent: () => n);
    if (p.kind == 'well') {
      p.well.take(n, now, p.planted);
    } else {
      restartProduction(p);
    }
    if (p.kind == 'farm') harvests++;
    _recordJourney(
      JourneyKind.note,
      label: 'Collected $n ${p.resource}',
      position: position,
    );
    changed(
      bonus > 0
          ? 'Collected $n ${p.resource}, including $bonus from your bunny.'
          : 'Collected $n ${p.resource}. Lovely work.',
    );
    return n;
  }

  Map<String, dynamic> json() => {
    'version': 1,
    'position': coords(position),
    'places': places.map((p) => p.json()).toList(),
    'bag': _bag,
    if (infiniteResources)
      'debugResourcesUntil': _debugEnds!.millisecondsSinceEpoch,
    'pet': pet?.name,
    'petTreats': petTreats,
    'petFriendship': petFriendship,
    'petWalkRemainder': _petWalkRemainder,
    'petStaysHome': _petStaysHome,
    'petFarm': _petFarmIndex,
    'herbsGiftedToRowan': herbsGiftedToRowan,
    'distance': distance,
    'offset': offset,
    'homeSet': homeSet,
    'harvests': harvests,
    'comfort': comfort,
    'fitnessAdjustment': fitnessAdjustment,
    'lastOuting': lastOuting?.json(),
    'lastFeedback': lastFeedback?.name,
    'snapFencesToRoads': snapFencesToRoads,
    'log': log,
    'journey': journey.map((e) => e.json()).toList(),
  };
  void restore(Map<String, dynamic> j) {
    if (j['version'] != 1) throw FormatException('Unsupported save');
    final ps = (j['places'] as List)
        .map((e) => Place.from(Map<String, dynamic>.from(e)))
        .toList();
    final bg = Map<String, int>.from(j['bag']);
    if (![
      'timber',
      'stone',
      'seeds',
      'carrots',
      'water',
    ].every((k) => bg.containsKey(k) && bg[k]! >= 0))
      throw FormatException('Invalid inventory');
    for (final crop in Crop.values) {
      bg.putIfAbsent(crop.stock, () => 0);
    }
    for (final project in HomeProject.values) {
      bg.putIfAbsent(project.resource, () => 0);
    }
    final pos = point(j['position']);
    if (pos.latitude.abs() > 85 || pos.longitude.abs() > 180)
      throw FormatException('Invalid coordinates');
    final history = (j['journey'] as List? ?? [])
        .map((entry) => JourneyEvent.from(List<dynamic>.from(entry)))
        .toList();
    places = ps;
    journey
      ..clear()
      ..addAll(history);
    if (j['journey'] == null) {
      for (final place in places) {
        _recordPlace(place, '${place.name} · existing at first recording');
      }
    }
    freeWalk = false;
    _newTrack = true;
    _lastJourneyPoint = null;
    _bag = bg;
    petTreats = j['petTreats'] as int? ?? 0;
    petFriendship = max(
      0,
      j['petFriendship'] as int? ?? petTreats * petTreatFriendship,
    );
    _petWalkRemainder = ((j['petWalkRemainder'] as num?)?.toDouble() ?? 0)
        .clamp(0, petWalkInterval - .001);
    _petStaysHome = j['petStaysHome'] == true;
    _petFarmIndex = j['petFarm'] as int?;
    herbsGiftedToRowan = j['herbsGiftedToRowan'] == true;
    pet = VillagePet.values
        .where((value) => value.name == j['pet'])
        .firstOrNull;
    final debugUntil = j['debugResourcesUntil'] as int?;
    _debugEnds = debugUntil == null
        ? null
        : DateTime.fromMillisecondsSinceEpoch(debugUntil);
    _debugBag = infiniteResources
        ? {for (final key in _bag.keys) key: 999999}
        : null;
    if (_debugBag == null) _debugEnds = null;
    eventToasts.clear();
    position = pos;
    distance = (j['distance'] as num).toDouble();
    offset = j['offset'];
    homeSet = j['homeSet'];
    harvests = j['harvests'] ?? 0;
    comfort = j['comfort'] ?? 'Gentle · 10 minutes';
    fitnessAdjustment = (j['fitnessAdjustment'] as int? ?? 0).clamp(-50, 50);
    lastFeedback = WalkFeedback.values
        .where((v) => v.name == j['lastFeedback'])
        .firstOrNull;
    lastOuting = j['lastOuting'] == null
        ? null
        : OutingSummary.from(Map<String, dynamic>.from(j['lastOuting']));
    snapFencesToRoads = j['snapFencesToRoads'] ?? true;
    log = List<String>.from(j['log'] ?? []);
    for (final place in places) {
      if (place.kind == 'well') place.well.nextRiskAt ??= now + _farmDay;
      if (place.kind == 'farm' && place.fence.length >= 3) {
        place.improvements.nextRiskAt ??= now + _farmDay;
        place.waterCheckedAt ??= now;
      }
    }
    _outingClock
      ..stop()
      ..reset();
    walking = false;
    paused = false;
    spoofer = false;
    recording = false;
    route = [];
    fence = [];
    cancelPipeWalk();
    changed('Village loaded.');
    advanceWater();
    advanceFarmRisks();
  }
}

/// A full joystick deflection at 1x is a gentle 1.4 m/s walk.
LatLng simulatedStep(
  LatLng origin, {
  required double horizontal,
  required double vertical,
  required double multiplier,
  required double seconds,
}) {
  final magnitude = sqrt(horizontal * horizontal + vertical * vertical);
  final divisor = max(1.0, magnitude);
  final travel = 1.4 * multiplier.clamp(1, 20) * seconds;
  return LatLng(
    origin.latitude - vertical / divisor * travel / 111320,
    origin.longitude +
        horizontal /
            divisor *
            travel /
            (111320 * cos(origin.latitude * pi / 180)),
  );
}

double fenceLength(List<LatLng> points) {
  double total = 0;
  for (int i = 1; i < points.length; i++) {
    total += meters(points[i - 1], points[i]);
  }
  return total;
}

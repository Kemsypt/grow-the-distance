import 'package:flutter/widgets.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

typedef IrrigationLink = ({LatLng well, LatLng farm, bool flowing});

class IrrigationLayer extends StatefulWidget {
  const IrrigationLayer({
    required this.links,
    required this.visible,
    super.key,
  });

  final List<IrrigationLink> links;
  final bool visible;

  @override
  State<IrrigationLayer> createState() => _IrrigationLayerState();
}

class _IrrigationLayerState extends State<IrrigationLayer>
    with SingleTickerProviderStateMixin {
  late final _flow = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 5),
  );

  @override
  void dispose() {
    _flow.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final flowing = widget.links.where((link) => link.flowing).toList();
    final animate =
        widget.visible &&
        flowing.isNotEmpty &&
        !MediaQuery.disableAnimationsOf(context);
    if (animate && !_flow.isAnimating) {
      _flow.repeat();
    } else if (!animate && _flow.isAnimating) {
      _flow.stop();
    }

    return IgnorePointer(
      child: Stack(
        fit: StackFit.expand,
        children: [
          PolylineLayer(
            polylines: [
              for (final link in widget.links)
                Polyline(
                  points: [link.well, link.farm],
                  color: const Color(0x59368caa),
                  strokeWidth: 2,
                ),
            ],
          ),
          if (animate)
            AnimatedBuilder(
              animation: _flow,
              builder: (context, _) => MarkerLayer(
                markers: [
                  for (final link in flowing)
                    for (final offset in [0.0, .5])
                      Marker(
                        point: _along(link, (_flow.value + offset) % 1),
                        width: 5,
                        height: 5,
                        child: const DecoratedBox(
                          decoration: BoxDecoration(
                            color: Color(0x8845b5d7),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  LatLng _along(IrrigationLink link, double progress) => LatLng(
    link.well.latitude + (link.farm.latitude - link.well.latitude) * progress,
    link.well.longitude +
        (link.farm.longitude - link.well.longitude) * progress,
  );
}

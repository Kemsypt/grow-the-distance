import 'dart:math';

import 'package:flutter/widgets.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' show LatLng;

/// Screen-space decoration follows the map camera, so rails/posts keep a legible
/// size at every zoom. Live trails stay open; only confirmed plots are closed.
class FenceLayer extends StatelessWidget {
  final List<List<LatLng>> completed;
  final List<LatLng> active;
  final List<int> tiers;
  const FenceLayer({
    super.key,
    required this.completed,
    required this.active,
    this.tiers = const [],
  });
  @override
  Widget build(BuildContext context) {
    final camera = MapCamera.of(context);
    return IgnorePointer(
      child: SizedBox.expand(
        child: CustomPaint(
          painter: FencePainter(
            completed: completed
                .map(
                  (p) =>
                      [...p, p.first].map(camera.latLngToScreenOffset).toList(),
                )
                .toList(),
            tiers: tiers,
            active: active.map(camera.latLngToScreenOffset).toList(),
          ),
        ),
      ),
    );
  }
}

class FencePainter extends CustomPainter {
  final List<List<Offset>> completed;
  final List<Offset> active;
  final List<int> tiers;
  const FencePainter({
    required this.completed,
    required this.active,
    this.tiers = const [],
  });
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    for (final (i, path) in completed.indexed) {
      _drawFence(canvas, size, path, tier: i < tiers.length ? tiers[i] : 1);
    }
    _drawFence(canvas, size, active);
    if (active.isNotEmpty) {
      final p = active.first;
      canvas.drawCircle(p, 10, Paint()..color = const Color(0xfffff3d6));
      canvas.drawCircle(
        p,
        8,
        Paint()
          ..color = const Color(0xff416841)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3,
      );
    }
    canvas.restore();
  }

  void _drawRails(Canvas canvas, List<Offset> input, Paint dark, Paint light) {
    if (input.length < 2) return;
    final closed =
        input.length > 2 && (input.first - input.last).distance < .01;
    final points = closed ? input.sublist(0, input.length - 1) : input;
    if (points.length < 2) return;
    Offset normal(Offset a, Offset b) {
      final d = b - a;
      return d.distance < .01 ? Offset.zero : Offset(-d.dy, d.dx) / d.distance;
    }

    for (final offset in [-2.5, 2.5]) {
      final rail = <Offset>[];
      for (int i = 0; i < points.length; i++) {
        final n0 = i == 0 && !closed
            ? normal(points[0], points[1])
            : normal(
                points[(i - 1 + points.length) % points.length],
                points[i],
              );
        final n1 = i == points.length - 1 && !closed
            ? normal(points[i - 1], points[i])
            : normal(points[i], points[(i + 1) % points.length]);
        final sum = n0 + n1;
        final miter = sum.distance < .01 ? n1 : sum / sum.distance;
        final dot = miter.dx * n1.dx + miter.dy * n1.dy;
        final amount = dot.abs() < .05
            ? offset
            : (offset / dot).clamp(-7.5, 7.5);
        rail.add(points[i] + miter * amount);
      }
      final path = Path()..moveTo(rail.first.dx, rail.first.dy);
      for (final p in rail.skip(1)) {
        path.lineTo(p.dx, p.dy);
      }
      if (closed) path.close();
      canvas.drawPath(
        path,
        dark
          ..style = PaintingStyle.stroke
          ..strokeJoin = StrokeJoin.round,
      );
      canvas.drawPath(
        path,
        light
          ..style = PaintingStyle.stroke
          ..strokeJoin = StrokeJoin.round,
      );
    }
  }

  void _drawFence(
    Canvas canvas,
    Size size,
    List<Offset> points, {
    int tier = 1,
  }) {
    final (edge, rail, postColour, cap) = switch (tier) {
      0 => (
        const Color(0xff71392c),
        const Color(0xffc26c55),
        const Color(0xffa45d46),
        const Color(0xffe2a28e),
      ),
      2 => (
        const Color(0xff4a301f),
        const Color(0xffb57942),
        const Color(0xff946239),
        const Color(0xffd5a35f),
      ),
      3 => (
        const Color(0xff54514b),
        const Color(0xffbbb1a0),
        const Color(0xff888277),
        const Color(0xffd9d1c0),
      ),
      4 => (
        const Color(0xff34464b),
        const Color(0xffa0c1c2),
        const Color(0xff69858d),
        const Color(0xffcae0e0),
      ),
      5 => (
        const Color(0xff243237),
        const Color(0xff6b8a99),
        const Color(0xff486477),
        const Color(0xffffcb70),
      ),
      _ => (
        const Color(0xff60432a),
        const Color(0xffd6ae68),
        const Color(0xffc58e4c),
        const Color(0xfff1d398),
      ),
    };
    if (points.isEmpty) return;
    final dark = Paint()
      ..color = edge
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.square;
    final light = Paint()
      ..color = rail
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.square;
    final visible = Rect.fromLTWH(-15, -15, size.width + 30, size.height + 30);
    // Leave a continuous phase across GPS samples instead of putting a post on
    // every GPS tick; this avoids flickering clumps of posts at slow speeds.
    _drawRails(canvas, points, dark, light);
    double untilPost = 22;
    final posts = <Offset>[points.first];
    for (int i = 1; i < points.length; i++) {
      final a = points[i - 1], b = points[i], delta = b - a;
      final length = delta.distance;
      if (length < .01) continue;
      // Geometry can extend far outside the viewport. Sample only the visible
      // portion of each segment rather than iterating millions of offscreen posts.
      final count = max(0, ((length - untilPost) / 22).floor() + 1);
      if (count > 0) {
        if (Rect.fromPoints(a, b).inflate(12).overlaps(visible)) {
          // Bound work to a small number of posts; huge zoomed-in segments use
          // segment clipping for the exact visible sample range below.
          var lo = 0.0, hi = 1.0;
          for (final edge in [
            (delta.dx, visible.left - a.dx, visible.right - a.dx),
            (delta.dy, visible.top - a.dy, visible.bottom - a.dy),
          ]) {
            if (edge.$1.abs() < 1e-9) continue;
            final u = edge.$2 / edge.$1, v = edge.$3 / edge.$1;
            lo = max(lo, min(u, v));
            hi = min(hi, max(u, v));
          }
          final first = max(0, ((lo * length - untilPost) / 22).ceil());
          final last = min(count - 1, ((hi * length - untilPost) / 22).floor());
          for (int k = first; k <= last; k++) {
            posts.add(a + delta * ((untilPost + k * 22) / length));
          }
        }
        untilPost += count * 22;
      }
      untilPost -= length;
    }
    if (points.length > 1) posts.add(points.last);
    for (int i = 1; i < points.length - 1; i++) {
      final a = points[i] - points[i - 1], b = points[i + 1] - points[i];
      if (a.distance > .01 &&
          b.distance > .01 &&
          (a.dx * b.dx + a.dy * b.dy) / (a.distance * b.distance) < .92)
        posts.add(points[i]);
    }
    final painted = <Offset>[];
    for (final p in posts) {
      if (!visible.contains(p) || painted.any((q) => (p - q).distance < 5))
        continue;
      painted.add(p);
      final post = Rect.fromCenter(center: p, width: 7, height: 12);
      canvas.drawRect(post, Paint()..color = edge);
      canvas.drawRect(post.deflate(1.5), Paint()..color = postColour);
      canvas.drawRect(
        Rect.fromLTWH(post.left + 1.5, post.top + 1.5, 4, 3),
        Paint()..color = cap,
      );
    }
  }

  @override
  bool shouldRepaint(covariant FencePainter oldDelegate) => true;
}

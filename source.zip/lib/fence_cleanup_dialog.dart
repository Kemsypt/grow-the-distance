import 'dart:math';

// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' show LatLng;

import 'fence_geometry.dart';
import 'game.dart';

Future<double?> showFenceCleanup(
  BuildContext context,
  List<LatLng> boundary,
  LatLng entrance,
) {
  double strength = 8;
  return showDialog<double>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, setLocal) {
        final clean = neatenFence(boundary, entrance, maxDeviation: strength);
        final oldArea = Place('', 'farm', entrance, fence: boundary).area;
        final newArea = Place('', 'farm', entrance, fence: clean.points).area;
        final change = oldArea > 0 ? (newArea - oldArea) / oldArea * 100 : 0.0;
        return AlertDialog(
          title: const Text('Neaten your fence'),
          content: SizedBox(
            width: 640,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Straighten small bends while keeping your plot’s overall shape. Works offline.',
                  ),
                  const SizedBox(height: 12),
                  DropdownButton<double>(
                    value: strength,
                    isExpanded: true,
                    items: const [
                      DropdownMenuItem(value: 3, child: Text('Gentle')),
                      DropdownMenuItem(value: 8, child: Text('Standard')),
                      DropdownMenuItem(value: 14, child: Text('Strong')),
                    ],
                    onChanged: (v) => setLocal(() => strength = v!),
                  ),
                  SizedBox(
                    height: 230,
                    child: CustomPaint(
                      size: const Size(double.infinity, 230),
                      painter: FenceComparisonPainter(
                        before: boundary,
                        after: clean.points,
                      ),
                    ),
                  ),
                  Text(
                    '${clean.beforeCount} → ${clean.points.length} boundary points · Area ${change >= 0 ? '+' : ''}${change.toStringAsFixed(1)}%',
                  ),
                  const SizedBox(height: 8),
                  Text(
                    clean.changed
                        ? 'Keeps deviations within ${clean.toleranceMeters.toStringAsFixed(1)} m and area within 8%. You can undo after applying.'
                        : clean.safe
                        ? 'No extra bends can be safely removed at this strength.'
                        : 'This boundary could not be safely straightened.',
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: clean.changed
                  ? () => Navigator.pop(c, strength)
                  : null,
              child: const Text('Apply neatening'),
            ),
          ],
        );
      },
    ),
  );
}

/// Identical bounds/scale in both panes make the visual change reviewable.
class FenceComparisonPainter extends CustomPainter {
  final List<LatLng> before, after;
  const FenceComparisonPainter({required this.before, required this.after});
  @override
  void paint(Canvas canvas, Size size) {
    if (before.isEmpty) return;
    final origin = before.first;
    Offset project(LatLng p) => Offset(
      (p.longitude - origin.longitude) *
          111320 *
          cos(origin.latitude * pi / 180),
      -(p.latitude - origin.latitude) * 111320,
    );
    final original = before.map(project).toList(),
        result = after.map(project).toList();
    final all = [...original, ...result];
    final minX = all.map((p) => p.dx).reduce(min),
        maxX = all.map((p) => p.dx).reduce(max);
    final minY = all.map((p) => p.dy).reduce(min),
        maxY = all.map((p) => p.dy).reduce(max);
    final half = size.width / 2,
        centre = Offset((minX + maxX) / 2, (minY + maxY) / 2);
    final scale = min(
      (half - 28) / max(1, maxX - minX),
      (size.height - 55) / max(1, maxY - minY),
    );
    for (final entry in [
      (original, const Color(0xff986839), 'Before'),
      (result, const Color(0xff294b32), 'After'),
    ].indexed) {
      final left = entry.$1 * half;
      final box = Rect.fromLTWH(left + 3, 4, half - 6, size.height - 8);
      canvas.drawRRect(
        RRect.fromRectAndRadius(box, const Radius.circular(6)),
        Paint()..color = const Color(0xfff3edd8),
      );
      final text = TextPainter(
        text: TextSpan(
          text: entry.$2.$3,
          style: const TextStyle(
            color: Color(0xff294b32),
            fontSize: 13,
            fontWeight: FontWeight.bold,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      text.paint(canvas, Offset(left + (half - text.width) / 2, 11));
      final points = entry.$2.$1
          .map(
            (p) =>
                (p - centre) * scale +
                Offset(left + half / 2, (size.height + 28) / 2),
          )
          .toList();
      if (points.length < 2) continue;
      final path = Path()..moveTo(points.first.dx, points.first.dy);
      for (final p in points.skip(1)) {
        path.lineTo(p.dx, p.dy);
      }
      path.close();
      canvas.drawPath(
        path,
        Paint()..color = entry.$2.$2.withValues(alpha: .10),
      );
      canvas.drawPath(
        path,
        Paint()
          ..color = entry.$2.$2
          ..strokeWidth = 2.5
          ..style = PaintingStyle.stroke
          ..strokeJoin = StrokeJoin.round,
      );
      for (final p in points) {
        canvas.drawCircle(p, 2.5, Paint()..color = entry.$2.$2);
      }
    }
  }

  @override
  bool shouldRepaint(covariant FenceComparisonPainter old) => true;
}

// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'game.dart';
import 'building_customization.dart';
import 'water_system.dart';

class WellUpgradeView extends StatelessWidget {
  const WellUpgradeView({
    required this.game,
    required this.well,
    required this.startWalk,
    super.key,
  });
  final Game game;
  final Place well;
  final ValueChanged<Place> startWalk;
  String costLabel(Map<String, int> cost) =>
      cost.entries.map((e) => '${e.value} ${e.key}').join(' · ');
  bool affordable(Map<String, int> cost) =>
      cost.entries.every((e) => (game.bag[e.key] ?? 0) >= e.value);

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Well upgrades')),
    body: SafeArea(
      child: ListenableBuilder(
        listenable: game,
        builder: (context, _) {
          final connections = game.connectedFarms(well);
          final candidates = game.places
              .where(
                (farm) =>
                    game.canPipe(farm) &&
                    farm.pipes.length < farm.pipeSlots &&
                    game.connectionTo(well, farm) == null,
              )
              .toList();
          final price = WellUpgrades.connectionCost(connections.length);
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Text(
                '${well.available(game.now)} / ${well.capacity} water ready',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              Text(
                '${well.well.rechargeMinutes} min from empty to full · ${(well.capacity * 60 / well.well.rechargeMinutes).toStringAsFixed(1)} water/hour',
              ),
              if (well.well.lastIncident case final incident?) Text(incident),
              if (!well.well.canDraw(game.now))
                const Text('Pump jammed · water temporarily unavailable'),
              if (well.well.siltUntil > game.now)
                const Text('Silt buildup · refilling at half speed'),
              if (game.wellNeedsRepair(well)) ...[
                if (!game.inCollectionRange(well))
                  const Text('Move within 45 m to use a repair kit.'),
                Align(
                  alignment: Alignment.centerLeft,
                  child: OutlinedButton(
                    onPressed:
                        game.inCollectionRange(well) &&
                            (game.bag['repair kits'] ?? 0) > 0
                        ? () => game.repairWell(well)
                        : null,
                    child: const Text('Repair well · 1 repair kit'),
                  ),
                ),
              ],
              Align(
                alignment: Alignment.centerLeft,
                child: OutlinedButton(
                  onPressed: () => editBuilding(context, game, well),
                  child: const Text('Rename well'),
                ),
              ),
              const SizedBox(height: 14),
              _upgrade(context, false),
              _upgrade(context, true),
              const SizedBox(height: 16),
              Text('Farm pipes', style: Theme.of(context).textTheme.titleLarge),
              const Text(
                'Active farms share this well’s production. Shortfalls come from your inventory. A farm needs tier 2 sprinklers and a completed fence.',
              ),
              for (final farm in connections)
                if (game.connectionTo(well, farm) case final pipe?)
                  ListTile(
                    leading: Icon(
                      pipe.installed ? Icons.water_drop : Icons.route,
                    ),
                    title: Text(farm.name),
                    subtitle: Text(
                      '${farm.crop.waterPerHour} water/hour · ${pipe.installed ? (pipe.enabled ? 'Direct watering on' : 'Pipe off') : 'Installation walk pending'}',
                    ),
                    trailing: pipe.installed
                        ? Switch(
                            value: pipe.enabled,
                            onChanged: (enabled) =>
                                game.togglePipe(farm, pipe, enabled),
                          )
                        : TextButton(
                            onPressed: () => startWalk(farm),
                            child: const Text('Start pipe walk'),
                          ),
                  ),
              const SizedBox(height: 8),
              Text('Next connection · ${costLabel(price)}'),
              if (candidates.isEmpty)
                const Text(
                  'An eligible farm needs tier 2 sprinklers and a free pipe slot.',
                ),
              for (final farm in candidates)
                ListTile(
                  title: Text(farm.name),
                  subtitle: Text(
                    '${farm.crop.label} · ${farm.crop.waterPerHour} water/hour',
                  ),
                  trailing: TextButton(
                    onPressed: affordable(price)
                        ? () => game.buyPipe(well, farm)
                        : null,
                    child: const Text('Buy pipe'),
                  ),
                ),
            ],
          );
        },
      ),
    ),
  );
  Widget _upgrade(BuildContext context, bool recharge) {
    final level = recharge ? well.well.rechargeTier : well.well.yieldTier;
    final maximum = level >= WellUpgrades.maxTier;
    final cost = WellUpgrades.cost(recharge, level);
    final next = WellUpgrades(
      yieldTier: well.well.yieldTier + (recharge || maximum ? 0 : 1),
      rechargeTier: well.well.rechargeTier + (!recharge || maximum ? 0 : 1),
    );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${recharge ? 'Recharge' : 'Collection yield'} · Tier $level / 5',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            if (!maximum) ...[
              Text(
                recharge
                    ? 'Next tier · ${next.rechargeMinutes} min to refill'
                    : 'Next tier · ${next.capacity} water per full collection',
              ),
              Text(costLabel(cost)),
              const SizedBox(height: 6),
              FilledButton(
                onPressed: affordable(cost)
                    ? () => game.upgradeWell(well, recharge: recharge)
                    : null,
                child: Text(recharge ? 'Upgrade recharge' : 'Upgrade yield'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

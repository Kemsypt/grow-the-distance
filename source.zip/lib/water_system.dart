class WellUpgrades {
  WellUpgrades({
    this.yieldTier = 1,
    this.rechargeTier = 1,
    this.buffer = 0,
    this.checkedAt,
    this.nextRiskAt,
    this.siltUntil = 0,
    this.jammedUntil = 0,
    this.lastIncident,
  });
  int yieldTier, rechargeTier;
  double buffer;
  int? checkedAt, nextRiskAt;
  int siltUntil, jammedUntil;
  String? lastIncident;
  bool canDraw(int time) => time >= jammedUntil;
  static const maxTier = 5;
  int get capacity => [20, 30, 45, 65, 90][yieldTier - 1];
  int get rechargeMinutes => [240, 195, 150, 110, 75][rechargeTier - 1];
  double stockAt(int time, int builtAt) {
    final start = checkedAt ?? builtAt;
    final elapsed = (time - start).clamp(0, double.infinity);
    final slow = (siltUntil - start).clamp(0, elapsed);
    final stock =
        buffer + (elapsed - slow / 2) * capacity / (rechargeMinutes * 60000);
    return stock.clamp(0.0, capacity.toDouble());
  }

  void take(int amount, int time, int builtAt) {
    buffer = stockAt(time, builtAt) - amount;
    checkedAt = time;
  }

  Map<String, dynamic> json() => {
    'yield': yieldTier,
    'recharge': rechargeTier,
    'buffer': buffer,
    'checkedAt': checkedAt,
    'nextRiskAt': nextRiskAt,
    'siltUntil': siltUntil,
    'jammedUntil': jammedUntil,
    'lastIncident': lastIncident,
  };
  factory WellUpgrades.from(Map data) => WellUpgrades(
    yieldTier: (data['yield'] as int? ?? 1).clamp(1, 5),
    rechargeTier: (data['recharge'] as int? ?? 1).clamp(1, 5),
    buffer: (data['buffer'] as num? ?? 0).toDouble(),
    checkedAt: data['checkedAt'] as int?,
    nextRiskAt: data['nextRiskAt'] as int?,
    siltUntil: data['siltUntil'] as int? ?? 0,
    jammedUntil: data['jammedUntil'] as int? ?? 0,
    lastIncident: data['lastIncident'] as String?,
  );

  static Map<String, int> cost(bool recharge, int currentTier) => recharge
      ? {'stone': 9 * currentTier, 'timber': 6 * currentTier}
      : {'stone': 12 * currentTier, 'timber': 8 * currentTier};
  static Map<String, int> connectionCost(int previous) => {
    'stone': 10 * (previous + 1),
    'timber': 8 * (previous + 1),
  };
}

enum WellEvent {
  crackedLining('Cracked lining'),
  siltBuildup('Silt buildup'),
  jammedPump('Jammed pump');

  const WellEvent(this.title);
  final String title;
}

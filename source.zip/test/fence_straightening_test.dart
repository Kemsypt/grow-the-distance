import 'dart:math';
import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/fence_geometry.dart';
import 'package:hearthstride/game.dart';
import 'fixtures/rough_fence.dart';

void main() {
  test(
    'park-sized offline fence loses visible bumps, including the starting seam',
    () {
      final result = neatenFence(roughFence, farmEntrance);
      expect(result.changed, true);
      expect(result.points.length, lessThanOrEqualTo(10));
      expect(result.points, isNot(contains(roughFence.first)));
      final before = Place('', 'farm', farmEntrance, fence: roughFence).area;
      final after = Place('', 'farm', farmEntrance, fence: result.points).area;
      expect((after - before).abs() / before, lessThanOrEqualTo(.080001));
      for (final original in roughFence) {
        double nearest = double.infinity;
        for (int i = 0; i < result.points.length; i++) {
          final a = result.points[i],
              b = result.points[(i + 1) % result.points.length];
          final bx =
                  (b.longitude - a.longitude) *
                  111320 *
                  cos(a.latitude * pi / 180),
              by = (b.latitude - a.latitude) * 111320;
          final px =
                  (original.longitude - a.longitude) *
                  111320 *
                  cos(a.latitude * pi / 180),
              py = (original.latitude - a.latitude) * 111320;
          final t = ((px * bx + py * by) / (bx * bx + by * by)).clamp(0, 1);
          nearest = min(
            nearest,
            sqrt(pow(px - bx * t, 2) + pow(py - by * t, 2)),
          );
        }
        expect(nearest, lessThanOrEqualTo(result.toleranceMeters + .05));
      }
    },
  );
  test(
    'new closed walks use stronger straightening even without road data',
    () {
      final result = findFenceBoundary([
        farmEntrance,
        ...roughFence,
        roughFence.first,
      ], farmEntrance);
      expect(result, isNotNull);
      expect(result!.points.length, lessThanOrEqualTo(10));
      expect(result.removedPoints, greaterThan(5));
      expect(result.snappedPoints, 0);
    },
  );
  test('cleanup and Undo both survive a village save round trip', () {
    final g = Game();
    final farm = Place(
      'Farm',
      'farm',
      farmEntrance,
      fence: List.of(roughFence),
    );
    g.places.add(farm);
    expect(g.applyFenceCleanup(farm), true);
    expect(farm.fence.length, lessThan(roughFence.length));
    final restored = Game()..restore(g.json());
    final saved = restored.places.single;
    expect(saved.fenceBeforeCleanup, roughFence);
    restored.undoFenceCleanup(saved);
    expect(saved.fence, roughFence);
    expect(saved.fenceBeforeCleanup, isEmpty);
  });
  test('clean boundaries do not claim a smoothing change', () {
    final clean = [
      fencePoint(0, 0),
      fencePoint(140, 0),
      fencePoint(140, 220),
      fencePoint(0, 220),
    ];
    expect(neatenFence(clean, farmEntrance).changed, false);
    final g = Game();
    g.fence = [...clean, clean.first];
    g.position = clean.first;
    final farm = Place('Farm', 'farm', farmEntrance);
    expect(g.finishFence(farm), true);
    expect(g.notice, contains('No extra bends removed.'));
  });
  test(
    'stronger choice can simplify more without shrinking beyond the area limit',
    () {
      final gentle = neatenFence(roughFence, farmEntrance, maxDeviation: 3);
      final standard = neatenFence(roughFence, farmEntrance, maxDeviation: 8);
      final strong = neatenFence(roughFence, farmEntrance, maxDeviation: 14);
      expect(standard.points.length, lessThanOrEqualTo(gentle.points.length));
      expect(strong.points.length, lessThanOrEqualTo(standard.points.length));
    },
  );
}

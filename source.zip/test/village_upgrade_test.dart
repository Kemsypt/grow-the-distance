import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/farm_upgrades.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/homestead.dart';
import 'package:hearthstride/water_system.dart';
import 'package:latlong2/latlong.dart';

import 'game_test.dart' show fieldAt;

void main() {
  test(
    'debug inventory expires on real time and saves the original amounts',
    () {
      var clock = DateTime(2026, 11, 18);
      final game = Game(clock: () => clock);
      game.bag['timber'] = 7;
      game.setInfiniteResources(true);
      expect(game.bag['timber'], greaterThan(1000));
      game.bag['timber'] = 3;
      expect(game.json()['bag']['timber'], 7);
      game.skip(const Duration(days: 14));
      expect(game.infiniteResources, isTrue);
      clock = clock.add(const Duration(minutes: 10));
      game.expireInfiniteResources();
      expect(game.infiniteResources, isFalse);
      expect(game.bag['timber'], 7);
    },
  );

  test('well events affect stock, recharge and pipe availability', () {
    final game = Game();
    final well = Place(
      'Brook Well',
      'well',
      start,
      planted: game.now - const Duration(hours: 8).inMilliseconds,
    );
    game.places.add(well);
    expect(well.available(game.now), 20);
    expect(game.triggerWellEvent(well, event: WellEvent.crackedLining), isTrue);
    expect(well.available(game.now), 10);
    expect(game.eventToasts.last, contains('Brook Well'));
    game.triggerWellEvent(well, event: WellEvent.siltBuildup);
    game.skip(const Duration(hours: 2));
    expect(well.available(game.now), 15);
    game.triggerWellEvent(well, event: WellEvent.jammedPump);
    expect(well.available(game.now), 0);
    game.skip(const Duration(hours: 12));
    expect(well.available(game.now), greaterThan(0));
  });

  test('extra pipe slots allow separate wells with independent shutoffs', () {
    final game = Game();
    final now = game.now;
    final first = Place(
      'First well',
      'well',
      start,
      planted: now - 4 * Game.waterHour,
    );
    final second = Place(
      'Second well',
      'well',
      start,
      planted: now - 4 * Game.waterHour,
    );
    final farm = Place(
      'Farm',
      'farm',
      start,
      fence: fieldAt(start),
      waterCheckedAt: now,
      planted: now,
      pipeWell: 0,
      pipeActive: true,
    );
    farm.improvements.tiers[FarmUpgrade.sprinklers] = 2;
    game.places.addAll([first, second, farm]);
    game.bag.addAll({'timber': 100, 'stone': 100});
    expect(game.buyPipe(second, farm), isFalse);
    expect(game.upgradePipes(farm), isTrue);
    expect(game.buyPipe(second, farm), isTrue);
    expect(game.buyPipe(second, farm), isFalse);
    game.connectionTo(second, farm)!.installed = true;
    game.togglePipe(farm, game.connectionTo(first, farm)!, false);
    game.skip(const Duration(hours: 1));
    expect(first.available(game.now), 20);
    expect(second.available(game.now), 18);
    final restored = Game()..restore(jsonDecode(jsonEncode(game.json())));
    expect(restored.places.last.pipes.map((pipe) => pipe.enabled), [
      false,
      true,
    ]);
  });

  test(
    'home grows seeds inside its fence and persists renamed buildings and a pet',
    () {
      final game = Game()..setHome(start);
      final home = game.home!..fence = fieldAt(start);
      final farm = Place('Farm', 'farm', start, fence: fieldAt(start));
      game.places.add(farm);
      expect(game.customizePlace(home, 'Fern Cottage'), isTrue);
      expect(
        game.customizePlace(farm, 'Fern Farm', color: 0xffcee5b3, emoji: '🌻'),
        isTrue,
      );
      expect(game.findPet(species: VillagePet.bunny), isTrue);
      expect(game.findPet(species: VillagePet.cat), isFalse);
      game.skip(const Duration(hours: 6));
      game.teleport(LatLng(start.latitude + .01, start.longitude));
      expect(game.collect(home), 0);
      game.teleport(start);
      expect(game.collect(home), 2);
      final restored = Game()..restore(jsonDecode(jsonEncode(game.json())));
      expect(restored.pet, VillagePet.bunny);
      expect(restored.home!.name, 'Fern Cottage');
      expect(restored.places.last.icon, '🌻');
      expect(restored.places.last.markerColor, 0xffcee5b3);
    },
  );
}

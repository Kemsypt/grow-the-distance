import 'dart:convert';
// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/irrigation_layer.dart';
import 'package:hearthstride/main.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'game_test.dart' show fieldAt;

void main() {
  testWidgets(
    'connected irrigation draws between markers and Admin triggers events',
    (t) async {
      final game = Game();
      final well = Place(
        'Village Well',
        'well',
        start,
        planted: game.now - const Duration(hours: 4).inMilliseconds,
      );
      final farmPosition = LatLng(start.latitude, start.longitude + .0004);
      final farm = Place(
        'Fern Acres',
        'farm',
        farmPosition,
        fence: fieldAt(farmPosition),
        planted: game.now - const Duration(days: 3).inMilliseconds,
        pipeWell: 0,
        pipeActive: true,
        pipePath: [
          start,
          LatLng(start.latitude + .0004, start.longitude),
          farmPosition,
        ],
      );
      game.places.addAll([well, farm]);
      SharedPreferences.setMockInitialValues({
        'village-v1': jsonEncode(game.json()),
      });

      await t.pumpWidget(const HearthApp());
      await t.pumpAndSettle();
      expect(find.text('Random effect'), findsNothing);
      await t.tap(find.text('Map'));
      await t.pump(const Duration(milliseconds: 500));
      final layer = t.widget<IrrigationLayer>(find.byType(IrrigationLayer));
      expect(layer.links, [
        (well: well.pos, farm: farm.markerPosition, flowing: true),
      ]);
      expect(find.byTooltip('Direct watering connected'), findsOneWidget);
      expect(t.takeException(), isNull);

      await t.tap(find.byTooltip('Settings'));
      await t.pumpAndSettle();
      await t.ensureVisible(find.text('Admin menu'));
      await t.tap(find.text('Admin menu'));
      await t.pumpAndSettle();
      await t.tap(find.text('Random effect'));
      await t.pumpAndSettle();
      expect(find.text('Random event'), findsOneWidget);
      expect(find.text('Fern Acres'), findsOneWidget);
      await t.tap(find.text('Broken Fence!'));
      await t.pumpAndSettle();
      expect(
        find.descendant(
          of: find.byType(SnackBar),
          matching: find.textContaining(RegExp(r'^Broken Fence!.*destroying')),
        ),
        findsOneWidget,
      );
      final prefs = await SharedPreferences.getInstance();
      await t.pump(const Duration(milliseconds: 600));
      final save = Game()..restore(jsonDecode(prefs.getString('village-v1')!));
      expect(
        save.places.last.yieldCapacity,
        lessThan(save.places.last.capacity),
      );
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox());
    },
  );
}

import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/homestead.dart';
import 'package:hearthstride/water_system.dart';

import 'game_test.dart' show fieldAt;

void main() {
  test('home projects supply compost, herbs and repair kits', () {
    final game = Game()..setHome(start);
    game.home!.fence = fieldAt(start);
    game.bag.addAll({'timber': 100, 'stone': 100});
    for (final project in HomeProject.values) {
      game.buildHomeProject(project);
      expect(game.canBuildHomeProject(project), isFalse);
    }
    game.skip(const Duration(hours: 19));
    expect(game.collectHomeProject(HomeProject.compostBin), 2);
    expect(game.collectHomeProject(HomeProject.herbPatch), 3);
    game.skip(const Duration(hours: 1));
    expect(game.collectHomeProject(HomeProject.herbPatch), 0);
    final farm = Place(
      'Farm',
      'farm',
      start,
      fence: fieldAt(start),
      planted: game.now,
    );
    final well = Place(
      'Well',
      'well',
      start,
      planted: game.now - 4 * Game.waterHour,
    );
    game.places.addAll([farm, well]);

    expect(game.applyCompost(farm), true);
    expect(game.applyCompost(farm), false);
    expect(game.now - farm.planted, closeTo(12 * Game.waterHour, 1000));

    game.findPet(species: VillagePet.bunny);
    game.treatPet();
    game.giftHerbs();
    expect(game.bag['herbs'], 0);
    expect(game.canGiftHerbs, false);

    game.craftRepairKit();
    game.triggerWellEvent(well, event: WellEvent.jammedPump);
    expect(game.repairWell(well), true);
    expect(well.available(game.now), 20);
    farm.improvements.fenceDamaged = true;
    game.craftRepairKit();
    expect(game.repairFarmFence(farm, useKit: true), true);
    expect(game.bag['repair kits'], 0);

    final loaded = Game()..restore(jsonDecode(jsonEncode(game.json())));
    expect(loaded.home!.projects.length, 3);
    expect(loaded.petTreats, 1);
    expect(loaded.herbsGiftedToRowan, true);
    expect(
      loaded.places.firstWhere((place) => place.kind == 'farm').compostApplied,
      true,
    );
  });
}

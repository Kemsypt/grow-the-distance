import 'dart:convert';
// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/main.dart';

void main() {
  testWidgets(
    'phone Build menu keeps Well and Fence available while a building is selected',
    (t) async {
      final seed = Game()..setHome(start);
      seed.bag['timber'] = 50;
      seed.bag['stone'] = 50;
      seed.build('farm', start);
      SharedPreferences.setMockInitialValues({
        'village-v1': jsonEncode(seed.json()),
      });
      t.view.physicalSize = const Size(390, 844);
      t.view.devicePixelRatio = 1;
      await t.pumpWidget(const HearthApp());
      await t.pumpAndSettle();
      await t.tap(find.text('Map'));
      await t.pump();
      // Select the existing farm through its map marker, rather than empty ground.
      await t.tap(find.text('Carrot Farm').last);
      await t.pump();
      await t.tap(find.byTooltip('Build'));
      await t.pumpAndSettle();
      expect(find.text('Farm · 5 timber / 3 stone'), findsOneWidget);
      expect(find.text('Well · 8 timber / 6 stone'), findsOneWidget);
      expect(find.text('Fence / wall'), findsOneWidget);
      await t.tap(find.text('Well · 8 timber / 6 stone'));
      await t.pumpAndSettle();
      expect(find.textContaining('Village Well ·'), findsOneWidget);
      await t.tap(find.byTooltip('Build'));
      await t.pumpAndSettle();
      await t.tap(find.text('Fence / wall'));
      await t.pumpAndSettle();
      await t.tap(find.text('Carrot Farm · 0 m away'));
      await t.pumpAndSettle();
      await t.tap(find.text('Build fence / wall'));
      await t.pumpAndSettle();
      expect(find.text('Finish fence'), findsOneWidget);
      expect(find.text('Cancel fence'), findsOneWidget);
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox());
      t.view.resetPhysicalSize();
      t.view.resetDevicePixelRatio();
    },
  );
  testWidgets('building from the map prompts for a custom farm name', (
    t,
  ) async {
    final game = Game()..setHome(start);
    game.bag.addAll({'timber': 10, 'stone': 10});
    SharedPreferences.setMockInitialValues({
      'village-v1': jsonEncode(game.json()),
    });
    await t.pumpWidget(const HearthApp());
    await t.pumpAndSettle();
    await t.tap(find.text('Map'));
    await t.pump();
    await t.tap(find.byTooltip('Build'));
    await t.pumpAndSettle();
    await t.tap(find.text('Farm · 5 timber / 3 stone'));
    await t.pumpAndSettle();
    await t.enterText(find.byType(TextFormField), 'Fern Acres');
    await t.tap(find.text('Build farm'));
    await t.pumpAndSettle();
    expect(find.textContaining('Fern Acres built'), findsOneWidget);
    expect(t.takeException(), isNull);
    await t.pumpWidget(const SizedBox());
  });

  testWidgets('Build menu shows locked options before home is set', (t) async {
    SharedPreferences.setMockInitialValues({});
    await t.pumpWidget(const HearthApp());
    await t.pumpAndSettle();
    await t.tap(find.text('Map'));
    await t.pump();
    await t.tap(find.byTooltip('Build'));
    await t.pumpAndSettle();
    expect(find.text('Set your home to unlock buildings.'), findsOneWidget);
    expect(find.text('Fence / wall · build a farm first'), findsOneWidget);
    await t.pumpWidget(const SizedBox());
  });
}

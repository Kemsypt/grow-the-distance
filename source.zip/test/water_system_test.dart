import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/fence_geometry.dart';
import 'package:hearthstride/farm_upgrades.dart';
import 'package:hearthstride/water_system.dart';
import 'package:latlong2/latlong.dart';
import 'game_test.dart' show fieldAt;

void main() {
  test(
    'hourly inventory water is crop-specific and dry hours preserve growth',
    () {
      final g = Game();
      final time = g.now;
      final farm = Place(
        'Farm',
        'farm',
        start,
        fence: fieldAt(start),
        crop: Crop.pumpkins,
        planted: time,
        waterCheckedAt: time,
      );
      g.places.add(farm);
      g.bag['water'] = 6;
      g.skip(const Duration(hours: 2));
      expect(g.bag['water'], 0);
      final growth = farm.growth(g.now);
      expect(growth, greaterThan(0));
      g.skip(const Duration(hours: 3));
      expect(farm.dry, true);
      expect(farm.growth(g.now), growth);
      g.bag['water'] = 3;
      g.skip(const Duration(hours: 1));
      expect(farm.dry, false);
      expect(g.bag['water'], 0);
      expect(farm.growth(g.now), greaterThan(growth));
    },
  );

  test(
    'paid well upgrades preserve reserves and give larger, quicker refills',
    () {
      final g = Game();
      final well = Place(
        'Well',
        'well',
        start,
        planted: g.now - 4 * Game.waterHour,
      );
      g.places.add(well);
      g.bag.addAll({'stone': 100, 'timber': 100});
      expect(well.available(g.now), 20);
      expect(g.upgradeWell(well, recharge: false), true);
      expect(well.capacity, 30);
      expect(well.available(g.now), 20);
      expect(g.upgradeWell(well, recharge: true), true);
      expect(well.well.rechargeMinutes, 195);
      g.skip(const Duration(hours: 4));
      expect(g.collect(well), 30);
      expect(well.available(g.now), 0);
      expect(g.bag['water'], 30);
    },
  );

  test('pipe joins use the closest segment within 100m', () {
    const end = LatLng(0, 0);
    final tail = [const LatLng(0, .001), const LatLng(0, .0005), end];
    final near = [const LatLng(-.0004, .00085), const LatLng(.0004, .00085)];
    final far = [const LatLng(-.0004, .00091), const LatLng(.0004, .00091)];
    expect(nearestPipeJoin(end, tail, [far]), isNull);
    final join = nearestPipeJoin(end, tail, [far, near])!;
    expect(join.latitude, closeTo(0, 1e-9));
    expect(join.longitude, closeTo(.00085, 1e-9));
  });

  test('pipe can snap across to the middle of its own earlier route', () {
    const end = LatLng(0, 0);
    final path = [
      const LatLng(-.0005, .0005),
      const LatLng(.001, .0005),
      const LatLng(.001, -.001),
      const LatLng(0, -.001),
      end,
    ];
    final join = nearestPipeJoin(end, path, [])!;
    expect(join.latitude, closeTo(0, 1e-9));
    expect(join.longitude, closeTo(.0005, 1e-9));
  });

  test('pipes need sprinklers, perimeter coverage, and a nearby join', () {
    final g = Game();
    final time = g.now;
    final well = Place(
      'Well',
      'well',
      start,
      planted: time - 4 * Game.waterHour,
    );
    final centre = LatLng(start.latitude + .00035, start.longitude);
    final farm = Place(
      'Farm',
      'farm',
      centre,
      fence: fieldAt(centre, size: .00014),
      planted: time,
      waterCheckedAt: time,
    );
    g.places.addAll([well, farm]);
    g.bag.addAll({'stone': 100, 'timber': 100});
    expect(g.buyPipe(well, farm), false);
    farm.improvements.tiers[FarmUpgrade.sprinklers] = 2;
    expect(g.buyPipe(well, farm), true);
    expect(g.buyPipe(well, farm), false);
    expect(
      WellUpgrades.connectionCost(g.connectedFarms(well).length)['timber'],
      16,
    );
    expect(g.startPipeWalk(well, farm), true);
    g.teleport(farm.pos);
    expect(farm.pipePath, isEmpty);
    expect(farm.pipeActive, false);
    expect(g.pipeWalk, isNull);
    expect(g.startPipeWalk(well, farm), false);
    g.teleport(well.pos);
    expect(g.startPipeWalk(well, farm), true);
    g.move(farm.fence.first);
    expect(farm.pipeActive, false);
    expect(g.pipeWalk!.path, [well.pos, farm.fence.first]);
    expect(g.finishPipeWalk(), false);
    final task = g.pipeWalk!;
    for (final point in [...farm.fence.skip(1), farm.fence.first]) {
      if (farm.pipeActive) break;
      g.move(point);
    }
    expect(farm.pipeActive, true);
    expect(task.covered / task.perimeter, greaterThanOrEqualTo(.6));
    expect(task.covered / task.perimeter, lessThan(1));
    expect(farm.pipePath.take(task.path.length), orderedEquals(task.path));
    expect(farm.pipePath.length, task.path.length + 1);
    expect(meters(farm.pipePath.last, g.position), lessThan(100));
    expect(g.finishPipeWalk(), false);
    g.bag['water'] = 1;
    g.skip(const Duration(hours: 1));
    expect(well.available(g.now), 18);
    expect(g.bag['water'], 1);
    final restored = Game()..restore(jsonDecode(jsonEncode(g.json())));
    expect(restored.places.last.pipeActive, true);
    expect(restored.places.last.pipePath, farm.pipePath);
    expect(restored.pipeSource(restored.places.last), restored.places.first);
    expect(restored.places.first.available(restored.now), 18);
  });
}

import 'dart:convert';
// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:latlong2/latlong.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/main.dart';
import 'game_test.dart' show fieldAt;

void main() {
  testWidgets(
    'collect a fenced crop during an outing, reveal the reward and adjust the next goal',
    (t) async {
      final seed = Game()..setHome(start);
      final entrance = LatLng(start.latitude + .0007, start.longitude);
      final farm = Place(
        'Carrot Farm',
        'farm',
        entrance,
        fence: fieldAt(start),
        planted: seed.now - const Duration(days: 7).inMilliseconds,
      );
      seed.places.add(farm);
      expect(meters(seed.position, entrance), greaterThan(45));
      expect(seed.inCollectionRange(farm), isTrue);
      SharedPreferences.setMockInitialValues({
        'village-v1': jsonEncode(seed.json()),
      });
      t.view.physicalSize = const Size(1368, 801);
      t.view.devicePixelRatio = 1;
      await t.pumpWidget(const HearthApp());
      await t.pumpAndSettle();
      await t.tap(find.text('Neighbourhood'));
      await t.pump();
      await t.tap(find.text('Start walk'));
      await t.pump();
      await t.tap(find.text('Harvest ready'));
      await t.pump();
      expect(find.textContaining('100% grown'), findsOneWidget);
      expect(find.textContaining('Inside farm'), findsOneWidget);
      await t.tap(find.text('Collect · 60s'));
      await t.pump();
      expect(find.text('Collecting carrots'), findsOneWidget);
      await t.pump(const Duration(seconds: 60));
      await t.pumpAndSettle();
      expect(find.text('+${farm.capacity} carrots'), findsOneWidget);
      await t.tap(find.text('Done'));
      await t.pump();
      await t.ensureVisible(find.text('Finish outing'));
      await t.pump();
      await t.tap(find.text('Finish outing'));
      await t.pumpAndSettle();
      expect(find.text('Collected · ${farm.capacity} carrots'), findsOneWidget);
      await t.tap(find.text('Easy'));
      await t.pumpAndSettle();
      expect(find.text('Next suggested outing · 770 m'), findsOneWidget);
      await t.tap(find.text('Done'));
      await t.pumpAndSettle();
      await t.tap(find.text('Village journal'));
      await t.pump();
      expect(find.text('Under the well cover'), findsOneWidget);
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox());
      t.view.resetPhysicalSize();
      t.view.resetDevicePixelRatio();
    },
  );
}

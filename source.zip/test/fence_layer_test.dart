import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:hearthstride/fence_layer.dart';
import 'package:hearthstride/game.dart';
import 'package:latlong2/latlong.dart';

void main() {
  testWidgets('live fence grows on movement and only completed plots close', (
    t,
  ) async {
    final recorded = [start, const LatLng(-34.9285, 138.6010)];
    final completed = [
      start,
      const LatLng(-34.9282, 138.6007),
      const LatLng(-34.9282, 138.6010),
    ];
    Widget map() => Directionality(
      textDirection: TextDirection.ltr,
      child: FlutterMap(
        options: const MapOptions(initialCenter: start, initialZoom: 17),
        children: [
          FenceLayer(completed: [completed], active: List.of(recorded)),
        ],
      ),
    );
    await t.pumpWidget(map());
    FencePainter painter() => t
        .widgetList<CustomPaint>(find.byType(CustomPaint))
        .map((w) => w.painter)
        .whereType<FencePainter>()
        .single;
    expect(painter().active.length, 2);
    expect(painter().active.first, isNot(painter().active.last));
    expect(painter().completed.single.first, painter().completed.single.last);
    recorded.add(const LatLng(-34.9282, 138.6010));
    await t.pumpWidget(map());
    expect(painter().active.length, 3);
    expect(painter().active.first, isNot(painter().active.last));
    expect(t.takeException(), isNull);
    await t.pumpWidget(const SizedBox());
  });
}

import 'dart:io';
import 'dart:ui' as ui;
// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/fence_geometry.dart';
import 'package:hearthstride/fence_cleanup_dialog.dart';
import 'fixtures/rough_fence.dart';

void main() {
  testWidgets('before/after preview supports cancelling or applying cleanup', (
    t,
  ) async {
    double? choice;
    await t.pumpWidget(
      MaterialApp(
        home: Builder(
          builder: (c) => Scaffold(
            body: TextButton(
              onPressed: () async {
                choice = await showFenceCleanup(c, roughFence, farmEntrance);
              },
              child: const Text('Neaten fence'),
            ),
          ),
        ),
      ),
    );
    await t.tap(find.text('Neaten fence'));
    await t.pumpAndSettle();
    expect(find.byType(CustomPaint), findsWidgets);
    expect(find.textContaining('boundary points'), findsOneWidget);
    expect(find.text('Apply neatening'), findsOneWidget);
    await t.tap(find.text('Cancel'));
    await t.pumpAndSettle();
    expect(choice, isNull);
    await t.tap(find.text('Neaten fence'));
    await t.pumpAndSettle();
    await t.tap(find.text('Apply neatening'));
    await t.pumpAndSettle();
    expect(choice, 8);
  });
  testWidgets(
    'render representative before/after geometry for visual inspection',
    (t) async {
      final clean = neatenFence(roughFence, farmEntrance);
      final key = GlobalKey();
      await t.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: RepaintBoundary(
                key: key,
                child: SizedBox(
                  width: 760,
                  height: 430,
                  child: CustomPaint(
                    painter: FenceComparisonPainter(
                      before: roughFence,
                      after: clean.points,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
      await t.pumpAndSettle();
      await t.runAsync(() async {
        final image =
            await (key.currentContext!.findRenderObject()
                    as RenderRepaintBoundary)
                .toImage(pixelRatio: 2);
        final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
        final output = Platform.environment['HEARTHSTRIDE_QA_IMAGE'];
        if (output != null)
          await File(output).writeAsBytes(bytes!.buffer.asUint8List());
        image.dispose();
      });
      expect(t.takeException(), isNull);
    },
  );
}

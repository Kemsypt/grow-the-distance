import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:latlong2/latlong.dart';
import 'package:hearthstride/road_service.dart';

void main() {
  test(
    'road provider loads centrelines and caches the coarse map area',
    () async {
      int calls = 0;
      final service = RoadService(
        client: MockClient((request) async {
          calls++;
          final query = request.bodyFields['data']!;
          expect(query, contains('out geom;'));
          expect(query, contains('way["highway"'));
          expect(query, isNot(contains('-34.9285123')));
          return http.Response(
            jsonEncode({
              'elements': [
                {
                  'type': 'way',
                  'geometry': [
                    {'lat': -34.929, 'lon': 138.600},
                    {'lat': -34.928, 'lon': 138.600},
                  ],
                },
              ],
            }),
            200,
          );
        }),
      );
      final points = [
        const LatLng(-34.9285123, 138.6007123),
        const LatLng(-34.9281, 138.6009),
      ];
      final result = await service.near(points);
      expect(result.available, true);
      expect(result.roads.single.length, 2);
      await service.near(points);
      expect(calls, 1);
      service.dispose();
    },
  );
  test('road server errors are a clean offline fallback', () async {
    final service = RoadService(
      client: MockClient((_) async => http.Response('Unavailable', 503)),
    );
    final result = await service.near([const LatLng(-34.9285, 138.6007)]);
    expect(result.available, false);
    expect(result.roads, isEmpty);
    service.dispose();
  });
  test('overlarge map requests are never sent', () async {
    final service = RoadService(
      client: MockClient((_) async => throw StateError('Must not request')),
    );
    final result = await service.near([
      const LatLng(-34, 138),
      const LatLng(-35, 139),
    ]);
    expect(result.available, false);
    service.dispose();
  });
}

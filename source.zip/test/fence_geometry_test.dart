import 'dart:math';
import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:hearthstride/fence_geometry.dart';
import 'package:hearthstride/game.dart';

LatLng p(double x, double y) => LatLng(
  start.latitude + y / 111320,
  start.longitude + x / (111320 * cos(start.latitude * pi / 180)),
);
double x(LatLng pnt) =>
    (pnt.longitude - start.longitude) * 111320 * cos(start.latitude * pi / 180);
double y(LatLng pnt) => (pnt.latitude - start.latitude) * 111320;
double area(FenceBoundary r) =>
    Place('farm', 'farm', p(20, 20), fence: r.points).area;
void main() {
  test(
    'centre lead-in is removed and only the outer circumference remains',
    () {
      final result = findFenceBoundary([
        p(20, 20),
        p(0, 20),
        p(0, 0),
        p(40, 0),
        p(40, 40),
        p(0, 40),
        p(0, 20),
      ], p(20, 20));
      expect(result, isNotNull);
      expect(area(result!), closeTo(1600, 2));
      expect(result.points.any((v) => x(v).abs() < 1 && y(v).abs() < 1), true);
      expect(
        result.points.any(
          (v) => (x(v) - 20).abs() < 1 && (y(v) - 20).abs() < 1,
        ),
        false,
      );
    },
  );
  test(
    'finishing near the middle of an older segment closes without reaching the start',
    () {
      final result = findFenceBoundary([
        p(20, 20),
        p(0, 20),
        p(0, 0),
        p(40, 0),
        p(40, 40),
        p(0, 40),
        p(1, 24),
      ], p(20, 20));
      expect(result, isNotNull);
      expect(area(result!), greaterThan(1500));
    },
  );
  test(
    'a closed loop followed by a short retraced lead-out keeps the outer loop',
    () {
      final result = findFenceBoundary([
        p(20, 20),
        p(0, 20),
        p(0, 0),
        p(40, 0),
        p(40, 40),
        p(0, 40),
        p(0, 20),
        p(6, 20),
      ], p(20, 20));
      expect(result, isNotNull);
      expect(area(result!), closeTo(1600, 2));
    },
  );
  test(
    'internal chords do not split the outer perimeter into smaller plots',
    () {
      final result = findFenceBoundary([
        p(0, 0),
        p(40, 0),
        p(40, 40),
        p(0, 40),
        p(0, 0),
        p(40, 40),
      ], p(12, 20));
      expect(result, isNotNull);
      expect(area(result!), closeTo(1600, 2));
    },
  );
  test('smoothing removes GPS wiggle without filling a concave plot', () {
    final trail = <LatLng>[p(0, 0)];
    for (int i = 1; i <= 20; i++) {
      trail.add(p(i * 2.0, (i % 2 == 0 ? 0.7 : -0.7)));
    }
    trail.addAll([
      p(40, 40),
      p(25, 40),
      p(25, 20),
      p(15, 20),
      p(15, 40),
      p(0, 40),
      p(0, 0),
    ]);
    final result = findFenceBoundary(trail, p(5, 20));
    expect(result, isNotNull);
    expect(result!.points.length, lessThan(13));
    expect(area(result), closeTo(1400, 50));
  });
  test('an open walk without a loop is not turned into a convex hull', () {
    expect(
      findFenceBoundary([
        p(0, 0),
        p(40, 0),
        p(40, 40),
        p(0, 40),
        p(0, 22),
      ], p(20, 20)),
      isNull,
    );
  });
  test('road centres within six metres attract nearby fence sections only', () {
    final trail = [p(0, 0), p(40, 0), p(40, 40), p(0, 40), p(0, 0)];
    final result = findFenceBoundary(
      trail,
      p(20, 20),
      roads: [
        [p(-4, -20), p(-4, 60)],
      ],
    );
    expect(result, isNotNull);
    expect(result!.snappedPoints, greaterThan(0));
    expect(result.points.map(x).reduce(min), closeTo(-4, .2));
    expect(result.points.map(x).reduce(max), closeTo(40, .2));
    final tooFar = findFenceBoundary(
      trail,
      p(20, 20),
      roads: [
        [p(-7, -20), p(-7, 60)],
      ],
    );
    expect(tooFar!.snappedPoints, 0);
    expect(tooFar.points.map(x).reduce(min), closeTo(0, .1));
  });
  test(
    'far from a completed fence does not allow completion from inside the plot',
    () {
      final result = findFenceBoundary([
        p(30, 30),
        p(0, 30),
        p(0, 0),
        p(60, 0),
        p(60, 60),
        p(0, 60),
        p(0, 30),
        p(30, 30),
      ], p(30, 30));
      expect(result, isNull);
    },
  );
}

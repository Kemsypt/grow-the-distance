import 'dart:convert';
// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/main.dart';

void main() {
  testWidgets('spoofer teleports using right-click or the map toolbar', (
    t,
  ) async {
    SharedPreferences.setMockInitialValues({
      'village-v1': jsonEncode(Game().json()),
    });
    t.view.physicalSize = const Size(1368, 801);
    t.view.devicePixelRatio = 1;
    await t.pumpWidget(const HearthApp());
    await t.pumpAndSettle();
    await t.tap(find.byTooltip('Settings'));
    await t.pump();
    await t.ensureVisible(find.text('Admin menu'));
    await t.pump();
    await t.tap(find.text('Admin menu'));
    await t.pump();
    await t.ensureVisible(find.text('Activate GPS spoofer'));
    await t.pump();
    await t.tap(find.text('Activate GPS spoofer'));
    await t.pump();
    expect(find.byTooltip('Teleport').hitTestable(), findsNothing);
    expect(find.text('JUMP TO COORDINATES'), findsNothing);
    await t.tap(find.text('Neighbourhood'));
    await t.pump(const Duration(milliseconds: 700));
    final store = await SharedPreferences.getInstance();
    List<double> position() => List<double>.from(
      jsonDecode(store.getString('village-v1')!)['position'],
    );
    final initial = position();
    final target =
        t.getRect(find.byType(FlutterMap)).center + const Offset(55, -35);
    await t.tapAt(target, kind: PointerDeviceKind.mouse);
    await t.pump(const Duration(milliseconds: 700));
    expect(find.textContaining('Selected location ·'), findsOneWidget);
    expect(position(), initial);
    expect(find.text('Teleport here'), findsNothing);
    await t.tapAt(
      target,
      buttons: kSecondaryMouseButton,
      kind: PointerDeviceKind.mouse,
    );
    await t.pump(const Duration(milliseconds: 700));
    final moved = position();
    expect(moved, isNot(initial));
    expect(jsonDecode(store.getString('village-v1')!)['distance'], 0);
    expect(
      find.textContaining('Teleported. No distance awarded.'),
      findsOneWidget,
    );
    final next =
        t.getRect(find.byType(FlutterMap)).center + const Offset(-55, 35);
    await t.tapAt(next, kind: PointerDeviceKind.mouse);
    await t.pump(const Duration(milliseconds: 700));
    expect(position(), moved);
    await t.tap(find.byTooltip('Teleport'));
    await t.pump(const Duration(milliseconds: 700));
    expect(position(), isNot(moved));
    expect(jsonDecode(store.getString('village-v1')!)['distance'], 0);
    expect(t.takeException(), isNull);
    await t.pumpWidget(const SizedBox());
    t.view.resetPhysicalSize();
    t.view.resetDevicePixelRatio();
  });
  testWidgets(
    'right-click cannot move the player when the spoofer is disabled',
    (t) async {
      SharedPreferences.setMockInitialValues({
        'village-v1': jsonEncode(Game().json()),
      });
      await t.pumpWidget(const HearthApp());
      await t.pumpAndSettle();
      await t.tap(find.text('Map'));
      await t.pump();
      final target =
          t.getRect(find.byType(FlutterMap)).center + const Offset(55, -35);
      await t.tapAt(
        target,
        buttons: kSecondaryMouseButton,
        kind: PointerDeviceKind.mouse,
      );
      await t.pump(const Duration(milliseconds: 700));
      final store = await SharedPreferences.getInstance();
      expect(
        jsonDecode(store.getString('village-v1')!)['position'],
        coords(start),
      );
      expect(find.textContaining('Teleported.'), findsNothing);
      expect(find.byTooltip('Teleport'), findsNothing);
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox());
    },
  );
}

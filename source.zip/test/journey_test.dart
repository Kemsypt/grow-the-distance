import 'dart:convert';
// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/journey_history.dart';
import 'package:hearthstride/journey_view.dart';
import 'package:latlong2/latlong.dart';
import 'game_test.dart' show fieldAt;

void main() {
  test('journey round trips walk order, teleport gaps and farm milestones', () {
    final game = Game()..setHome(start);
    game.startWalk(free: true);
    game.move(LatLng(start.latitude + .0001, start.longitude));
    final jumped = LatLng(start.latitude + .01, start.longitude);
    game.teleport(jumped);
    game.move(LatLng(jumped.latitude + .0001, jumped.longitude));
    game.bag.addAll({'timber': 5, 'stone': 3});
    expect(game.build('farm', jumped, farmName: '  Fern Acres  '), true);
    game.finishWalk();
    game.startWalk();
    game.move(LatLng(jumped.latitude + .0002, jumped.longitude));
    game.finishWalk();
    final saved = Game()..restore(jsonDecode(jsonEncode(game.json())));
    final frame = JourneyFrame()..seek(saved.journey, saved.journey.length);
    expect(frame.tracks.map((t) => t.$1), [1, 1, 2]);
    expect(frame.tracks[1].$2.first, jumped);
    expect(frame.tracks[0].$2, isNot(contains(jumped)));
    expect(saved.places.last.name, 'Fern Acres');
    expect(frame.buildings.values.last.label, 'Fern Acres built');
    expect(
      saved.journey.firstWhere((e) => e.kind == JourneyKind.walkStart).label,
      'Free walk started',
    );
    frame.seek(saved.journey, 2);
    expect(frame.buildings.values.any((e) => e.building == 'farm'), false);
  });

  test(
    'crop changes require being inside even when entrance is in collection range',
    () {
      final game = Game();
      final farm = Place(
        'Farm',
        'farm',
        start,
        fence: fieldAt(start, size: .0001),
      );
      game.places.add(farm);
      game.teleport(LatLng(start.latitude + .0002, start.longitude));
      expect(game.inCollectionRange(farm), true);
      game.plant(farm, Crop.pumpkins);
      expect(farm.crop, Crop.carrots);
      game.teleport(start);
      game.plant(farm, Crop.pumpkins);
      expect(farm.crop, Crop.pumpkins);
    },
  );

  testWidgets('overview farm visibility and replay timeline controls', (
    t,
  ) async {
    final game = Game()..setHome(start);
    game.bag.addAll({'timber': 5, 'stone': 3});
    game.build('farm', start);
    game.startWalk();
    game.move(LatLng(start.latitude + .0001, start.longitude));
    game.finishWalk();
    await t.pumpWidget(
      MaterialApp(
        home: JourneyView(events: game.journey, origin: start, tiles: false),
      ),
    );
    await t.pumpAndSettle();
    expect(t.widget<MarkerLayer>(find.byType(MarkerLayer)).markers.length, 2);
    await t.tap(find.text('Show farms'));
    await t.pumpAndSettle();
    expect(t.widget<MarkerLayer>(find.byType(MarkerLayer)).markers.length, 1);
    await t.tap(find.text('Replay'));
    await t.pumpAndSettle();
    expect(find.text('Play'), findsOneWidget);
    await t.tap(find.text('1×'));
    await t.pumpAndSettle();
    await t.tap(find.text('20×').last);
    await t.pumpAndSettle();
    expect(find.text('20×'), findsOneWidget);
    await t.tap(find.text('Play'));
    await t.pump(const Duration(seconds: 4));
    await t.pumpAndSettle();
    expect(find.textContaining('Walk finished'), findsOneWidget);
    expect(
      t.widget<PolylineLayer>(find.byType(PolylineLayer)).polylines.length,
      1,
    );
    await t.tap(find.byTooltip('Restart replay'));
    await t.pumpAndSettle();
    expect(
      t.widget<PolylineLayer>(find.byType(PolylineLayer)).polylines,
      isEmpty,
    );
    expect(t.takeException(), isNull);
  });
}

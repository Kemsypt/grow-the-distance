// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/road_permission.dart';

void main() {
  testWidgets('road lookup needs an explicit allow and skip is offline', (
    t,
  ) async {
    bool? allowed;
    await t.pumpWidget(
      MaterialApp(
        home: Builder(
          builder: (c) => Scaffold(
            body: TextButton(
              onPressed: () async {
                allowed = await askForRoadData(c);
              },
              child: const Text('Finish'),
            ),
          ),
        ),
      ),
    );
    await t.tap(find.text('Finish'));
    await t.pumpAndSettle();
    expect(allowed, isNull);
    expect(find.textContaining('overpass-api.de'), findsOneWidget);
    await t.tap(find.text('Skip road snapping'));
    await t.pumpAndSettle();
    expect(allowed, false);
    await t.tap(find.text('Finish'));
    await t.pumpAndSettle();
    await t.tap(find.text('Allow road lookup'));
    await t.pumpAndSettle();
    expect(allowed, true);
  });
}

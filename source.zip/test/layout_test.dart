// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hearthstride/main.dart';

void main() {
  testWidgets('Desktop Admin remains open and simulator/time skip work', (
    t,
  ) async {
    SharedPreferences.setMockInitialValues({});
    t.view.physicalSize = const Size(1368, 801);
    t.view.devicePixelRatio = 1;
    await t.pumpWidget(const HearthApp());
    await t.pumpAndSettle();
    await t.tap(find.byTooltip('Settings'));
    await t.pump();
    expect(find.text('Admin menu'), findsOneWidget);
    await t.pump(const Duration(seconds: 3));
    expect(find.text('Admin menu'), findsOneWidget);
    await t.ensureVisible(find.text('Admin menu'));
    await t.pump();
    await t.tap(find.text('Admin menu'));
    await t.pump();
    expect(find.text('TIME SKIPPER'), findsOneWidget);
    await t.ensureVisible(find.text('Activate GPS spoofer'));
    await t.pump();
    await t.tap(find.text('Activate GPS spoofer'));
    await t.pump();
    expect(find.text('ADMIN · GPS SIMULATOR'), findsOneWidget);
    final sliderFinder = find.byType(Slider);
    await t.ensureVisible(sliderFinder);
    await t.pump();
    final sliderRect = t.getRect(sliderFinder);
    await t.tapAt(Offset(sliderRect.right - 24, sliderRect.center.dy));
    await t.pump();
    expect(t.widget<Slider>(sliderFinder).value, 20);
    expect(find.textContaining('20× walking speed'), findsOneWidget);
    await t.ensureVisible(find.text('+5 days'));
    await t.pump();
    await t.tap(find.text('+5 days'));
    await t.pump();
    expect(
      find.textContaining('Advanced village time by 120 hours.'),
      findsWidgets,
    );
    await t.tap(find.text('Neighbourhood'));
    await t.pump();
    expect(find.text('SIMULATOR ACTIVE'), findsOneWidget);
    await t.tap(find.text('Set home here'));
    await t.pump();
    expect(find.textContaining('Home established.'), findsWidgets);
    expect(t.takeException(), isNull);
    await t.pumpWidget(const SizedBox());
    t.view.resetPhysicalSize();
    t.view.resetDevicePixelRatio();
  });
  testWidgets('Phone home and Settings fit without overflow', (t) async {
    SharedPreferences.setMockInitialValues({});
    t.view.physicalSize = const Size(390, 844);
    t.view.devicePixelRatio = 1;
    await t.pumpWidget(const HearthApp());
    await t.pumpAndSettle();
    await t.tap(find.byTooltip('Settings'));
    await t.pump();
    await t.ensureVisible(find.text('Admin menu'));
    await t.pump();
    await t.tap(find.text('Admin menu'));
    await t.pump();
    expect(find.text('TIME SKIPPER'), findsOneWidget);
    expect(t.takeException(), isNull);
    await t.pumpWidget(const SizedBox());
    t.view.resetPhysicalSize();
    t.view.resetDevicePixelRatio();
  });
}

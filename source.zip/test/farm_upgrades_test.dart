import 'dart:convert';
import 'dart:math';
// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/farm_upgrades.dart';
import 'package:hearthstride/farm_upgrade_view.dart';
import 'package:latlong2/latlong.dart';
import 'game_test.dart' show fieldAt;

class FixedRandom implements Random {
  FixedRandom([this.roll = .10]);
  final double roll;
  @override
  double nextDouble() => roll;
  @override
  int nextInt(int max) => 0;
  @override
  bool nextBool() => false;
}

Place makeFarm(Game game) {
  final farm = Place(
    'Test Farm',
    'farm',
    start,
    fence: fieldAt(start),
    planted: game.now - const Duration(days: 3).inMilliseconds,
  );
  game.places.add(farm);
  return farm;
}

void main() {
  test(
    'five-tier upgrades charge resources and synchronize growth and storage',
    () {
      final game = Game();
      final farm = makeFarm(game);
      expect(game.upgradeFarm(farm, FarmUpgrade.sprinklers), false);
      game.bag.addAll({
        'timber': 200,
        'stone': 200,
        'seeds': 200,
        'water': 200,
      });
      game.teleport(LatLng(start.latitude + .01, start.longitude));
      expect(game.upgradeFarm(farm, FarmUpgrade.sprinklers), false);
      expect(game.bag['stone'], 200);
      game.teleport(start);
      final progress = farm.growth(game.now);
      final mature = farm.fullAt;
      expect(game.upgradeFarm(farm, FarmUpgrade.sprinklers), true);
      expect(farm.growth(game.now), closeTo(progress, .00001));
      expect(farm.fullAt, lessThan(mature));
      for (var i = 0; i < 4; i++) {
        expect(game.upgradeFarm(farm, FarmUpgrade.farmhouse), true);
      }
      expect(farm.storage, farm.capacity * 2);
      expect(farm.available(farm.storageFullAt), farm.storage);
      expect(farm.available(farm.fullAt), farm.capacity);
      final timber = game.bag['timber'];
      expect(game.upgradeFarm(farm, FarmUpgrade.farmhouse), false);
      expect(game.bag['timber'], timber);
      final restored = Game()..restore(jsonDecode(jsonEncode(game.json())));
      expect(
        restored.places.single.improvements.level(FarmUpgrade.farmhouse),
        5,
      );
      expect(
        restored.places.single.improvements.level(FarmUpgrade.sprinklers),
        2,
      );
    },
  );

  test(
    'fence and scarecrow tiers prevent incidents on the same daily roll',
    () {
      final game = Game(random: FixedRandom());
      final basic = makeFarm(game), protected = makeFarm(game);
      protected.improvements.tiers[FarmUpgrade.fence] = 5;
      protected.improvements.tiers[FarmUpgrade.scarecrow] = 5;
      for (final farm in [basic, protected]) {
        farm.improvements.nextRiskAt = game.now;
      }
      game.advanceFarmRisks();
      expect(basic.improvements.fenceDamaged, true);
      expect(basic.improvements.lastIncident, contains('Broken Fence!'));
      expect(basic.improvements.lastIncident, contains('A rabbit'));
      expect(basic.yieldCapacity, lessThan(basic.capacity));
      expect(basic.improvements.lostCrops, greaterThan(0));
      expect(protected.improvements.fenceDamaged, false);
      expect(protected.improvements.lostCrops, 0);
      final loss = basic.improvements.lostCrops;
      game.advanceFarmRisks();
      expect(basic.improvements.lostCrops, loss);
      final restored = Game()..restore(jsonDecode(jsonEncode(game.json())));
      expect(restored.places.first.yieldCapacity, basic.yieldCapacity);
      game.bag['timber'] = 4;
      game.teleport(LatLng(start.latitude + .01, start.longitude));
      expect(game.repairFarmFence(basic), false);
      expect(game.bag['timber'], 4);
      game.teleport(start);
      expect(game.repairFarmFence(basic), true);
      expect(basic.yieldCapacity, basic.capacity);
      expect(basic.improvements.lostCrops, loss);
      expect(basic.improvements.fenceDamaged, false);
      expect(game.bag['timber'], 0);
    },
  );

  test('weather rolls use local seasons in both hemispheres', () {
    expect(
      FarmEvent.seasonalWeather(DateTime(2026, 1), -34),
      FarmEvent.drought,
    );
    expect(
      FarmEvent.seasonalWeather(DateTime(2026, 5), -34),
      FarmEvent.drought,
    );
    expect(
      FarmEvent.seasonalWeather(DateTime(2026, 6), -34),
      FarmEvent.heavyRain,
    );
    expect(
      FarmEvent.seasonalWeather(DateTime(2026, 11), -34),
      FarmEvent.heavyRain,
    );
    expect(
      FarmEvent.seasonalWeather(DateTime(2026, 1), 34),
      FarmEvent.heavyRain,
    );
    expect(FarmEvent.seasonalWeather(DateTime(2026, 6), 34), FarmEvent.drought);
  });

  test(
    'damaged farms roll more events and debug triggers apply real losses',
    () {
      final game = Game(random: FixedRandom(.32));
      final damaged = makeFarm(game), healthy = makeFarm(game);
      expect(
        game.triggerFarmEvent(damaged, event: FarmEvent.brokenFence),
        true,
      );
      for (final farm in [damaged, healthy]) {
        farm.improvements.nextRiskAt = game.now;
      }
      game.advanceFarmRisks();
      expect(damaged.improvements.lastIncident, startsWith('Bird Swarm!'));
      expect(healthy.improvements.lastIncident, isNull);
      expect(game.triggerFarmEvent(healthy, event: FarmEvent.heavyRain), true);
      expect(healthy.improvements.lastIncident, startsWith('Heavy Rain!'));
      expect(healthy.improvements.lostCrops, greaterThan(0));
      expect(game.log.first, contains('Heavy Rain!'));
    },
  );

  testWidgets('farm upgrade page purchases the displayed next tier', (t) async {
    final game = Game();
    final farm = makeFarm(game);
    game.bag.addAll({'timber': 8, 'stone': 5});
    await t.pumpWidget(
      MaterialApp(
        home: FarmUpgradeView(game: game, farm: farm),
      ),
    );
    await t.tap(find.text('Upgrade fence to tier 2'));
    await t.pumpAndSettle();
    expect(find.text('Tier 2 / 5'), findsOneWidget);
    expect(find.text('Reinforced timber'), findsOneWidget);
    expect(game.bag['timber'], 0);
    expect(t.takeException(), isNull);
  });
}

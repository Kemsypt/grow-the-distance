import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:hearthstride/game.dart';

void main() {
  test('field area scales full yield and long crops take twice as long', () {
    final g = Game();
    final small = Place(
      'Small',
      'farm',
      start,
      fence: fieldAt(start, size: .0001),
      planted: g.now,
    );
    final large = Place(
      'Large',
      'farm',
      start,
      fence: fieldAt(start, size: .0002),
      planted: g.now,
    );
    expect(large.capacity, greaterThan(small.capacity));
    g.places.addAll([small, large]);
    g.plant(large, Crop.pumpkins);
    g.skip(const Duration(days: 7));
    expect(small.available(g.now), small.capacity);
    expect(large.growth(g.now), closeTo(.5, .001));
    expect(large.available(g.now), lessThan(large.capacity));
    g.skip(const Duration(days: 7));
    expect(large.available(g.now), large.capacity);
    expect(g.collect(large), large.capacity);
    expect(g.bag['pumpkins'], large.capacity);
    expect(large.growth(g.now), closeTo(0, .001));
  });
  test('marker uses the fence centre while the entrance remains unchanged', () {
    final centre = const LatLng(-34.929, 138.6);
    final farm = Place('Farm', 'farm', start, fence: fieldAt(centre));
    expect(meters(farm.markerPosition, centre), lessThan(.1));
    expect(farm.pos, start);
  });
  test('summary owns walk rewards and feedback updates the next goal once', () {
    final g = Game();
    g.startWalk();
    g.pickup();
    g.pickup(fromWalk: true);
    final p = Place(
      'Well',
      'well',
      start,
      planted: g.now - const Duration(hours: 4).inMilliseconds,
    );
    expect(g.collect(p), 20);
    final outing = g.finishWalk()!;
    expect(outing.discoveries, 1);
    expect(outing.harvested['water'], 20);
    g.recordFeedback(outing, WalkFeedback.tooMuch);
    expect(g.goal, 595);
    g.recordFeedback(outing, WalkFeedback.easy);
    expect(g.goal, 595);
    final restored = Game()..restore(g.json());
    expect(restored.lastOuting!.discoveries, 1);
    expect(restored.goal, 595);
  });
  test('crop trade charges resources only when the well can be built', () {
    final g = Game()..setHome(start);
    g.bag['carrots'] = 6;
    g.bag['potatoes'] = 4;
    g.bag['timber'] = 4;
    expect(g.build('well', start, useCrops: true), false);
    expect(g.surplusCrops, 10);
    g.bag['stone'] = 6;
    expect(g.build('well', start, useCrops: true), true);
    expect(g.surplusCrops, 0);
    expect(g.bag['timber'], 0);
    expect(g.bag['stone'], 0);
  });
  test('teleport never adds distance or pickups', () {
    final g = Game();
    g.startWalk();
    g.teleport(const LatLng(-34.93, 138.61));
    expect(g.distance, 0);
    expect(g.bag['timber'], 0);
  });
  test('walking accumulates distance, pausing does not', () {
    final g = Game();
    g.startWalk();
    g.move(const LatLng(-34.9284, 138.6007));
    expect(g.distance, greaterThan(10));
    final d = g.distance;
    g.startWalk();
    g.move(const LatLng(-34.9283, 138.6007));
    expect(g.distance, d);
  });
  test(
    'time skipper grows crops with no fitness credit and caps production',
    () {
      final g = Game();
      g.places.add(
        Place('Farm', 'farm', start, planted: g.now, fence: fieldAt(start)),
      );
      g.skip(const Duration(days: 14));
      expect(g.places.first.available(g.now), g.places.first.capacity);
      expect(g.distance, 0);
      expect(() => g.skip(const Duration(hours: -1)), throwsArgumentError);
    },
  );
  test('build deducts resources and prevents insufficient supplies', () {
    final g = Game();
    g.setHome(start);
    expect(g.build('farm', start), false);
    g.bag['timber'] = 10;
    g.bag['stone'] = 10;
    expect(g.build('farm', start), true);
    expect(g.bag['timber'], 5);
    expect(g.bag['stone'], 7);
  });
  test('collection requires proximity and cannot be claimed twice', () {
    final g = Game();
    final p = Place(
      'Farm',
      'farm',
      const LatLng(-35, 138.6),
      planted: g.now - const Duration(days: 7).inMilliseconds,
      fence: fieldAt(const LatLng(-35, 138.6)),
    );
    expect(g.collect(p), 0);
    g.teleport(p.pos);
    expect(g.collect(p), greaterThan(0));
    expect(g.collect(p), 0);
  });
  test(
    'save round trip retains world but disables simulator and active tracking',
    () {
      final g = Game();
      g.setHome(start);
      g.bag['timber'] = 50;
      g.skip(const Duration(hours: 5));
      g.spoofer = true;
      g.startWalk();
      final loaded = Game()..restore(g.json());
      expect(loaded.homeSet, true);
      expect(loaded.bag['timber'], 50);
      expect(loaded.offset, g.offset);
      expect(loaded.spoofer, false);
      expect(loaded.walking, false);
    },
  );
  test('farm fence needs closed loop containing farm', () {
    final g = Game();
    final p = Place('Farm', 'farm', start);
    g.beginFence();
    g.fence = [
      const LatLng(-34.9287, 138.6005),
      const LatLng(-34.9283, 138.6005),
      const LatLng(-34.9283, 138.6009),
      const LatLng(-34.9287, 138.6009),
    ];
    g.position = g.fence.first;
    g.fence.add(g.position);
    expect(g.finishFence(p), true);
    expect(p.area, greaterThan(100));
    expect(p.capacity, greaterThan(20));
  });
  test('long tracked walk produces discoveries', () {
    final g = Game();
    g.startWalk();
    for (int i = 1; i < 50; i++) {
      g.move(LatLng(start.latitude + i * .0001, start.longitude));
    }
    expect(g.bag.values.reduce((a, b) => a + b), greaterThan(6));
  });

  test(
    '20x simulator movement stays trackable and draws fence points live',
    () {
      final one = simulatedStep(
        start,
        horizontal: 1,
        vertical: 0,
        multiplier: 1,
        seconds: .2,
      );
      final twenty = simulatedStep(
        start,
        horizontal: 1,
        vertical: 0,
        multiplier: 20,
        seconds: .2,
      );
      expect(meters(start, twenty) / meters(start, one), closeTo(20, .01));
      final g = Game();
      g.beginFence();
      for (int i = 0; i < 50; i++) {
        g.move(
          simulatedStep(
            g.position,
            horizontal: 1,
            vertical: 0,
            multiplier: 20,
            seconds: .2,
          ),
        );
      }
      expect(g.distance, greaterThan(270));
      expect(g.fence.length, 51);
      expect(g.fence.last, g.position);
      g.startWalk(); // Pause the outing.
      g.move(
        simulatedStep(
          g.position,
          horizontal: 1,
          vertical: 0,
          multiplier: 20,
          seconds: .2,
        ),
      );
      expect(g.fence.length, 51);
    },
  );
  test('simulator speed is capped at 20x and diagonals are normalized', () {
    final capped = simulatedStep(
      start,
      horizontal: 1,
      vertical: 0,
      multiplier: 100,
      seconds: .2,
    );
    final maximum = simulatedStep(
      start,
      horizontal: 1,
      vertical: 0,
      multiplier: 20,
      seconds: .2,
    );
    expect(capped, maximum);
    final diagonal = simulatedStep(
      start,
      horizontal: 1,
      vertical: 1,
      multiplier: 20,
      seconds: .2,
    );
    expect(meters(start, diagonal), closeTo(meters(start, maximum), .05));
  });

  test(
    'normal-speed sub-metre GPS ticks extend fences and accumulate distance',
    () {
      final g = Game();
      g.beginFence();
      for (int i = 0; i < 10; i++) {
        g.move(
          simulatedStep(
            g.position,
            horizontal: 1,
            vertical: 0,
            multiplier: 1,
            seconds: .2,
          ),
        );
      }
      expect(g.distance, closeTo(2.8, .02));
      expect(g.fence.length, 11);
    },
  );
}

List<LatLng> fieldAt(LatLng p, {double size = .001}) => [
  LatLng(p.latitude - size, p.longitude - size),
  LatLng(p.latitude + size, p.longitude - size),
  LatLng(p.latitude + size, p.longitude + size),
  LatLng(p.latitude - size, p.longitude + size),
];

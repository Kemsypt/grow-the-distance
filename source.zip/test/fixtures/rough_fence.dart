import 'dart:math';
import 'package:latlong2/latlong.dart';
import 'package:hearthstride/game.dart';

LatLng fencePoint(double x, double y) => LatLng(
  start.latitude + y / 111320,
  start.longitude + x / (111320 * cos(start.latitude * pi / 180)),
);
final farmEntrance = fencePoint(70, 110);
// A synthetic, park-sized walk with several-metre steering/GPS bumps like the
// supplied screenshot. It is not an extraction of anyone's real location trace.
final roughFence = <LatLng>[
  fencePoint(-4, 110),
  fencePoint(1, 145),
  fencePoint(-2, 180),
  fencePoint(0, 205),
  fencePoint(10, 220),
  fencePoint(45, 222),
  fencePoint(70, 219),
  fencePoint(100, 221),
  fencePoint(130, 218),
  fencePoint(140, 205),
  fencePoint(142, 170),
  fencePoint(138, 125),
  fencePoint(143, 80),
  fencePoint(140, 35),
  fencePoint(135, 5),
  fencePoint(120, -2),
  fencePoint(95, 1),
  fencePoint(70, -4),
  fencePoint(40, 2),
  fencePoint(15, 1),
  fencePoint(5, 0),
  fencePoint(0, 15),
  fencePoint(-2, 50),
  fencePoint(3, 90),
];

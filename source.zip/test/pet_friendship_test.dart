import 'dart:convert';
import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:hearthstride/game.dart';
import 'package:hearthstride/homestead.dart';
import 'package:latlong2/latlong.dart';

import 'game_test.dart' show fieldAt;

void main() {
  test('only accepted walks with a following pet earn friendship', () {
    final game = Game()..setHome(start);
    game.findPet(species: VillagePet.dog);
    game.startWalk();
    game.move(
      simulatedStep(
        start,
        horizontal: 1,
        vertical: 0,
        multiplier: 1,
        seconds: 42,
      ),
    );
    expect(game.petFriendship, 0);
    final saved = Game()..restore(jsonDecode(jsonEncode(game.json())));
    saved.startWalk();
    saved.move(
      simulatedStep(
        saved.position,
        horizontal: 1,
        vertical: 0,
        multiplier: 1,
        seconds: 42,
      ),
    );
    expect(saved.petFriendship, 1);
    saved.startWalk(); // Pause the current outing.
    saved.move(
      simulatedStep(
        saved.position,
        horizontal: 1,
        vertical: 0,
        multiplier: 1,
        seconds: 60,
      ),
    );
    saved.teleport(const LatLng(-34.95, 138.61));
    expect(saved.petFriendship, 1);
    saved.startWalk();
    saved.setPetFollowing(false);
    for (var step = 0; step < 3; step++) {
      saved.move(
        simulatedStep(
          saved.position,
          horizontal: 1,
          vertical: 0,
          multiplier: 1,
          seconds: 42,
        ),
      );
    }
    expect(saved.petFriendship, 1);
    saved.setPetFollowing(true);
    saved.bag['herbs'] = 1;
    saved.treatPet();
    expect(saved.petFriendship, 6);
  });

  test('level four unlocks one farm helper and persists its harvest bonus', () {
    final game = Game()..setHome(start);
    game.findPet(species: VillagePet.bunny);
    final farm = Place(
      'Sunny Farm',
      'farm',
      start,
      fence: fieldAt(start),
      planted: game.now - const Duration(days: 7).inMilliseconds,
    );
    game.places.add(farm);
    expect(game.assignPetToFarm(farm), false);
    game.bag['herbs'] = 8;
    for (var i = 0; i < 8; i++) {
      game.treatPet();
    }
    expect(game.petFriendshipLevel, 4);
    game.teleport(const LatLng(-34.95, 138.61));
    expect(game.assignPetToFarm(farm), false);
    game.teleport(start);
    expect(game.assignPetToFarm(farm), true);
    final restored = Game()..restore(jsonDecode(jsonEncode(game.json())));
    final savedFarm = restored.places.last;
    expect(restored.petFarm, same(savedFarm));
    expect(restored.petFollows, false);
    final harvest = savedFarm.available(restored.now);
    expect(restored.collect(savedFarm), harvest + (harvest * .15).round());
    restored.setPetFollowing(true);
    expect(restored.petFarm, isNull);
    expect(restored.petFollows, true);
  });

  for (final species in [VillagePet.dog, VillagePet.cat]) {
    test('${species.label} protects the assigned farm from its event', () {
      final dog = species == VillagePet.dog;
      final game = Game(random: _FixedRoll(dog ? .11 : .17))..setHome(start);
      game.findPet(species: species);
      final age = dog ? 0 : const Duration(days: 3).inMilliseconds;
      final first = Place(
        'Protected',
        'farm',
        start,
        fence: fieldAt(start),
        planted: game.now - age,
      );
      final second = Place(
        'Exposed',
        'farm',
        start,
        fence: fieldAt(start),
        planted: game.now - age,
      );
      game.places.addAll([first, second]);
      game.petFriendship = Game.petFarmUnlock;
      expect(game.assignPetToFarm(first), true);
      first.improvements.nextRiskAt = second.improvements.nextRiskAt = game.now;
      game.advanceFarmRisks();
      expect(first.improvements.lastIncident, isNull);
      expect(
        second.improvements.lastIncident,
        contains(dog ? 'Broken Fence!' : 'Bird Swarm!'),
      );
    });
  }
}

class _FixedRoll implements Random {
  const _FixedRoll(this.roll);
  final double roll;
  @override
  bool nextBool() => false;
  @override
  double nextDouble() => roll;
  @override
  int nextInt(int max) => 0;
}

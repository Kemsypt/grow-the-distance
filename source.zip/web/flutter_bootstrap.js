{{flutter_js}}
{{flutter_build_config}}

// Keep browser/CDN caches from loading an older game after a deployment.
const gameBuildVersion = {{flutter_service_worker_version}};
for (const build of _flutter.buildConfig.builds) {
  if (build.compileTarget === 'dart2js') {
    build.mainJsPath = (build.mainJsPath || 'main.dart.js') + '?v=' + gameBuildVersion;
  }
}
_flutter.loader.load();

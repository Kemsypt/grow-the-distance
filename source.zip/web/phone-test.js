(() => {
  'use strict';
  const phones = [["iphone17", "iPhone 17", 402, 874], ["iphone17pro", "iPhone 17 Pro", 402, 874], ["iphone17max", "iPhone 17 Pro Max", 440, 956], ["iphone16", "iPhone 16", 393, 852], ["iphone16pro", "iPhone 16 Pro", 402, 874], ["iphone16max", "iPhone 16 Pro Max", 440, 956], ["iphone15", "iPhone 15", 393, 852], ["iphone14", "iPhone 14", 390, 844], ["iphonese", "iPhone SE (3rd gen)", 375, 667], ["s26ultra", "Samsung Galaxy S26 Ultra", 412, 891], ["s25", "Samsung Galaxy S25", 360, 780], ["s24", "Samsung Galaxy S24", 360, 780], ["a17", "Samsung Galaxy A17", 412, 892], ["a55", "Samsung Galaxy A55", 384, 832], ["pixel8a", "Google Pixel 8a", 412, 915]];
  const params = new URLSearchParams(location.search);
  const mobile = navigator.userAgentData?.mobile || /Android|iPhone|iPod|iPad/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  if (mobile && params.get('phoneTest') !== '1') {
    location.replace(new URL('app.html' + location.search + location.hash, document.baseURI));
    return;
  }
  const $ = id => document.getElementById(id);
  const phone = $('phone'), zoom = $('zoom'), stage = $('stage'), device = $('device'), screen = $('screen'), game = $('game');
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem('gtd.phoneTest') || '{}') || {}; } catch (_) {}
  for (const [id, name, w, h] of phones) {
    const option = new Option(`${name} · ${w} × ${h}`, id);
    phone.add(option);
  }
  phone.value = phones.some(p => p[0] === saved.phone) ? saved.phone : 'pixel8a';
  let landscape = saved.landscape === true;
  if (['fit', '1', '0.75', '0.5'].includes(saved.zoom)) zoom.value = saved.zoom;
  let desktop = params.get('view') === 'desktop';
  let raf;
  function persist() {
    try { localStorage.setItem('gtd.phoneTest', JSON.stringify({phone: phone.value, landscape, zoom: zoom.value})); } catch (_) {}
  }
  function render() {
    document.body.classList.toggle('desktop', desktop);
    $('return').hidden = !desktop;
    if (desktop) {
      const w = stage.clientWidth, h = stage.clientHeight;
      device.style.width = screen.style.width = w + 'px';
      device.style.height = screen.style.height = h + 'px';
      game.style.width = w + 'px'; game.style.height = h + 'px'; game.style.transform = 'none';
      return;
    }
    const p = phones.find(p => p[0] === phone.value);
    const w = landscape ? p[3] : p[2], h = landscape ? p[2] : p[3];
    // Fit the whole frame, while keeping the iframe at the selected phone's real layout size.
    const fit = Math.min(1, Math.max(.1, (stage.clientWidth - 64) / w), Math.max(.1, (stage.clientHeight - 64) / h));
    const scale = zoom.value === 'fit' ? fit : Number(zoom.value);
    device.style.width = screen.style.width = w * scale + 'px';
    device.style.height = screen.style.height = h * scale + 'px';
    game.style.width = w + 'px'; game.style.height = h + 'px'; game.style.transform = `scale(${scale})`;
    $('dimensions').textContent = `${w} × ${h}`;
    $('scale').textContent = `${Math.round(scale * 100)}% scale · ${landscape ? 'Landscape' : 'Portrait'}`;
    $('rotate').textContent = `↻ Rotate to ${landscape ? 'portrait' : 'landscape'}`;
    game.title = `Grow the Distance · ${p[1]} · ${w} × ${h}`;
  }
  function schedule() { cancelAnimationFrame(raf); raf = requestAnimationFrame(render); }
  phone.addEventListener('change', () => { persist(); render(); });
  zoom.addEventListener('change', () => { persist(); render(); });
  $('rotate').addEventListener('click', () => { landscape = !landscape; persist(); render(); });
  $('desktop').addEventListener('click', () => { desktop = true; render(); });
  $('return').addEventListener('click', () => { desktop = false; render(); });
  new ResizeObserver(schedule).observe(stage);
  window.addEventListener('resize', schedule);
  render();
  // One game instance: device, rotation, zoom and desktop switches never reload progress.
  const app = new URL('app.html', document.baseURI);
  params.delete('view'); params.delete('phoneTest');
  app.search = params.toString(); app.searchParams.set('build', '017-1');
  game.src = app.href;
})();
